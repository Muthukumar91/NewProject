package LoginTestCase;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import base.WdMethods;
import pages.LoginPage;
import pages.ViewDespatchLinkage;

public class CheckQuerry extends PreAndPost{
		
		@BeforeClass
		public void setValues() {
			browserName="internet explorer";
			testCaseName="TC014_ViewDespatchLinkageBeforeToolTip";
			testDescription="BeforeClickingToolTipforOrderNumberl";
			category="Functional";
			dataSource="excel";
			dataSheetName="TC014_ViewDespatchLinkageBeforeToolTip";
			authors="Muthu";
		}
		
		@Test(dataProvider ="fetchData")
		public void runLogin(String username,String password,String orderNumber,String dataWarningMessage,String Message,String code) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
			new ViewDespatchLinkage()
			.dbvalidation("select TEOIQPDB_Quantity from epm.SQLPMP.PMP_T_EXECPLAN_OUTPUT_ITEM_SPECIFICATION_QUANTITY_PLAN_DETAIL_BREAKUPS");
					
			
			
		}
	

}


