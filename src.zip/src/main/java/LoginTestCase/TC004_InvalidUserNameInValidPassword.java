package LoginTestCase;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC004_InvalidUserNameInValidPassword   extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC004_InvalidUserNameInValidPassword";
		testDescription="TC004_InvalidUserNameInValidPassword";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC004_Login";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void Login (String uName, String pwd,String TextData) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
        .InvalidCredentials()
        .AlertTextLoginpage(TextData)
        .AcceptalertforInvalidCredentials();





	}

}
