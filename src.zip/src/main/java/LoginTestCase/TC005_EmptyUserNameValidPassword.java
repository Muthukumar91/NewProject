package LoginTestCase;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC005_EmptyUserNameValidPassword   extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_EmptyUserNameValidPassword";
		testDescription="TC005_EmptyUserNameValidPassword";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC005_Login";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void Login (String uName, String pwd,String TextData) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
        .InvalidCredentials()
        .AlertTextLoginpage(TextData)
        .AcceptalertforInvalidCredentials();





	}

}
