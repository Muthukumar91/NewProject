package LoginTestCase;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC006_EmptyUserNameEmptyPassword   extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC006_EmptyUserNameEmptyPassword";
		testDescription="TC006_EmptyUserNameEmptyPassword";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC006_Login";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void Login (String uName, String pwd,String TextData) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
        .InvalidCredentials()
        .AlertTextLoginpage(TextData)
        .AcceptalertforInvalidCredentials();





	}

}
