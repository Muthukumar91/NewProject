package LoginTestCase;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC009_EmptyUserNameInvalidPassword   extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC009_EmptyUserNameInvalidPassword";
		testDescription="TC009_EmptyUserNameInvalidPassword";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC009_Login";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void Login (String uName, String pwd,String TextData) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
        .InvalidCredentials()
        .AlertTextLoginpage(TextData)
        .AcceptalertforInvalidCredentials();





	}

}
