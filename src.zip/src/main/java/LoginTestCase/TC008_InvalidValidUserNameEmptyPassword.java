package LoginTestCase;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC008_InvalidValidUserNameEmptyPassword   extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC007_ValidUserNameEmptyPassword";
		testDescription="TC007_ValidUserNameEmptyPassword";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC007_Login";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void Login (String uName, String pwd,String TextData) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
        .InvalidCredentials()
        .AlertTextLoginpage(TextData)
        .AcceptalertforInvalidCredentials();





	}

}
