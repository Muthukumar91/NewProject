package TestCase.DeliveryChallanView;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC002_ViewDeliveryChallan_ClickReset extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC002_ViewDeliveryChallan_ClickReset";
		testDescription="ClickReset";
		category="Functional";
		dataSource="Excel";
		dataSheetName="DC/TC001_CreateDeliveryChallan_ClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDeliveryChallan()
		.clickReset();	
		
		
		
		
		
	}

}
