package TestCase.DeliveryChallanView;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC007_ViewDeliveryChallan_WithDCNumber extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC007_ViewDeliveryChallan_WithDCNumber";
		testDescription="WithDCNumber";
		category="Functional";
		dataSource="Excel";
		dataSheetName="DC/TC001_CreateDeliveryChallan_ClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String DCNumber) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDeliveryChallan()
		.clickFromDateIcon(Year, month, day, date)
		.clickToDateIcon(Year, month, day, date)
		.typeAndChooseDCNumber(DCNumber)
		.clickGo();
		
		
		
		
		
	}

}
