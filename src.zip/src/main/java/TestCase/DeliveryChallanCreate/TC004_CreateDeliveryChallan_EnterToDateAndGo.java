package TestCase.DeliveryChallanCreate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC004_CreateDeliveryChallan_EnterToDateAndGo extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC003_CreateDeliveryChallanEnterFromDateAndGo";
		testDescription="EnterFromDateAndGo";
		category="smoke";
		dataSource="Excel";
		dataSheetName="DC/TC003_CreateDeliveryChallanEnterMandatoryField";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDeliveryChallan()
		.clickCreate()
		.clicktoDateicon(Year,month,day,date)
		.ClickGo()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
		
		
		
		
		
	}

}
