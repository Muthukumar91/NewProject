package TestCase.DeliveryChallanCreate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC006_CreateDeliveryChallan_ToDateLesserThanFromDate extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_CreateDeliveryChallan_FromDateGreaterThanToDate";
		testDescription="FromDateGreaterThanToDate";
		category="smoke";
		dataSource="Excel";
		dataSheetName="DC/TC005_CreateDeliveryChallan_FromDateGreaterThanToDate";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String Year1, String month1, String day1, String date1,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDeliveryChallan()
		.clickCreate()
		.clickFromDateicon(Year,month,day,date)
		.clicktoDateicon(Year1,month1,day1,date1)
		.ClickGo()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
		
		
		
		
		
	}

}
