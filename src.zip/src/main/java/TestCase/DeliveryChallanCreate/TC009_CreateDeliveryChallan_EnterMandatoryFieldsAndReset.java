package TestCase.DeliveryChallanCreate;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC009_CreateDeliveryChallan_EnterMandatoryFieldsAndReset extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC007_CreateDeliveryChallan_EnterMandatoryFields";
		testDescription="EnterMandatoryFields";
		category="smoke";
		dataSource="Excel";
		dataSheetName="DC/TC007_CreateDeliveryChallan_EnterMandatoryFields";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String Year1, String month1, String day1, String date1) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDeliveryChallan()
		.clickCreate()
		.clickFromDateicon(Year,month,day,date)
		.clicktoDateicon(Year1,month1,day1,date1)
		.typeAndChooseDAType()
		.ClickReset();
		
		
		
		
		
	}

}
