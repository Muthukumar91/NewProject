package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class DespatchAdviceReport extends AbstractPage  {

public DespatchAdviceReport(){
	

		PageFactory.initElements(driver, this);

}
@FindBy(how=How.ID,using="txtOrderNumber")

public WebElement eleOrderNumber;
public DespatchAdviceReport TypeOrderNumber(String data){
	typeAndChoose(eleOrderNumber, data);
	return this;
}

@FindBy(how=How.ID,using="txtConsignee")

public WebElement eletxtConsignee;
public DespatchAdviceReport TypeConsignee(String data){
	try {
		typeAndChoose(eletxtConsignee,data);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return this;
}
@FindBy(how=How.XPATH,using="//span[text()='Select DA Number']/..")

public WebElement eleDANumber;
public DespatchAdviceReport ClickDANumber(){
	click(eleDANumber);
	return this;
}
@FindBy(how=How.ID,using="ddlDANumber")

public WebElement eleddlDANumber;
public DespatchAdviceReport selectDANumber(int data){
	selectUsingIndex(eleddlDANumber, data);
	return this;
}
@FindBy(how=How.ID,using="btnGenerateReport")

public WebElement elebtnGenerateReport;
public DespatchAdviceReport ClickGenerateReport(){
	
	switchToFrame(locateElement("xpath", "//iframe[@class='fake']"));
	pause(2);
	click(elebtnGenerateReport);
	return this;
}

@FindBy(how=How.ID,using="lblwindowmsg")

public WebElement eleWindowMsg;
public DespatchAdviceReport VerifyWindowMsg(){
	String text = getText(eleWindowMsg);
	if(text.equals(text)) {
		reportStep("Text Matched", "Pass");
	}else {
		reportStep("Text Not Matched", "FAIL");
	}
	return this;
}


@FindBy(how=How.XPATH,using="//button[text()='Clear']")

public WebElement eleClear;
public DespatchAdviceReport ClickClear(){
	click(eleClear);
	return this;
}
@FindBy(how=How.XPATH,using="//input[@id='fromDate']/following::span")
public WebElement eleFromDateicon;
public DespatchAdviceReport clickFromDateicon(String Year, String month, String day, String date){
	pause(2);
	click(eleFromDateicon);
	pause(2);
	click(locateElement("xpath", "//div[@id='fromDate_dateview']//a[2]"));
	pause(2);
	click(locateElement("xpath", "//div[@id='fromDate_dateview']//a[2]"));
	pause(2);
	click(locateElement("linkText", Year));

	pause(2);
	click(locateElement("linkText", month));

	click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));


	return this;
}

@FindBy(how=How.ID,using="fromDate")

public WebElement eleFromDate;
public DespatchAdviceReport typeFromDate(String dataeleFromDate){
	type(eleFromDate, dataeleFromDate);
	return this;
}
@FindBy(how=How.ID,using="toDate")

public WebElement eleToDate;
public DespatchAdviceReport typeToDate(String dataeleToDate){
	type(eleToDate, dataeleToDate);
	return this;
}


@FindBy(how=How.XPATH,using="//input[@id='toDate']/following::span")
public WebElement eletoDateicon;
public DespatchAdviceReport clicktoDateicon(String Year, String month, String day, String date){
	pause(2);
	click(eletoDateicon);
	pause(2);
	click(locateElement("xpath", "//div[@id='toDate_dateview']//a[2]"));
	pause(2);
	click(locateElement("xpath", "//div[@id='toDate_dateview']//a[2]"));
	pause(2);
	click(locateElement("linkText", Year));

	pause(2);
	click(locateElement("linkText", month));

	List<WebElement> list = getEventDriver().findElements(By.xpath("//a[@data-value='"+Year+"/"+day+"/"+date+"']"));
	int size = list.size();
	System.out.println(size);
	try {
		if (size==0) {
			click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));
		}else if (size>=1) {
			click(locateElement("xpath", "(//a[@data-value='"+Year+"/"+day+"/"+date+"'])[1]"));
		}else {
			click(locateElement("xpath", "(//a[@data-value='"+Year+"/"+day+"/"+date+"'])[2]"));
		}
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	try {
		click(locateElement("xpath", "//div[@class='k-footer']/a"));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return this;
}

@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following::a")

public WebElement eleClose;
public DespatchAdviceReport ClickClose(){
	click(eleClose);
	return this;
}


}
