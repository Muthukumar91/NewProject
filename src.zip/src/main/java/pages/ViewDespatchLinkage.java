package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.When;



public class ViewDespatchLinkage extends AbstractPage  {
	String text;
	public List<String> text1, text2, text3;
	public ViewDespatchLinkage(){

		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="Create")

	public WebElement eleCreate;
	@When ("Click on Create")
	public CreateDespatchLinkage clickCreate(){
		click(eleCreate);
		return new CreateDespatchLinkage();
	} 

	/*@FindBy(how=How.CLASS_NAME,using="lti-mand")

	private WebElement eleMandate;

	public CreateDespatchLinkage verifyMandate(){
		if(getText(eleMandate).contains("*"))
			System.out.println("The "+ getText(locateElement("xpath", "//span[@class='lti-mand']/.."))+" is displayed as Mandatory field");
		return new CreateDespatchLinkage();
	}*/



	/*	@FindBy(how=How.ID,using="LinkageNo")

	public WebElement eleLinkageNo;

	public ViewDespatchLinkage typeLinkageNo(){
		String linkageNumber = new CreateDespatchLinkage().dialogMessage.replaceAll("Despatch Linkage Request  Created Succesfully!!", "");
		typeAndChoose(eleLinkageNo,linkageNumber);
		return this;
	}*/

	@FindBy(how=How.XPATH,using="//tr[@role='row']/td[@class='defaultWeight']/span/preceding::td[1]")
	public List<WebElement> ConsigneeDescription;
	public ViewDespatchLinkage gettextFromConsigneeDescription()
	{			String string = "";
	text1= new ArrayList<String>();
	for (WebElement ele : ConsigneeDescription) {

		text = ele.getText();
		text1.add(text);

		System.out.println("ConsigneeDescription for UI:" + text);

	}
	return this;
	}


	@FindBy(how=How.XPATH,using="//a[@class='ShowPopup']")
	public List<WebElement> LinkedQuantity;
	public ViewDespatchLinkage gettextFromLinkedQuantity()
	{			
		text1= new ArrayList<String>();
		for (WebElement ele : LinkedQuantity) {

			text = ele.getText();
			text1.add(text);

			System.out.println("LinkedQuantity for UI:" + text);

		}
		return this;
	}
	@FindBy(how=How.XPATH,using="(//tbody[@role='rowgroup'])[2]/tr/td[1]")
	public List<WebElement> AllDespatchLinkageNumber;
	@FindBy(how=How.XPATH,using="//span[@class='ui-button-icon ui-icon ui-icon-closethick']")
	public WebElement closebutton;

	@FindBy(how=How.XPATH,using="//a[@class='ShowPopup']")
	public List<WebElement>  clickLinkedQuantity;
	public ViewDespatchLinkage clickFirstLinkedQuantityAndLNValidation(String sql) {

		text1= new ArrayList<String>();
		for (WebElement ele : clickLinkedQuantity) {
			click(ele);
			//pause(2);
			for (WebElement webElement : AllDespatchLinkageNumber) {
				int size = AllDespatchLinkageNumber.size();
				if(size>5) {
					String text4 = getText(webElement);
					System.out.println("Text from UI : "+ text4);
					text1.add(text4);
					JavascriptExecutor js = (JavascriptExecutor) getDriver();
					js.executeScript("window.scrollBy(0,10)");
				}else
				{
					String text4 = getText(webElement);
					System.out.println("Text from UI : "+ text4);
					text1.add(text4);
				}

			}
			dbvalidation(sql);

			compareLinkageNumber();
			click(closebutton);
		}

		return this;

	}

	@FindBy(how=How.XPATH,using="//span[text()=' Linked Quantity']/following::td[2]")
	public List<WebElement> LinkedQuantityInGrid;

	@FindBy(how=How.ID,using="lblLinkedquantity")
	public WebElement LinkedQuantityTitle;

	public ViewDespatchLinkage clickHyperLinkLinkedQuantityAndQuantityValidation() {
		int total=0;

		for (WebElement ele : clickLinkedQuantity) {
			click(ele);
			//pause(2);
			for (WebElement webElement : LinkedQuantityInGrid) {
				int size = LinkedQuantityInGrid.size();
				String text4 = getText(webElement);
				int num = StringToInteger(text4);
				total=total+num;
				int quantity = StringToInteger(getText(LinkedQuantityTitle));
				if(quantity==total) {
					System.out.println("Quantity Matched");
				}else {
					System.out.println("Quantity Not Matched");
				}
				click(closebutton);
				total= total-total;
			}
		}
		return this;

	}

	@FindBys(@FindBy(how=How.XPATH,using="(//tbody[@role='rowgroup'])[2]/tr/td[1]"))
	public List<WebElement> DespatchLinkageNumber;
	public ViewDespatchLinkage gettextFromDespatchLinkageNumber()
	{			
		text1= new ArrayList<String>();
		for (WebElement ele : DespatchLinkageNumber) {

			text = ele.getText();
			text1.add(text);

			System.out.println("ConsigneeDescription for UI:" + text);

		}
		return this;
	}

	public ViewDespatchLinkage dbvalidation(String sql) {
		String string = "";
		text2= new ArrayList<String>();
		Object[][] dataFromDb = getDataFromDb(sql);
		for (Object[] objects : dataFromDb) {
			for (int i = 0; i < objects.length; i++) {
				string = objects[i].toString();
				text2.add(string);
				System.out.println("Text From DB:" +string);
			}


		}
		return this;

	}



	public ViewDespatchLinkage compareString() {
		if(text2.equals(text1)) {
			System.out.println("DB VALIDATION SUCCESSFULLY");	
		}else {
			System.out.println("DB VALIDATION FAILED");
		}
		return this;

	}
	public ViewDespatchLinkage compareLinkageNumber() {
		for (String text : text1) {
			
			if(text2.contains(text)) {
				System.out.println("DB VALIDATION SUCCESSFULLY");	
			}else {
				System.out.println("DB VALIDATION FAILED");
			}
		}
		
		return this;
		
	}

	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	@When ("The orderNumber entered")
	public ViewDespatchLinkage typeOrderNumber(String orderNumber){
		typeAndChoose(eleOrderNumber,orderNumber);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='OrderNumber']/../following-sibling::i")

	public WebElement eleOrderinfo;
	public ViewDespatchLinkage clickOrderinfoBefore(String dataWarningMessage){
		click(eleOrderinfo);
		String text4 = getText(locateElement("xpath", "//i[@data-original-title='Order Details']//following::div[3]/div"));
		/*if (text4.equals(dataWarningMessage)) {
			reportStep("Text Message Correct", "Pass");
		}else {
			reportStep("Text message incorrect", "Fail");
		}*/
		return this;
	}
	

	public ViewDespatchLinkage clickOrderinfoAfter(String dataWarningMessage){
		click(eleOrderinfo);
		String text4 = getText(locateElement("xpath", "//h3[text()='Order Details']/following::td[2]"));
		if (text4.equals(dataWarningMessage)) {
			reportStep("Text Message Correct", "Pass");
		}else {
			reportStep("Text message incorrect", "Fail");
		}
		return this;
	}
	
	



	@FindBy(how=How.XPATH,using="//input[@id='ConsigneeCode']/../following-sibling::i")

	public WebElement eleConsigneeinfo;
	public ViewDespatchLinkage clickConsigneeInfoBefore(String dataWarningMessage){
		click(eleConsigneeinfo);
		String text4 = getText(locateElement("xpath", "//h3[text()='Consignee Details']/following::div/div"));
	/*	if (text4.equals(dataWarningMessage)) {
			reportStep("Text Message Correct", "Pass");
		}else {
			reportStep("Text message incorrect", "Fail");
		}*/
		return this;
	}
	public ViewDespatchLinkage clickConsigneeInfoAfter(String dataWarningMessage){
		click(eleConsigneeinfo);
		String text4 = getText(locateElement("xpath", "//h3[text()='Consignee Details']/following::div"));
		if (text4.contains(dataWarningMessage)) {
			reportStep("Text Message Correct", "Pass");
		}else {
			reportStep("Text message incorrect", "Fail");
		}
		return this;
	}

	@FindBy(how=How.ID,using="ConsigneeCode")

	public WebElement eleConsignee;
	@When ("Enter the  Consignee Code")
	public ViewDespatchLinkage typeConsignee(String consigneeNum){
		typeAndChoose(eleConsignee,"43498");
		return this;
	}

	@FindBy(how=How.ID,using="LinkageNo")

	public WebElement eleLinkageNo;
	@When ("Enter the  Consignee Code")
	public ViewDespatchLinkage typeLinkageNo(String code){
		typeAndChoose(eleLinkageNo,"TPY18DL-0000033");
		return this;
	}

	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleGo;
	public ViewDespatchLinkage clickgo(){
		click(eleGo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='items per page']/span/span")

	public WebElement itemsPerPage;
	public ViewDespatchLinkage clickItemsPerPage(String page){
		click(itemsPerPage);
		pause(1);
		click(locateElement("xpath", "//li[text()='"+page+"']"));
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@id='LinkageDetails']/div[3]/span[1]/input")

	public WebElement itemsinput;
	public ViewDespatchLinkage EnterPageNumber(String data){
		click(itemsinput);
		pause(1);
		itemsinput.sendKeys(Keys.BACK_SPACE);
		itemsinput.sendKeys(Keys.DELETE);
		typeandEnter(itemsinput, data);

		return this;
	}
	


	@FindBy(how=How.XPATH,using="//div[@id='LinkageDetails']/div[3]/span[1]")
	public WebElement totalpage;
	@FindBy(how=How.XPATH,using="//div[@id='LinkageDetails']/div[3]//li[1]/a")
	public WebElement pageindex;
	public ViewDespatchLinkage ClickNextPage(){
		String pages = getText(totalpage).replaceAll("\\D", "");
		int page = StringToInteger(pages);
		if(page>1) {
			click(locateElement("xpath", "//a[@title='Go to the next page']"));
		}
		return this;
	}

	public ViewDespatchLinkage ClickPreviousPage(){
		click(locateElement("xpath", "//a[@title='Go to the previous page']"));
	
		return this;
	}
	public ViewDespatchLinkage ClickLastPage(){
		click(locateElement("xpath", "//a[@title='Go to the previous page']"));
	
		return this;
	}
	public ViewDespatchLinkage ClickFirstPage(){
		click(locateElement("xpath", "//a[@title='Go to the first page']"));
	
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@class='lti-alert-msg']/label")
	WebElement errorValidation;

	@FindBy(how=How.XPATH,using="(//tbody[@role='rowgroup'])[2]//b")
	WebElement errorMessageValidation;

	public ViewDespatchLinkage errorMessageValidation(String message)
	{
		if(verifyText(errorValidation, message)==true) {
			System.out.println("Text matched");
		}else {
			System.out.println("Text not matched");
		}


		return this;
	}





	public ViewDespatchLinkage NoRecordsValidation(String message)
	{
		if(verifyText(errorMessageValidation, message)==true) {
			System.out.println("Text matched");
		}else {
			System.out.println("Text not matched");
		}


		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@id='LinkageDetails']//tbody/tr")
	List<WebElement> elerecords;

	public int getNumberOfDispatchRecords()
	{
		System.out.println("rows are"+elerecords.size());
		return elerecords.size();
	}

	@FindBy(how=How.XPATH,using="//div[@id='ShowPopup']//tbody/tr")
	List<WebElement> elerecordsHyperLink;

	public int getNumberOfDispatchRecordsInHyperLink()
	{
		System.out.println("rows are"+elerecordsHyperLink.size());
		return elerecordsHyperLink.size();
	}


	public ViewDespatchLinkage clickLinkedQuantity(){

		int rows = getNumberOfDispatchRecords();

		for (int i = 1; i <= rows; i++) {

			click(locateWebTableElement("Linked", i));
			click(locateElement("xpath", "//button[text()='Close']"));
		}


		return this;
	}



	@FindBy(how=How.XPATH,using="//span[text()='Close']/..")

	public WebElement eleError;
	public ViewDespatchLinkage CloseError(){
		click(eleError);
		return this;
	}

	@FindBy(how=How.ID,using="btnReset")

	public WebElement eleReset;
	public ViewDespatchLinkage clickReset(){
		click(eleReset);
		return this;
	}


	@FindBy(how=How.XPATH,using="//button[text()='Yes']")

	public WebElement eleYes;
	public ViewDespatchLinkage clickBtnYes(){
		click(eleYes);
		return this;
	}

	@FindBy(how=How.ID,using="btnno")

	public WebElement eleBtnNO;
	public ViewDespatchLinkage clickBtnNO(){
		click(eleBtnNO);
		return this;
	}
	
	
	public ViewDespatchLinkage ResetVerification() {
		String attribute = eleOrderNumber.getAttribute("aria-busy");		
		if(attribute.equals(null)) {
			reportStep("Value Cleared", "Pass");
		}else if(attribute.equals("false")) {
			reportStep("Value not Cleared", "Pass");
		}else {
			reportStep("Value not Cleared", "Fail");
		}
		return this;
		
	}
	
	@FindBy(how=How.XPATH,using="//span[@class='k-pager-info k-label']")
	public WebElement itemsInTheGrid;
	public ViewDespatchLinkage getitemsInTheGrid() {
		String items = getText(itemsInTheGrid);
		if (items.equals("No items to display")) {
			reportStep("No Record", "Pass");	
		}else {
			reportStep("Records Obtained", "Pass");
		}
		return this;
		
	}
	
	

}

