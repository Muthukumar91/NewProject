package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;


public class LoginPage extends AbstractPage{
	
	String sessionId ="";

	public LoginPage() {
		System.out.println("page factory");
		PageFactory.initElements(getEventDriver(), this);
	}

	@FindBy(how = How.ID, using = "txtUserName")
	private WebElement eleUName;

	@FindBy(how = How.ID, using = "txtPassword")
	private WebElement elePassword;

	@FindBy(how = How.ID, using = "btnLogin")
	private WebElement eleLogin;
	
	@FindBy(how = How.XPATH, using = "//a[@class='bottom showroles']/i")
	private WebElement eleManIcon;

	public LoginPage enterUserName(String data) {
		System.out.println("username");
		typeAndTab(eleUName, data);
		return this;
	}

	public LoginPage enterPassword(String data) {
		System.out.println(getAttributeText(elePassword, "value").trim());
		if(getAttributeText(elePassword, "value").trim().equals(""))
			type(elePassword, data);
		pause(2);
		return this;
	}

	public LeftMenuPage clickLogin(String OrderNumber) {
		OrderNumber="TPR180341";
		click(eleLogin);
		pause(5);
		String currentUrl = getEventDriver().getCurrentUrl();		
		if(currentUrl.contains(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=")) {
			sessionId = currentUrl.replace(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=", "");
		}
		getEventDriver().get(config.getProperty("URL")+"/EIPPDSS/CommonGetSession.aspx?strpage=PDSHome/PDSHome&SessionID="+sessionId);
		pause(5);
		String Url = getEventDriver().getCurrentUrl();
		if(Url.contains("https://eip-tb.lntecc.com/EIPPDSS/PDSHome/PDSSError")) {
			getEventDriver().get(config.getProperty("URL"));
			pause(2);
			enterUserName("sbkms");
			pause(1);
			enterPassword("Welcome@018");
			click(eleLogin);
			String current = getEventDriver().getCurrentUrl();		
			if(current.contains(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=")) {
				sessionId = current.replace(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=", "");
			}
			getEventDriver().get(config.getProperty("URL")+"/EIPPDSS/CommonGetSession.aspx?strpage=PDSHome/PDSHome&SessionID="+sessionId);
			pause(5);
		}
		
		 if(OrderNumber.contains("TPR")) {
			 click(eleManIcon);
			 pause(2);
			 click(locateElement("id", "pdssFactory"));
			 pause(2);
			 click(locateElement("xpath", "//label[text()='Transmission Line Tower Factory (TLT) � Pondicherry']"));
			 
		 }else {
			 click(eleManIcon);
			 pause(2);
			 click(locateElement("id", "pdssFactory"));
			 pause(2);
			 click(locateElement("xpath", "//label[text()='EWL Factory']"));
			 
		 }
		return new LeftMenuPage();
	}
	
	public void loginfailure() {
		String Url = getEventDriver().getCurrentUrl();
		if(Url.contains("https://eip-tb.lntecc.com/EIPPDSS/PDSHome/PDSSError")) {
			getEventDriver().get(config.getProperty("URL"));
			pause(2);
			enterUserName("sbkms");
			pause(1);
			enterPassword("Welcome@018");
			click(eleLogin);
		}
		
	}
	
	public LeftMenuPage clickLogin() {
		
		click(eleLogin);
		pause(5);
		String currentUrl = getEventDriver().getCurrentUrl();		
		if(currentUrl.contains(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=")) {
			sessionId = currentUrl.replace(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=", "");
		}
		getEventDriver().get(config.getProperty("URL")+"/EIPPDSS/CommonGetSession.aspx?strpage=PDSHome/PDSHome&SessionID="+sessionId);
		pause(5);
		 
		return new LeftMenuPage();
	}
	
public LeftMenuPage clickLoginForChrome() {
		
		click(eleLogin);
		pause(5);
		String currentUrl = getEventDriver().getCurrentUrl();	
		if(currentUrl.contains(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=")) {
			sessionId = currentUrl.replace(config.getProperty("URL")+"/MemberPage/ESMMgmt.aspx?SessionID=", "");
		}
		getEventDriver().get(config.getProperty("URL")+"/EIPPDSS/CommonGetSession.aspx?strpage=PDSHome/PDSHome&SessionID="+sessionId);
		pause(5);
		return new LeftMenuPage();
	}
public LeftMenuPage clickLoginForChrome(String OrderNumber) {
	click(eleLogin);
	pause(2);
	new Actions(getEventDriver()).moveToElement(locateElement("xpath", "//input[@src='../images/BSS.png']")).click().perform();
	pause(2);
	new Actions(getEventDriver()).moveToElement(locateElement("xpath", "//input[@title='Manufacturing Orders']")).click().perform();
		
	if(OrderNumber.contains("TPR")) {
		 click(eleManIcon);
		 pause(2);
		 click(locateElement("id", "pdssFactory"));
		 pause(2);
		 click(locateElement("xpath", "//label[text()='Transmission Line Tower Factory (TLT) � Pondicherry']"));
		 
	 }else {
		 click(eleManIcon);
		 pause(2);
		 click(locateElement("id", "pdssFactory"));
		 pause(2);
		 click(locateElement("xpath", "//label[text()='EWL Factory']"));
		 
	 }
		return new LeftMenuPage();
	}


public LoginPage InvalidCredentials()
{
	
	click(eleLogin);
	return this;
}

public LoginPage AcceptalertforInvalidCredentials()
{
	
	acceptAlert();
	return this;
}

public LoginPage AlertTextLoginpage(String TextData)
{
	
	String textAlert = getTextAlert();
	if( textAlert.equalsIgnoreCase(TextData))
	{
		reportStep("Alert Text is  " +textAlert, "PASS");
	}
	
	else
	{
		reportStep("Alert Text is  " +textAlert, "FAIL");
	}
	return this;
}

}
