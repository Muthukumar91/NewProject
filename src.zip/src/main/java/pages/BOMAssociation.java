package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;



public class BOMAssociation extends AbstractPage  {
	
	
	public BOMAssociation(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="Create")
	public WebElement eleCreate;
	public BOMAssociation clickCreate(){
		pause(2);
		click(eleCreate);
		pause(2); 
		return this;
	}
	
	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	public BOMAssociation TypeOrderNumber(){
		String data=WindowMessage;
		System.out.println(data);
	
		typeAndChoose(eleOrderNumber, data);
		return this;
	}
	
	public BOMAssociation TypeOrderNumber(String data){
		
		pause(2);
		typeAndChoose(eleOrderNumber, data);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//span[@aria-owns='ProductCode_listbox']")

	public WebElement eleProductCode;
	public BOMAssociation SelectProductCode(){
		click(eleProductCode);
		pause(2);
		click(locateElement("xpath", "//ul[@id='ProductCode_listbox']/li[3]"));
		
		return this;
	}
	
	
	public BOMAssociation SelectProductCodeDesign(){
		click(eleProductCode);
		pause(2);
		click(locateElement("xpath", "//ul[@id='ProductCode_listbox']/li[4]"));
		
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='AssociationType_listbox']")

	public WebElement eleAssociationType;
	public BOMAssociation SelectAssociationType(){
		click(eleAssociationType);
		pause(2);
		click(locateElement("xpath", "//ul[@id='AssociationType_listbox']/li[4]"));
		
		return this;
	}
	
	public BOMAssociation SelectAssociationTypeWelding(){
		click(eleAssociationType);
		pause(2);
		click(locateElement("xpath", "//ul[@id='AssociationType_listbox']/li[2]"));
		
		return this;
	}
	
	public BOMAssociation SelectAssociationTypeAssembly(){
		click(eleAssociationType);
		pause(2);
		click(locateElement("xpath", "//ul[@id='AssociationType_listbox']/li[3]"));
		click(locateElement("xpath", "//input[@value='Yes']"));
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']//tbody//tr[1]")

	public WebElement eleFirstPart;
	public BOMAssociation ClickFirstPart(){
		try {
			click(eleFirstPart);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@title='Move to Right']")

	public WebElement eleMovetoRight;
	public BOMAssociation clickMovetoRight(){
		click(eleMovetoRight);
		return this;
	}
	
	
	
	
	
	@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Right']")

	public WebElement eleMoveAll;
	public BOMAssociation clickMoveAll(){
		pause(2);
		try {
			click(eleMoveAll);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return this;
	}
	
	@FindBy(how=How.ID,using="SubmitAssociation")

	public WebElement eleSubmitAssociation;
	public BOMAssociation clickSubmit(){
	
		click(eleSubmitAssociation);
			return this;
	}
	@FindBy(how=How.ID,using="PartCode")

	public WebElement elePartCode;
	public BOMAssociation SelectPartCode(String data){
		try {
			clear(elePartCode);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		click(elePartCode);
		typeAndChoose(elePartCode, data);
			return this;
	}
	
	

	
		
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following::a")

	public WebElement eleclose;
	public BOMAssociation ClickClose(){

		try {
			click(eleclose);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		
		return this;
	}
	
	
	@FindBy(how=How.ID,using="Search")
	public WebElement eleSearch;
	public BOMAssociation TypeSearch(String data){
	type(eleSearch, data);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@id='kendoWindowRedirect_wnd_title']/following::a")

	public WebElement elecloseSuccess;
	public BOMAssociation ClickCloseSucess(){

		try {
			click(elecloseSuccess);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		
		return this;
	}
	
	@FindBy(how=How.ID,using="btnno")
	public WebElement elebtnno;
	public BOMAssociation clickNO(){
		pause(2);
		click(elebtnno);
		getEventDriver().navigate().refresh();
		return this;
	}
	
	@FindBy(how=How.ID,using="btnyes") 
	public WebElement elebtnyes;
	public BOMAssociation clickYes(){
		pause(2);
		click(elebtnyes);
		pause(2);
		//getEventDriver().navigate().refresh();
		return this;
	}
	@FindBy(how=How.ID,using="chkASelectAll")

	public WebElement elechkASelectAll;
	public BOMAssociation ClickChkASelectAll(){
		pause(2);
		try {
			click(elechkASelectAll);
			click(locateElement("xpath", "//input[@type='checkbox']"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='APPROVE']")

	public WebElement eleAPPROVE;
	public BOMAssociation ClickAPPROVE(){

		click(eleAPPROVE);
		pause(2);
		
		return this;
	}
	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;
		public LeftMenuPage clickNavigation() {
		pause(2);
		click(eleNavigation); 
		return new LeftMenuPage(); 
	}
	
	}

	

