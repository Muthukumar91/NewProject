package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.nimbusds.openid.connect.sdk.id.PairwiseSubjectIdentifierGenerator;

import cucumber.api.java.en.And;



public class ProcessFlow extends AbstractPage  {
	
	
	public ProcessFlow(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="Create")
	public WebElement eleCreate;
	public ProcessFlow clickCreate(){
		pause(2);
		click(eleCreate);
		pause(2); 
		return this;
	}
	
	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	public ProcessFlow TypeOrderNumber(){
		String data=WindowMessage;
		System.out.println(data);
	
		typeAndChoose(eleOrderNumber, data);
		pause(2);
		return this;
	}
	
	public ProcessFlow TypeOrderNumber(String data){
		
		typeAndChoose(eleOrderNumber, data);
		pause(2);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='ProductCode_listbox']")

	public WebElement eleProductCode;
	public ProcessFlow SelectProductCode(){
		click(eleProductCode);
		pause(2);
		click(locateElement("xpath", "//ul[@id='ProductCode_listbox']/li[3]"));
		
		return this;
	}	
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='PartType_listbox']")

	public WebElement elePartType;
	public ProcessFlow SelectPartType(){
		click(elePartType);
		pause(2);
		click(locateElement("xpath", "//ul[@id='PartType_listbox']/li[2]"));
		
		return this;
	}	
	public ProcessFlow SelectPartTypeWelding(){
		click(elePartType);
		pause(2);
		click(locateElement("xpath", "//ul[@id='PartType_listbox']/li[3]"));
		
		return this;
	}
	
	public ProcessFlow SelectPartTypeAssembly(){
		click(elePartType);
		pause(2);
		click(locateElement("xpath", "//ul[@id='PartType_listbox']/li[4]"));
		
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//header[text()='Part Code']/../input")

	public WebElement elePartCode;
	public ProcessFlow clickPartCode(){
		click(elePartCode);
		
		
		return this;
	}	
	
	@FindBy(how=How.ID,using="All")
	public WebElement eleSearch;
	public ProcessFlow TypeSearch(String data){
		try {
			clear(eleSearch);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		click(eleSearch);
		type(eleSearch, data);
		pause(1);
		click(locateElement("xpath", "//h3[text()='Operations']/following::li/header[@data-opercode='"+data+"']"));
		
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='SUBMIT']")

	public WebElement eleSubmitAssociation;
	public ProcessFlow clickSubmit(){
	
		click(eleSubmitAssociation);
			return this;
	}
	
	@FindBy(how=How.ID,using="btnyes") 
	public WebElement elebtnyes;
	public ProcessFlow clickYes(){
		pause(2);
		click(elebtnyes);
		pause(2);
		
		return this;
	}
	@FindBy(how=How.ID,using="authorize")
	public WebElement eleAuthorize;
	public ProcessFlow clickAuthorize(){
		pause(2);
		click(eleAuthorize);
		pause(2); 
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@id='PFApproval']//thead//th/input")

	public WebElement eleCheckAll;
	public ProcessFlow clickCheckAll(){
	
		try {
			click(eleCheckAll);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='APPROVE']")

	public WebElement eleApprove;
	public ProcessFlow clickApprove(){
	
		click(eleApprove);
			return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following::a")

	public WebElement eleclose;
	public ProcessFlow ClickClose(){

		try {
			click(eleclose);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		
		return this;
	}
	
	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;
	
	@And ("Click on Despatch Menu Item")
	public LeftMenuPage clickNavigation() {
		pause(2);
		click(eleNavigation); 
		return new LeftMenuPage(); 
	}
	
	
}

	

