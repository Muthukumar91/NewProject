package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.nimbusds.openid.connect.sdk.id.PairwiseSubjectIdentifierGenerator;

import cucumber.api.java.en.And;



public class RouteCardGeneration extends AbstractPage  {
	
	
	public RouteCardGeneration(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="Create")
	public WebElement eleCreate;
	public RouteCardGeneration clickCreate(){
		pause(2);
		click(eleCreate);
		pause(2); 
		return this;
	}
	
	
	
	
	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	public RouteCardGeneration TypeOrderNumber(){
		String data=WindowMessage;
		System.out.println(data);
	
		typeAndChoose(eleOrderNumber, data);
		pause(2);
		return this;
	}
	
	public RouteCardGeneration TypeOrderNumber(String data){
		
		typeAndChoose(eleOrderNumber, data);
		pause(2);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='ProductCode_listbox']")

	public WebElement eleProductCode;
	public RouteCardGeneration SelectProductCode(){
		click(eleProductCode);
		pause(2);
		click(locateElement("xpath", "//ul[@id='ProductCode_listbox']/li[2]"));
		
		return this;
	}	
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='ProductLOTNumber_listbox']")

	public WebElement eleLotNumber;
	public RouteCardGeneration SelectLotNumber(){
		click(eleLotNumber);
		pause(2);
		click(locateElement("xpath", "//ul[@id='ProductLOTNumber_listbox']/li[2]"));
		
		return this;
	}	
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='RCType_listbox']")

	public WebElement eleRCType;
	public RouteCardGeneration SelectRCType(){
		click(eleRCType);
		pause(2);
		click(locateElement("xpath", "//ul[@id='RCType_listbox']/li[6]"));
		
		return this;
	}	
	
	
	@FindBy(how=How.ID,using="RawMaterial")

	public WebElement eleRawMaterial;
	public RouteCardGeneration TypeRawMaterial(){
	typeAndChoose(eleRawMaterial, "112510010");
		
		
		return this;
	}	
	@FindBy(how=How.ID,using="BatchQuantity")

	public WebElement eleBatchQuantity;
	public RouteCardGeneration TypeBatchQuantity(){
	typeAndChoose(eleBatchQuantity, "10");
		
		
		return this;
	}	
	
	@FindBy(how=How.XPATH,using="//div[@id='PartCart']/button")

	public WebElement elepartcode;
	public RouteCardGeneration clickPartCode(){
	
		click(elepartcode);
		pause(2);
		click(locateElement("id", "btnContentavailablejob"));
		pause(1);
		click(locateElement("id", "btnContentpost"));
			return this;
	}
	
	
	
	
	@FindBy(how=How.ID,using="All")
	public WebElement eleSearch;
	public RouteCardGeneration TypeSearch(String data){
		try {
			clear(eleSearch);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		click(eleSearch);
		type(eleSearch, data);
		pause(1);
		click(locateElement("xpath", "//h3[text()='Operations']/following::li/header[@data-opercode='"+data+"']"));
		
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='Submit']")

	public WebElement eleSubmitAssociation;
	public RouteCardGeneration clickSubmit(){
	
		click(eleSubmitAssociation);
			return this;
	}
	
	@FindBy(how=How.ID,using="btnyes") 
	public WebElement elebtnyes;
	public RouteCardGeneration clickYes(){
		pause(2);
		click(elebtnyes);
		pause(2);
		
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following::a")

	public WebElement eleclose;
	public RouteCardGeneration ClickClose(){

		try {
			click(eleclose);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindowRedirect_wnd_title']/following::a")

	public WebElement elecloseSuccess;
	public RouteCardGeneration ClickCloseSucess(){

		try {
			click(elecloseSuccess);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		
		return this;
	}
	
	
	
	
}

	

