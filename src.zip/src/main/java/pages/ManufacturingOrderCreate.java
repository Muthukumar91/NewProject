package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;



public class ManufacturingOrderCreate extends AbstractPage  {
	
	
	public ManufacturingOrderCreate(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="Create")
	public WebElement eleCreate;
	public ManufacturingOrderCreate clickCreate(){
		pause(2);
		click(eleCreate);
		pause(2); 
		return this;
	}
	
	@FindBy(how=How.ID,using="JobOrders_OrderDescription")

	public WebElement eleJobOrdersOrderDescription;
	public ManufacturingOrderCreate TypeJobOrdersDescription(String data){
		pause(2);
		type(eleJobOrdersOrderDescription, data);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='JobOrders_OrderTypeCode_listbox']/span")

	public WebElement eleOrderType;
	public ManufacturingOrderCreate SelectOrderType(){
		pause(2);
		click(eleOrderType);
		pause(2);
		click(locateElement("xpath", "//li[text()='Regular']"));
		return this;
	}
	
	@FindBy(how=How.ID,using="JobOrders_JobCode")

	public WebElement eleJobCode;
	public ManufacturingOrderCreate TypeJobCode(String data){
		typeAndChoose(eleJobCode, data);
		pause(2);
		return this;
	}
	
	@FindBy(how=How.ID,using="JobOrders_CustomerCode")

	public WebElement eleCustomerCode;
	public ManufacturingOrderCreate TypeCustomerCode(String data){
		try {
			pause(2);
			typeAndChoose(eleCustomerCode, data);
	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		return this;
	}
	
	@FindBy(how=How.ID,using="JobOrders.ClientOrderNumber")

	public WebElement eleClientOrderNumber;
	public ManufacturingOrderCreate TypeClientOrderNumber(String data){
	
		type(eleClientOrderNumber, data);
		pause(2);

		return this;
	}
	
	@FindBy(how=How.ID,using="JobOrders_ClientOrderDate")

	public WebElement eleClientOrderDate;
	public ManufacturingOrderCreate TypeClientOrderDate(String data){
		
		try {
			type(eleClientOrderDate, data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@id='TechnicalButton']/following::button")

	public WebElement eleDespatch;
	public ManufacturingOrderCreate ClickDespatch(){

		try {
			click(eleDespatch);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[@id='TechnicalButton']/following::button[2]")

	public WebElement eleCommercial;
	public ManufacturingOrderCreate ClickCommercial(){
		
		try {
			click(eleCommercial);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Submit']")

	public WebElement eleSubmit;
	public ManufacturingOrderCreate ClickSubmit(){
		
		click(eleSubmit);
		
		return this;
	}
	
	@FindBy(how=How.ID,using="txtDescription")

	public WebElement eleInvoiceMessage;
	public ManufacturingOrderCreate TypeInvoiceMessage(String data){
		
		type(eleInvoiceMessage, data);
		return this;
	}
	
	@FindBy(how=How.ID,using="txtShippingMark")

	public WebElement eleShippingMark;
	public ManufacturingOrderCreate TypeShippingMark(String data){
		
		type(eleShippingMark, data);
		return this;
	}
	
	@FindBy(how=How.ID,using="txtExportInvoiceDescription")

	public WebElement eleExportInvoiceDescription;
	public ManufacturingOrderCreate TypeExportInvoiceDescription(String data){
		
		type(eleExportInvoiceDescription, data);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//button[text()='OK'])[3]")

	public WebElement eleOK;
	public ManufacturingOrderCreate ClickOK(){
		
		click(eleOK);
		pause(2);
		
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@placeholder='Enter Order Value']/..")

	public WebElement eleEnterOrderValue;
	public ManufacturingOrderCreate TypeEnterOrderValue(String data){
		
		click(eleEnterOrderValue);
		pause(2);
		try {
			locateElement("xpath", "//input[@placeholder='Enter Order Value']/following::input").sendKeys(Keys.BACK_SPACE,Keys.DELETE);
			
			locateElement("xpath", "//input[@placeholder='Enter Order Value']/following::input").sendKeys(data);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='JobOrders_CurrencyCode_listbox']")

	public WebElement eleCurrency;
	public ManufacturingOrderCreate ClickCurrency(){
		
		try {
			click(eleCurrency);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(3);
		locateElement("xpath", "//li[text()='INR-Indian rupee']").click();
		
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@aria-owns='CommercialDetails_BillingTypeCode_listbox']/span")

	public WebElement eleBillingType;
	public ManufacturingOrderCreate ClickBillingType(){
		
		try {
			click(eleBillingType);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		locateElement("xpath", "//li[text()='Direct Billing']").click();
		
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//button[text()='OK']")

	public WebElement eleCommericalOK;
	public ManufacturingOrderCreate ClickCommericalOK(){
		
		click(eleCommericalOK);
		pause(2);
		
		return this;
	}
	
	@FindBy(how=How.ID,using="lblwindowmsg")

	public WebElement elelblwindowmsg;
	public ManufacturingOrderCreate getWindowMsg(){
		pause(2);
		
		String substring = getText((elelblwindowmsg));
		 WindowMessage = substring .substring(6, 15);
		System.out.println(WindowMessage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following::a")

	public WebElement eleclose;
	public ManufacturingOrderCreate ClickClose(){
		
		click(eleclose);
		pause(2);
		
		
		return this;
	}
	

	@FindBy(how=How.ID,using="Authorize")

	public WebElement eleAuthorize;
	public ManufacturingOrderCreate ClickAuthorize(){
		pause(2);
		click(eleAuthorize);
		pause(2);
		return this;
	}
	
	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	public ManufacturingOrderCreate TypeOrderNumber(){
		pause(2);
		typeAndChoose(eleOrderNumber, WindowMessage);
		
		return this;
	}
	

	@FindBy(how=How.ID,using="submit")

	public WebElement elesubmit;
	public ManufacturingOrderCreate Clicksubmit(){
		pause(2);
		click(elesubmit);
		
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//div[@id='OrderDetails']//tbody/tr") 
	private List<WebElement> eleNoOfProductDetails;
	private int noOfRecordsInGrid;
	public ManufacturingOrderCreate getNoOfProductdetails() {
		noOfRecordsInGrid=eleNoOfProductDetails.size();
		System.out.println("The no of records in the grid are "+eleNoOfProductDetails.size());
		return this;

	}
	public int getReworkQuantity(int i){

		System.out.println("The quantity is"+getText(locateWebTableElement("Sale Rate", i)));

		int canLinkQty = Integer.parseInt(getText(locateWebTableElement("Sale Rate", i)));


		return canLinkQty;
	}

	public ManufacturingOrderCreate ClickAuthoriz(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			locateWebTableElement("UOM", i);
			int columnIndexreworkQuantity6=getEventDriver().findElements(By.xpath("//*[text()='Authorize']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity6);
			WebElement Authorize = getEventDriver().findElement(By.xpath("//*[text()='Authorize']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity6+"]/input"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			click(Authorize);
			pause(1);
		}
	
	
			return this;
		}
	
	@FindBy(how=How.ID,using="chkASelectAll")

	public WebElement elechkASelectAll;
	public ManufacturingOrderCreate ClickChkASelectAll(){
		pause(2);
		click(elechkASelectAll);
		
		return this;
	}
	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;
		public LeftMenuPage clickNavigation() {
		pause(2);
		click(eleNavigation); 
		return new LeftMenuPage(); 
	}
	
	
	}

	

