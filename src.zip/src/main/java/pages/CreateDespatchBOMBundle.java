package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Sleeper;

import cucumber.api.java.en.When;

public class CreateDespatchBOMBundle extends AbstractPage {
	public static String dialogMessage,dialogTitle;
	private int panelPartrs,bundleParts;
		public CreateDespatchBOMBundle(){
			PageFactory.initElements(getEventDriver(), this);
		}
		
		@FindBy(how=How.CLASS_NAME,using="mandatory-star")
		private List<WebElement> eleMandatory;

		public CreateDespatchBOMBundle verifyMandatoryFields()
		{
			String[] elements = {"Order Number ","Product Code ","Panel Code "};
			System.out.println(verifyMandatory(elements));
			return this;

		}
		@FindBy(how=How.ID,using="update")
	    private WebElement eleEdit;
	
		public EditDespatchBomBundle clickEdit(){
		
			click(eleEdit);
			return new EditDespatchBomBundle();
		}
		
		@FindBy(how=How.ID,using="view")
	    private WebElement eleView;
	
		public ViewDespatchBOMBundle clickView(){
		
			click(eleView);
			return new ViewDespatchBOMBundle();
		}
		
		@FindBy(how=How.ID,using="authorize")
	    private WebElement eleApprove;
	
		public CreateDespatchBOMBundle clickApprove(){
		
			click(eleApprove);
			return this;
		}
		@FindBy(how=How.ID,using="help")
	    private WebElement eleHelp;

		public CreateDespatchBOMBundle clickHelp(){
		
			click(eleHelp);
			return this;
		}
		@FindBy(how=How.ID,using="OrderNumber")
	    private WebElement eleOrderNumber;
	
		public CreateDespatchBOMBundle typeOrderNumber(String dataOrderNumber){
		
			typeAndChoose(eleOrderNumber, dataOrderNumber);
			return this;
		}
		
		@FindBy(how=How.XPATH,using="//input[@id='Product']/preceding-sibling::span/span[@class='k-select']/span")

		public WebElement eleProductCodeDd;
		public CreateDespatchBOMBundle clickProductCodeDd(){
			click(eleProductCodeDd);
			return this;
		}
		
		
		public CreateDespatchBOMBundle selectProductCode(String productCode){
			selectUsingText(locateElement("xpath", "//li[text()='"+productCode+"']"), productCode);
			return this;
		}
		
		
		@FindBy(how=How.XPATH,using="//input[@id='PanelCode']/preceding-sibling::span/span[@class='k-select']/span")

		public WebElement elePanelCodeDd;
		public CreateDespatchBOMBundle clickPanelCodeDd(){
			click(elePanelCodeDd);
			return this;
		}
		
		
		public CreateDespatchBOMBundle selectPanelCode(String panelCode){
			selectUsingText(locateElement("xpath", "//li[text()='"+panelCode+"']"), panelCode);
			return this;
		}
		
		@FindBy(how=How.ID,using="BundleCode")
		private WebElement eleBundleCode;
		public CreateDespatchBOMBundle getBundleCode(){
			System.out.println("The Auto generated Bundle code is "+eleBundleCode.getAttribute("value"));
			return this;
		}
		
		
		@FindBy(how=How.XPATH,using="//input[@id='BundleType']/preceding-sibling::span/span[@class='k-select']/span")

		public WebElement eleBundleTypeDd;
		public CreateDespatchBOMBundle clickBundleTypeDd(){
			click(eleBundleTypeDd);
			return this;
		}
		
		@FindBy(how=How.XPATH,using="//input[@id='BundleType']/preceding-sibling::span/span[@class='k-select']/preceding-sibling::span")

		public WebElement eleBundleType;
		public CreateDespatchBOMBundle getSelectedBundleType(){
			System.out.println("The selected Bundle type is "+getText(eleBundleType));
			return this;
		}
		public CreateDespatchBOMBundle selectBundleType(String bundleType){
			selectUsingText(locateElement("xpath", "//li[text()='"+bundleType+"']"), bundleType);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return this;
		}
		
		@FindBy(how=How.ID,using="SubmitAssociation")

		public WebElement eleSubmit;
		public CreateDespatchBOMBundle clickSubmit(){
			click(eleSubmit);
			return this;
		}
		
		@FindBy(how=How.XPATH,using="//button[text()='Reset']")

		private WebElement eleReset;
		public  CreateDespatchBOMBundle clickReset(){
			click(eleReset);
			return this;
		}
		
		@FindBy(how=How.XPATH,using="//span[@title='Move to Right']/i")

		private WebElement eleMoveToRight;
		public  CreateDespatchBOMBundle clickMoveToRight(){
			click(eleMoveToRight);
			return this;
		}
	
		@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Right']")

		private WebElement eleMoveAllToRight;
		public  CreateDespatchBOMBundle clickMoveAllToRight(){
			click(eleMoveAllToRight);
			return this;
		}
		
		@FindBy(how=How.XPATH,using="//span[@title='Move to Left']/i")

		private WebElement eleMoveToLeft;
		public  CreateDespatchBOMBundle clickMoveToLeft(){
			click(eleMoveToLeft);
			return this;
		}
		
		@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Left']")

		private WebElement eleMoveAllToLeft;
		public  CreateDespatchBOMBundle clickMoveAllToLeft(){
			click(eleMoveAllToLeft);
			return this;
		}
		
		@FindBy(how=How.ID,using="lblBundleWt")

		private WebElement eleBundleWeight;
		public  CreateDespatchBOMBundle getBundleWeight(){
			getText(eleBundleWeight);
			System.out.println("The Bundle weight displayed is "+getText(eleBundleWeight));
			return this;
		}
		

		@FindBy(how=How.XPATH,using="//div[@id='PanelCompDetails']//tbody/tr")
		public List<WebElement> eleNoOfPanelPartdetails;
		public CreateDespatchBOMBundle getNoOfPanelPartdetails() 
		{
			int panelParts = eleNoOfPanelPartdetails.size();
			System.out.println("The total Panel part displyed in UI is "+panelParts);
			return this;
		}
		@FindBy(how=How.XPATH,using="//div[@id='BundleCompDetails']//tbody/tr")
		public List<WebElement> eleNoOfBundlePartdetails;
		public CreateDespatchBOMBundle getNoOfBundlePartdetails() 
		{
			int BundleParts = eleNoOfBundlePartdetails.size();
			System.out.println("The total Bundle part displyed in UI is "+BundleParts);
			return this;
		}


		@FindBy(how=How.XPATH,using="//ul[@class='k-pager-numbers k-reset']//a[@class='k-link']")
		private List<WebElement> eleTotalNoOfPages;
		private int totalNoOfpages;
		public CreateDespatchBOMBundle getTotalNoOfPages()
		{
			clickDoubleRightArrow();
			try {
				int noOfElements=eleTotalNoOfPages.size();
				System.out.println(noOfElements);
				totalNoOfpages=Integer.parseInt(getText(locateElement("xpath", "(//ul[@class='k-pager-numbers k-reset']//a[@class='k-link'])["+noOfElements+"]")))+1;
			}catch(Exception e)
			{
				System.out.println("No of pages is one");
			}
			clickDoubleLeftArrow();
			return this;
		}

		@FindBy(how=How.XPATH,using="//span[text()='seek-e']/..")
		private WebElement eleDoubleRightArrow;
		public CreateDespatchBOMBundle clickDoubleRightArrow()
		{
			click(eleDoubleRightArrow);
			return this;

		}

		@FindBy(how=How.XPATH,using="//span[text()='seek-w']/..")
		private WebElement eleDoubleLeftArrow;
		public CreateDespatchBOMBundle clickDoubleLeftArrow()
		{
			click(eleDoubleLeftArrow);
			return this;

		}
		
		@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")
		private WebElement eleSingleRightArrow;
		public CreateDespatchBOMBundle clickSingleRightArrow()
		{
			click(eleSingleRightArrow);
			return this;

		}


		@FindBy(how=How.XPATH,using="//span[text()='arrow-w']/..")
		private WebElement eleSingleLeftArrow;
		public CreateDespatchBOMBundle clickSingleLeftArrow()
		{
			click(eleSingleLeftArrow);
			return this;

		}
		
		public CreateDespatchBOMBundle clickPartsToCreateBundle(int noOfRecordsFromDB,int partsToSelect)//as of now take hardcode value
		{
			int totalNoOfPages=1;
			System.out.println(eleTotalNoOfPages);
			if(eleTotalNoOfPages.isEmpty()) {
				
				System.out.println("No of records are captured in single page");
				for (int i = 1; i <= partsToSelect; i++) {
					WebElement ele=locateElement("xpath","//div[@id='PanelCompDetails']//tbody/tr["+i+"]");
					//System.out.println("The element captured "+ele);
					click(ele);
					
				}

			}
			else if(noOfRecordsFromDB==0)
			{
				System.out.println("There are no records to display for the given inputs");
			}
			else
			{
				while(totalNoOfPages<=totalNoOfpages&&totalNoOfpages!=0) {

					for (int i = 1; i <= partsToSelect; i++) {
						WebElement ele=locateElement("xpath","//div[@id='PanelCompDetails']//tbody/tr["+i+"]");
						//System.out.println("The element is"+ele);
						click(ele);
					}

					clickSingleRightArrow();
					totalNoOfPages++;
				}
			}
			return this;
		}
		@FindBy(how=How.ID,using="kendoWindow_wnd_title")
		public WebElement eledialogTitle;
		public CreateDespatchBOMBundle getdialogTitle() 
		{
			System.out.println(getText(eledialogTitle));
			dialogTitle=getText(eledialogTitle);
			return this;
		}
		
		@FindBy(how=How.ID,using="lblwindowmsg")
		private WebElement eledialogMsg;
		public CreateDespatchBOMBundle getdialogMsg() 
		{
			dialogMessage = getText(eledialogMsg);		
			System.out.println(dialogMessage);
			return this;
		}
		
		@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
		public WebElement closeMessage; 
		public CreateDespatchBOMBundle  CloseMessage()
		{
			click(closeMessage);
			return this;
		}
		public CreateDespatchBOMBundle clickPartsToCreateBundletemp(int partsToSelect) {
		for (int i = 1; i <= partsToSelect; i++) {
			//WebElement ele=locateElement("xpath","//div[@id='PanelCompDetails']//tbody/tr["+i+"]");
			
			WebElement ele = locateWebTableElement("Part Code", i);
			//ele.sendKeys(Keys.ENTER);
			/*WebElement ele = locateWebTableElement("Part Code", i);
			wait.until(ExpectedConditions.elementToBeClickable(ele));*/
			/*JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript(String.format("return $('td:contains(\"{0}\")').parent().addClass('k-state-selected');", ele));*/
			/*JavascriptExecutor js=(JavascriptExecutor)getEventDriver();
			js.executeScript("arguments[0].click()", locateElement("xpath","//div[@id='PanelCompDetails']//tbody/tr["+i+"]"));*/
			click(ele);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.println(ele.getAttribute("aria-selected"));
			
		}
		return this;
		}
		//this option is not given in the build release
		@FindBy(how=How.XPATH,using="dummy") 
		public WebElement eleAnotherBundle; 
		public CreateDespatchBOMBundle  clickAnotherBundle()
		{
			click(eleAnotherBundle);
			return this;
		}
}