package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class BBUEssentialsCreate extends AbstractPage  {

public BBUEssentialsCreate(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsOrderNumber;
public BBUEssentialsCreate typeBBUEssentialsOrderNumber(String dataBBUEssentialsOrderNumber){
	type(eleBBUEssentialsOrderNumber, dataBBUEssentialsOrderNumber);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsProductCode;
public BBUEssentialsCreate selectUsingTextBBUEssentialsProductCode(String dataBBUEssentialsProductCode){
	selectUsingText(eleBBUEssentialsProductCode, dataBBUEssentialsProductCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentials_BBUCode;
public BBUEssentialsCreate typeBBUEssentials_BBUCode(String dataBBUEssentials_BBUCode){
	type(eleBBUEssentials_BBUCode, dataBBUEssentials_BBUCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")	

public WebElement eleBBUEssentialsBBUDesc;
public BBUEssentialsCreate typeBBUEssentialsBBUDesc(String dataBBUEssentialsBBUDesc){
	type(eleBBUEssentialsBBUDesc, dataBBUEssentialsBBUDesc);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUBOMPartdetailsSearch;
public BBUEssentialsCreate typeBBUBOMPartdetailsSearch(String dataBBUBOMPartdetailsSearch){
	type(eleBBUBOMPartdetailsSearch, dataBBUBOMPartdetailsSearch);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUBOMPartdetailsBoth;
public BBUEssentialsCreate clickBBUBOMPartdetailsBoth(){
	click(eleBBUBOMPartdetailsBoth);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUBOMPartdetailsPartCode;
public BBUEssentialsCreate clickBBUBOMPartdetailsPartCode(){
	click(eleBBUBOMPartdetailsPartCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUBOMPartdetailsProductCode;
public BBUEssentialsCreate clickBBUBOMPartdetailsProductCode(){
	click(eleBBUBOMPartdetailsProductCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUBOMPartDetailsPartCodeDesignProductCode;
public BBUEssentialsCreate verifyExactTextBBUBOMPartDetailsPartCodeDesignProductCode(String dataBBUBOMPartDetailsPartCodeDesignProductCode){
	verifyText(eleBBUBOMPartDetailsPartCodeDesignProductCode, dataBBUBOMPartDetailsPartCodeDesignProductCode);
	return this;
}
/*@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUBOMPartdetailsQtyProduct;
public BBUEssentialsCreate verifyCountBBUBOMPartdetailsQtyProduct(String dataBBUBOMPartdetailsQtyProduct){
	verifyCount(eleBBUBOMPartdetailsQtyProduct, dataBBUBOMPartdetailsQtyProduct);
	return this;
}*/
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUSingleLeftArrow;
public BBUEssentialsCreate clickBBUSingleLeftArrow(){
	click(eleBBUSingleLeftArrow);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDoubleLeftArrow;
public BBUEssentialsCreate clickBBUDoubleLeftArrow(){
	click(eleBBUDoubleLeftArrow);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUSingleRightArrow;
public BBUEssentialsCreate clickBBUSingleRightArrow(){
	click(eleBBUSingleRightArrow);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDoubleRightArrow;
public BBUEssentialsCreate clickBBUDoubleRightArrow(){
	click(eleBBUDoubleRightArrow);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUPartDetailsPartCodeDesignProductCode;
public BBUEssentialsCreate verifyExactTextBBUPartDetailsPartCodeDesignProductCode(String dataBBUPartDetailsPartCodeDesignProductCode){
	verifyText(eleBBUPartDetailsPartCodeDesignProductCode, dataBBUPartDetailsPartCodeDesignProductCode);
	return this;
}
/*@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUPartDetailsQtyProduct;
public BBUEssentialsCreate verifyCountBBUPartDetailsQtyProduct(String dataBBUPartDetailsQtyProduct){
	verifyCount(eleBBUPartDetailsQtyProduct, dataBBUPartDetailsQtyProduct);
	return this;
}*/
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBURemarks;
public BBUEssentialsCreate typeBBURemarks(String dataBBURemarks){
	type(eleBBURemarks, dataBBURemarks);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsSubmit;
public BBUEssentialsCreate clickBBUDetailsSubmit(){
	click(eleBBUDetailsSubmit);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsReset;
public BBUEssentialsCreate clickBBUDetailsReset(){
	click(eleBBUDetailsReset);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsSuccessMessage;
public BBUEssentialsCreate verifyTextContainsBBUDetailsSuccessMessage(String dataBBUDetailsSuccessMessage){
	verifyText(eleBBUDetailsSuccessMessage, dataBBUDetailsSuccessMessage);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsSuccessMessageClose;
public BBUEssentialsCreate clickBBUDetailsSuccessMessageClose(){
	click(eleBBUDetailsSuccessMessageClose);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsSuccessMessageYes;
public BBUEssentialsCreate clickBBUDetailsSuccessMessageYes(){
	click(eleBBUDetailsSuccessMessageYes);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsSuccessMessageNo;
public BBUEssentialsCreate clickBBUDetailsSuccessMessageNo(){
	click(eleBBUDetailsSuccessMessageNo);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUWeightinCreate;
public BBUEssentialsCreate verifyExactTextBBUWeightinCreate(String dataBBUWeightinCreate){
	verifyText(eleBBUWeightinCreate, dataBBUWeightinCreate);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleCreateBBUTitle;
public BBUEssentialsCreate verifyTitleBBUCreate(String title){
	verifyTitle(title);
	
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleErrorMsg;
public BBUEssentialsCreate verifyErrorMsg(String dataVerifyError){
	verifyText(eleErrorMsg, dataVerifyError);
	return this;
}



}
