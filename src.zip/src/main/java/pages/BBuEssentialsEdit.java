package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class BBuEssentialsEdit extends AbstractPage  {

public BBuEssentialsEdit(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUEssentialsOrderNumber;
public BBuEssentialsEdit typeBBUEssentialsOrderNumber(String dataBBUEssentialsOrderNumber){
	type(eleBBUEssentialsOrderNumber, dataBBUEssentialsOrderNumber);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUEssentialsProductCode;
public BBuEssentialsEdit selectUsingTextBBUEssentialsProductCode(String dataBBUEssentialsProductCode){
	selectUsingText(eleBBUEssentialsProductCode, dataBBUEssentialsProductCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUEssentials_BBUCode;
public BBuEssentialsEdit typeBBUEssentials_BBUCode(String dataBBUEssentials_BBUCode){
	type(eleBBUEssentials_BBUCode, dataBBUEssentials_BBUCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")	

private WebElement eleBBUEssentialsBBUDesc;
public BBuEssentialsEdit typeBBUEssentialsBBUDesc(String dataBBUEssentialsBBUDesc){
	type(eleBBUEssentialsBBUDesc, dataBBUEssentialsBBUDesc);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUBOMPartdetailsSearch;
public BBuEssentialsEdit typeBBUBOMPartdetailsSearch(String dataBBUBOMPartdetailsSearch){
	type(eleBBUBOMPartdetailsSearch, dataBBUBOMPartdetailsSearch);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUBOMPartdetailsBoth;
public BBuEssentialsEdit clickBBUBOMPartdetailsBoth(){
	click(eleBBUBOMPartdetailsBoth);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUBOMPartdetailsPartCode;
public BBuEssentialsEdit clickBBUBOMPartdetailsPartCode(){
	click(eleBBUBOMPartdetailsPartCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUBOMPartdetailsProductCode;
public BBuEssentialsEdit clickBBUBOMPartdetailsProductCode(){
	click(eleBBUBOMPartdetailsProductCode);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUSingleLeftArrow;
public BBuEssentialsEdit clickBBUSingleLeftArrow(){
	click(eleBBUSingleLeftArrow);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUDoubleLeftArrow;
public BBuEssentialsEdit clickBBUDoubleLeftArrow(){
	click(eleBBUDoubleLeftArrow);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUSingleRightArrow;
public BBuEssentialsEdit clickBBUSingleRightArrow(){
	click(eleBBUSingleRightArrow);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUDoubleRightArrow;
public BBuEssentialsEdit clickBBUDoubleRightArrow(){
	click(eleBBUDoubleRightArrow);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleBBUPartDetailsPartCodeDesignProductCode;
public BBuEssentialsEdit verifyExactTextBBUPartDetailsPartCodeDesignProductCode(String dataBBUPartDetailsPartCodeDesignProductCode){
	verifyText(eleBBUPartDetailsPartCodeDesignProductCode, dataBBUPartDetailsPartCodeDesignProductCode);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleUpdateButton;
public BBuEssentialsEdit clickUpdateButton(){
	click(eleUpdateButton);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

private WebElement eleResetButton;
public BBuEssentialsEdit clickResetButton(){
	click(eleResetButton);
	return this;
}



}