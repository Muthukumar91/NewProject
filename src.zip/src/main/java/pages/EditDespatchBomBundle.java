package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class EditDespatchBomBundle extends AbstractPage {
	public static String dialogMessage,dialogTitle;
	public EditDespatchBomBundle(){
		PageFactory.initElements(getEventDriver(), this);
	}
	
	@FindBy(how=How.ID,using="view")
    private WebElement eleView;

	public ViewDespatchBOMBundle clickView(){
	
		click(eleView);
		return new ViewDespatchBOMBundle();
	}
	
	@FindBy(how=How.ID,using="Create")
    private WebElement eleCreate;

	public CreateDespatchBOMBundle clickCreate(){
	
		click(eleCreate);
		return new CreateDespatchBOMBundle();
	}
	

	@FindBy(how=How.ID,using="authorize")
    private WebElement eleApprove;

	public ApprovalDespatchBOMBundle clickApprove(){
	
		click(eleApprove);
		return new ApprovalDespatchBOMBundle();
	}
	
	@FindBy(how=How.ID,using="help")
    private WebElement eleHelp;

	public EditDespatchBomBundle clickHelp(){
	
		click(eleHelp);
		return this;
	}
	@FindBy(how=How.CLASS_NAME,using="mandatory-star")
	private List<WebElement> eleMandatory;

	public EditDespatchBomBundle verifyMandatoryFields()
	{
		String[] elements = {"Order Number ","Product Code ","Panel Code "};
		System.out.println(verifyMandatory(elements));
		return this;

	}
	
	@FindBy(how=How.ID,using="OrderNumber")
    private WebElement eleOrderNumber;

	public EditDespatchBomBundle typeOrderNumber(String dataOrderNumber){
	
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='Product']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleProductCodeDd;
	public EditDespatchBomBundle clickProductCodeDd(){
		click(eleProductCodeDd);
		return this;
	}
	
	
	public EditDespatchBomBundle selectProductCode(String productCode){
		selectUsingText(locateElement("xpath", "//li[text()='"+productCode+"']"), productCode);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='PanelCode']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement elePanelCodeDd;
	public EditDespatchBomBundle clickPanelCodeDd(){
		click(elePanelCodeDd);
		return this;
	}
	
	
	public EditDespatchBomBundle selectPanelCode(String panelCode){
		selectUsingText(locateElement("xpath", "//li[text()='"+panelCode+"']"), panelCode);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='BundleCode']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleBundleCodeDd;
	public EditDespatchBomBundle clickBundleCodeDd(){
		click(eleBundleCodeDd);
		return this;
	}
	
	
	public EditDespatchBomBundle selectBundleCode(String bundleCode){
		selectUsingText(locateElement("xpath", "//li[text()='"+bundleCode+"']"), bundleCode);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='BundleType']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleBundleTypeDd;
	public EditDespatchBomBundle clickBundleTypeDd(){
		click(eleBundleTypeDd);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='BundleType']/preceding-sibling::span/span[@class='k-select']/preceding-sibling::span")

	public WebElement eleBundleType;
	public EditDespatchBomBundle getSelectedBundleType(){
		System.out.println("The selected Bundle type is "+getText(eleBundleType));
		return this;
	}
	
	public EditDespatchBomBundle selectBundleType(String bundleType){
		selectUsingText(locateElement("xpath", "//li[text()='"+bundleType+"']"), bundleType);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Reset']")

	private WebElement eleReset;
	public  EditDespatchBomBundle clickReset(){
		click(eleReset);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@title='Move to Right']/i")

	private WebElement eleMoveToRight;
	public  EditDespatchBomBundle clickMoveToRight(){
		click(eleMoveToRight);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Right']")

	private WebElement eleMoveAllToRight;
	public  EditDespatchBomBundle clickMoveAllToRight(){
		click(eleMoveAllToRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@title='Move to Left']/i")

	private WebElement eleMoveToLeft;
	public  EditDespatchBomBundle clickMoveToLeft(){
		click(eleMoveToLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Left']")

	private WebElement eleMoveAllToLeft;
	public  EditDespatchBomBundle clickMoveAllToLeft(){
		click(eleMoveAllToLeft);
		return this;
	}
	
	@FindBy(how=How.ID,using="lblBundleWt")

	private WebElement eleBundleWeight;
	public  EditDespatchBomBundle getBundleWeight(){
		getText(eleBundleWeight);
		System.out.println("The Bundle weight displayed is "+getText(eleBundleWeight));
		return this;
	}
	
	@FindBy(how=How.ID,using="kendoWindow_wnd_title")
	public WebElement eledialogTitle;
	public EditDespatchBomBundle getdialogTitle() 
	{
		System.out.println(getText(eledialogTitle));
		dialogTitle=getText(eledialogTitle);
		return this;
	}
	
	@FindBy(how=How.ID,using="lblwindowmsg")
	private WebElement eledialogMsg;
	public EditDespatchBomBundle getdialogMsg() 
	{
		dialogMessage = getText(eledialogMsg);		
		System.out.println(dialogMessage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	public WebElement closeMessage; 
	public EditDespatchBomBundle  CloseMessage()
	{
		click(closeMessage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@id='PanelCompDetails']//tbody/tr")
	public List<WebElement> eleNoOfPanelPartdetails;
	public EditDespatchBomBundle getNoOfPanelPartdetails() 
	{
		int panelParts = eleNoOfPanelPartdetails.size();
		System.out.println("The total Panel part displyed in UI is "+panelParts);
		return this;
	}
	@FindBy(how=How.XPATH,using="//div[@id='BundleCompDetails']//tbody/tr")
	public List<WebElement> eleNoOfBundlePartdetails;
	public EditDespatchBomBundle getNoOfBundlePartdetails() 
	{
		int BundleParts = eleNoOfBundlePartdetails.size();
		System.out.println("The total Panel part displyed in UI is "+BundleParts);
		return this;
	}
	@FindBy(how=How.ID,using="dummy") 
	public WebElement eleupdate; 
	public EditDespatchBomBundle  clickUpdate()
	{
		click(eleupdate);
		return this;
	}
	
}
