package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;



public class ProductsCreate extends AbstractPage  {
	
	
	public ProductsCreate(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="Create")
	public WebElement eleCreate;
	public ProductsCreate clickCreate(){
		getEventDriver().navigate().refresh();
		pause(2);
		click(eleCreate);
		pause(2); 
		return this;
	}
	
	@FindBy(how=How.ID,using="DesignOrder")

	public WebElement eleDesignOrder;
	public ProductsCreate TypeDesignOrder(){
		String data=WindowMessage;
		System.out.println(data);
		typeAndChoose(eleDesignOrder, data);
		return this;
	}
	
	public ProductsCreate TypeDesignOrder(String data){
		
		typeAndChoose(eleDesignOrder, data);
		return this;
	}
	

	@FindBy(how=How.ID,using="ProductCode")

	public WebElement eleProductCode;
	public ProductsCreate TypeProductCode(String data){
		type(eleProductCode, data);
		
		return this;
	}
	
	@FindBy(how=How.ID,using="ShortDescription")

	public WebElement eleShortDescription;
	public ProductsCreate TypeShortDescription(String data){
		try {
		
			type(eleShortDescription, data);
	
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return this;
	}
	
	
	
	@FindBy(how=How.XPATH,using="//input[@type='radio']")

	public WebElement eleDesignProduct;
	public ProductsCreate clickDesignProduct(){
	
		click(eleDesignProduct);
			return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@type='radio'][2]")

	public WebElement eleCustomerProduct;
	public ProductsCreate clickCustomerProduct(){
		
	click(eleCustomerProduct);
		return this;
	}
	
	
	@FindBy(how=How.ID,using="ReqQty")

	public WebElement eleReqQty;
	public ProductsCreate TypeReqQty(String data){
		
		type(eleReqQty, data);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//button[text()='Submit']")

	public WebElement elesub;
	public ProductsCreate ClickSubmit(){
		
		click(elesub);
		pause(2);
		
		return this;
	}
	
		
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following::a")

	public WebElement eleclose;
	public ProductsCreate ClickClose(){

		click(eleclose);
		pause(2);
		
		return this;
	}
	
	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;
		public LeftMenuPage clickNavigation() {
		pause(2);
		click(eleNavigation); 
		return new LeftMenuPage(); 
	}
	

	
	
	}

	

