package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.When;

public class PanelEssentialsView extends AbstractPage  {
	public List<String> text1, text2, text3;

	public PanelEssentialsView(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}
	@FindBy(how=How.ID,using="Create")

	public WebElement eleCreate;
	public PanelEssentialsCreate clickCreate(){
		click(eleCreate);
		return new PanelEssentialsCreate();
	}


	@FindBy(how=How.ID,using="update")

	public WebElement eleEdit;
	public PanelEssentialsEdit clickEdit(){
		click(eleEdit);
		pause(2);
		return new PanelEssentialsEdit();
	}

	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	@When ("The OrderNumber entered")
	public PanelEssentialsView typeAndChooseOrderNumber(String dataOrderNumber){
		click(eleOrderNumber);
		pause(3);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		eleOrderNumber.sendKeys(Keys.TAB);
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@class='k-select']")

	public WebElement eleProductCode;
	public PanelEssentialsView  selectUsingTextProductCode(String options){
		click(eleProductCode);
		pause(2);
		click(locateElement("xpath", "(//li[@id='ProductCode_option_selected']/following::li[@class='k-item'])["+options+"]"));
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[text()='--Select Panel Code--']/following::span")
		//	"//label[@id='lblPan']/following::span[3]")

	public WebElement elePanelCode;
	public PanelEssentialsView typePanelCode(String dataPanelCode){
		//selectUsingText(elePanelCode, dataPanelCode);
		click(elePanelCode);
		pause(2);
		click(locateElement("xpath", "//li[text()='"+dataPanelCode+"']"));
		return this;
	}

	@FindBy(how=How.ID,using="SubmitAssociation")

	public WebElement eleGoButton;
	public PanelEssentialsView clickGo(){
		click(eleGoButton);
		return this;
	}

	@FindBy(how=How.ID,using="Reset")

	private WebElement eleReset;
	public  PanelEssentialsView clickReset(){
		click(eleReset);
		return this;
	}


	@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']/div[3]//input")
	public WebElement elePageNumber;
	public PanelEssentialsView EnterPageNumber(String PageNumber)
	{	elePageNumber.sendKeys(Keys.BACK_SPACE);
		elePageNumber.sendKeys(Keys.DELETE);
		typeandEnter(elePageNumber, PageNumber);
		String number = getText(locateElement("xpath", "//span[@class='k-pager-input k-label']")).replaceAll("\\D", "");
		System.out.println(number);
		if(PageNumber==number) {
			System.out.println("Page Moved");

		}else {
			System.out.println("Page Not Moved");

		}

		return this;

	}

	public PanelEssentialsView enteritems(String items)
	{
		click(locateElement("xpath", "//div[@id='BOMPartDetails']/div[3]/span[2]/span/span"));
		pause(2);
		click(locateElement("xpath", "//li[text()='"+items+"']"));


		return this;

	} 

	@FindBy(how=How.XPATH,using="//div[@class='lti-alert-msg']")

	public WebElement eleErrorMessage;
	public PanelEssentialsView verifyTextContainWarningMsg(String warning) {

		boolean text = verifyPartialText(eleErrorMessage, warning);
		if(text==true)
			System.out.println("text matched");
		else
			System.out.println("text not matched");
		return this;
	}

	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	private WebElement closeMessage; 
	public PanelEssentialsView  CloseWarningMsg()
	{
		click(closeMessage);
		return this;
	}

	public PanelEssentialsView clickReferesh(){
		getEventDriver().navigate().refresh();
		pause(2);
		return this;
	}

	public PanelEssentialsView ResetVerification() {

		String attribute = locateElement("id", "OrderNumber").getAttribute("aria-busy");		
		if(attribute==null) {
			reportStep("Value Cleared", "Pass");
		}else if(attribute.equals("false")) {
			reportStep("Value not Cleared", "Pass");
		}else {
			reportStep("Value not Cleared", "Fail");
		}
		return this;

	}

	@FindBy(how=How.XPATH,using="//input[@id='OrderNumber']/../following::i")

	public WebElement eleOrderNuminfo;
	public PanelEssentialsView clickOrderNumberInfo(){
		pause(2);
		click(eleOrderNuminfo);
		return this;
	}

	public PanelEssentialsView clickOrderNumberInfoAfter(String order){
		pause(2);
		click(eleOrderNuminfo);
		String number = getText(locateElement("xpath", "//td[text()='Order Number']/following::td"));
		if (number.equals(order)) {
			reportStep("Text Matched", "Pass");

		}else {
			reportStep("Text not Matched", "Fail");
		}
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ProductCode']/../following::i")

	public WebElement eleProductCodeinfo;
	public PanelEssentialsView clickProductCodeInfo(){
		pause(2);
		click(eleProductCodeinfo);

		return this;
	}

	public PanelEssentialsView clickProductCodeInfoAfter(){
		String options = getText(locateElement("xpath", "//span[@aria-activedescendant='ProductCode_option_selected']/span/span"));

		pause(2);
		click(eleProductCodeinfo);

		String number = getText(locateElement("xpath", "//td[text()='Short Description']/following::td"));
		if (options.contains(number)) {
			reportStep("Text Matched", "Pass");

		}else {
			reportStep("Text not Matched", "Fail");
		}
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@class='k-pager-info k-label']")
	public  WebElement eleNoRecords;

	public PanelEssentialsView getNoRecords(){
		String text = getText(eleNoRecords);
		if (text.equals("No items to display")) {
			reportStep("No Records Found", "Pass");
		}else {
			reportStep("Records Found", "Pass");
		}

		return this;
	}

	/*@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']/div[2]//tbody/tr")
	public  List<WebElement> elegridDetails;*/
	public PanelEssentialsView gridUIValidation(){
		text1= new ArrayList<String>();
		pause(3);
		int sum =0;
		int page = 0;
		String pagenumber = getText(locateElement("xpath", "//span[@class='k-pager-input k-label']")).replaceAll("\\D", "");
		int number = StringToInteger(pagenumber);
		do {
			List<WebElement> elegridDetails = getEventDriver().findElements(By.xpath("//div[@id='BOMPartDetails']/div[2]//tbody/tr"));
			for (WebElement details : elegridDetails) {
				String text = getText(details);
				System.out.println("Grid value from UI:" +text);
				text1.add(text);
				}

			String attributeText = getAttributeText(locateElement("xpath", "//div[@id='BOMPartDetails']/div[3]/a[2]"), "data-page");
			System.out.println("attributeText:" +attributeText);
			page = StringToInteger(attributeText);
			page=page+sum;
			sum++;
			System.out.println("sum: "+ sum);
			System.out.println("page: "+ page);
			ClickNextPage();
		}
		while(number!=page);


		return this;
	}

	public PanelEssentialsView ClickNextPage(){
		pause(2);
		jsClick(locateElement("xpath", "//a[@title='Go to the next page']"));

		return this;
	}

	public PanelEssentialsView ClickPreviousPage(){
		click(locateElement("xpath", "//a[@title='Go to the previous page']"));

		return this;
	}
	public PanelEssentialsView ClickLastPage(){
		click(locateElement("xpath", "//a[@title='Go to the last page']"));

		return this;
	}
	public PanelEssentialsView ClickFirstPage(){
		click(locateElement("xpath", "//a[@title='Go to the first page']"));

		return this;
	}

	public PanelEssentialsView dbvalidation(String sql) {
		String string = "";
		text2= new ArrayList<String>();
		Object[][] dataFromDb = getDataFromDb(sql);
		for (Object[] objects : dataFromDb) {
			for (int i = 0; i < objects.length; i++) {
				string = objects[i].toString();
				text2.add(string);
				System.out.println("Text From DB:" +string);
			}


		}
		return this;

	}


	public PanelEssentialsView compareString() {
		if(text2.equals(text1)) {
			System.out.println("DB VALIDATION SUCCESSFULLY");	
		}else {
			System.out.println("DB VALIDATION FAILED");
		}
		return this;

	}
}
