package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class DeliveryChallan extends AbstractPage  {
	public DeliveryChallan(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleClickClose;
	public DeliveryChallan clickeleClickClose(){
		click(eleeleClickClose);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleGetConformationMessage;
	public DeliveryChallan storeTexteleGetConformationMessage(){
		getText(eleeleGetConformationMessage);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleClickYes;
	public DeliveryChallan clickeleClickYes(){
		click(eleeleClickYes);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleClickNo;
	public DeliveryChallan clickeleClickNo(){
		click(eleeleClickNo);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleDeliveryChallanNumber;
	public DeliveryChallan storeTexteleDeliveryChallanNumber(){
		getText(eleeleDeliveryChallanNumber);
		return this;
	}
	@FindBy(how=How.ID,using="Create")

	public WebElement eleeleClickCreate;
	public DeliveryChallan clickeleClickCreate(){
		click(eleeleClickCreate);
		return this;
	}



	@FindBy(how=How.XPATH,using="//input[@id='dtFromdate']/following::span")
	public WebElement eleFromDateicon;
	public DeliveryChallan clickFromDateicon(String Year, String month, String day, String date){
		pause(2);
		click(eleFromDateicon);
		pause(2);
		click(locateElement("xpath", "//div[@id='dtFromdate_dateview']//a[2]"));
		pause(2);
		click(locateElement("xpath", "//div[@id='dtFromdate_dateview']//a[2]"));
		pause(2);
		click(locateElement("linkText", Year));

		pause(2);
		click(locateElement("linkText", month));

		click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));


		return this;
	}

	@FindBy(how=How.ID,using="fromDate")

	public WebElement eleeleFromDate;
	public DeliveryChallan typeFromDate(String dataeleFromDate){
		type(eleeleFromDate, dataeleFromDate);
		return this;
	}
	@FindBy(how=How.ID,using="toDate")

	public WebElement eleeleToDate;
	public DeliveryChallan typeeleToDate(String dataeleToDate){
		type(eleeleToDate, dataeleToDate);
		return this;
	}


	@FindBy(how=How.XPATH,using="//input[@id='dtTodate']/following::span")
	public WebElement eletoDateicon;
	public DeliveryChallan clicktoDateicon(String Year, String month, String day, String date){
		pause(2);
		click(eletoDateicon);
		pause(2);
		click(locateElement("xpath", "//div[@id='dtTodate_dateview']//a[2]"));
		pause(2);
		click(locateElement("xpath", "//div[@id='dtTodate_dateview']//a[2]"));
		pause(2);
		click(locateElement("linkText", Year));

		pause(2);
		click(locateElement("linkText", month));

		List<WebElement> list = getEventDriver().findElements(By.xpath("//a[@data-value='"+Year+"/"+day+"/"+date+"']"));
		int size = list.size();
		System.out.println(size);
		try {
			if (size==0) {
				click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));
			}else if (size>=1) {
				click(locateElement("xpath", "(//a[@data-value='"+Year+"/"+day+"/"+date+"'])[1]"));
			}else {
				click(locateElement("xpath", "(//a[@data-value='"+Year+"/"+day+"/"+date+"'])[2]"));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			click(locateElement("xpath", "//div[@class='k-footer']/a"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;
	}
	@FindBy(how=How.XPATH,using="//label[text()='DA Type']/following::span")

	public WebElement eleDAType;
	public DeliveryChallan typeAndChooseDAType(){
		String data="";
		Object[][] dataFromDb = getDataFromDb("select top 1 MDAT_Description from EIPPDSS.[PDSMAS].[GEN_M_DA_Types],EIPPDSS.PDSSAL.SAL_H_Despatch_Advice,EIPPDSS.PDSSAL.SAL_H_Delivery_Challan where HDA_Order_Number!=HDC_Order_Number and MDAT_DA_Type_Code=HDA_DA_Type_Code and MDAT_ISActive = 'Y' and MDAT_MU_Code='1616' ORDER BY newid()");
		for (Object[] objects : dataFromDb) {
			for (Object object : objects) {
				data = object.toString();
				System.out.println(data);
			}

		}
		click(eleDAType);
		pause(2);
		typeAndChoose(locateElement("xpath", "//input[@aria-owns='txtDAType_listbox']"), data);
		return this;
	}
	@FindBy(how=How.ID,using="txtOrderNumber")

	public WebElement eleeleOrderNumber;
	public DeliveryChallan typeAndChooseeleOrderNumber(String dataeleOrderNumber){
		typeAndChoose(eleeleOrderNumber, dataeleOrderNumber);
		return this;
	}
	@FindBy(how=How.ID,using="txtDANumber")

	public WebElement eleeleDANumber;
	public DeliveryChallan typeAndChooseeleDANumber(String dataeleDANumber){
		typeAndChoose(eleeleDANumber, dataeleDANumber);
		return this;
	}

	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleGo;
	public DeliveryChallan ClickGo(){
		pause(2);
		click(eleGo);
		return this;
	}

	@FindBy(how=How.ID,using="lblwindowmsg")
	public WebElement eleErrorMessage;
	public DeliveryChallan verifyTextContainWarningMsg(String data) {
		boolean text = verifyPartialText(eleErrorMessage, data);
		if(text==true) {
			System.out.println("Text Matched");
		}else {
			System.out.println("Text not Matched");
		}

		return this;

	}


	@FindBy(how=How.XPATH,using="//span[text()='Error']/following::a")

	public WebElement eleClose;
	public DeliveryChallan CloseWarningMsg(){
		click(eleClose);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()=' Reset']")

	public WebElement eleReset;
	public DeliveryChallan ClickReset(){
		click(eleReset);
		return this;
	}


	@FindBy(how=How.ID,using="chkselectAll")

	public WebElement elechkselectAll;
	public DeliveryChallan clickSelectAll(){
		click(elechkselectAll);
		
		
		return this;
	}

	@FindBy(how=How.XPATH,using="//tbody[@role='rowgroup']//td/input")

	public WebElement elefirstchk;
	public DeliveryChallan clickfirstchk(){
		click(elefirstchk);
		if (locateElement("id", "lblwindowmsg").isDisplayed()) {
			verifyWindowMsg();
			CloseWarningMsg();
		}
		
		return this;
	}

	@FindBy(how=How.XPATH,using="//tbody[@role='rowgroup']//td/input")

	public List<WebElement> eleMultiplechk;
	public DeliveryChallan clickMultiplechk(){
		for (WebElement multiplecheck : eleMultiplechk) {
			click(multiplecheck);
			if (locateElement("id", "lblwindowmsg").isDisplayed()) {
				verifyWindowMsg();
				CloseWarningMsg();
			}
			
		}
		return this;
	}


	@FindBy(how=How.ID,using="txtLorryNo")

	public WebElement eleeleLorryNumber;
	public DeliveryChallan typeLorryNumber(String dataeleLorryNumber){
		type(eleeleLorryNumber, dataeleLorryNumber);
		return this;
	}
	@FindBy(how=How.ID,using="txtLorryReceiptNo")

	public WebElement eleeleLorryReceiptNo;
	public DeliveryChallan typeLorryReceiptNo(String dataeleLorryReceiptNo){
		type(eleeleLorryReceiptNo, dataeleLorryReceiptNo);
		return this;
	}
	@FindBy(how=How.XPATH,using="//input[@id='dtLorryReceiptDate']/following::span")

	public WebElement eleLorryReceiptDate;
	public DeliveryChallan selectLorryReceiptDate(String Year,String month, String day, String date){
		pause(2);
		click(eleLorryReceiptDate);
		pause(2);
		click(locateElement("xpath", "(//div[@data-role='calendar']//a[2])[3]"));
		pause(2);
		click(locateElement("xpath", "(//div[@data-role='calendar']//a[2])[3]"));
		pause(2);
		click(locateElement("linkText", Year));

		pause(2);
		click(locateElement("linkText", month));
		List<WebElement> list = getEventDriver().findElements(By.xpath("//a[@data-value='"+Year+"/"+day+"/"+date+"']"));
		int size = list.size();
		if (size>=1) {
		click(locateElement("xpath", "(//a[@data-value='"+Year+"/"+day+"/"+date+"'])["+size+"]"));
		}else {
			click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));
		}
		return this;
	}
	@FindBy(how=How.ID,using="txtTransporterCode")

	public WebElement eleeleTransporterCode;
	public DeliveryChallan typeTransporterCode(String dataeleTransporterCode){
		typeAndChoose(eleeleTransporterCode, dataeleTransporterCode);
		return this;
	}
	@FindBy(how=How.ID,using="txtRemarks")

	public WebElement eleeleRemarks;
	public DeliveryChallan typeeleRemarks(String dataeleRemarks){
		type(eleeleRemarks, dataeleRemarks);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='Submit']")

	public WebElement eleeleSubmit;
	public DeliveryChallan clickSubmit(){
		click(eleeleSubmit);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='Reset']")

	public WebElement eleeleReset;
	public DeliveryChallan clickReset(){
		click(eleeleReset);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleClosePopUp;
	public DeliveryChallan clickeleClosePopUp(){
		click(eleeleClosePopUp);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleLotNumber;
	public DeliveryChallan storeTexteleLotNumber(){
		getText(eleeleLotNumber);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleConsignee;
	public DeliveryChallan storeTexteleConsignee(){
		getText(eleeleConsignee);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleDATotalWeight;
	public DeliveryChallan verifyExactTexteleDATotalWeight(String dataeleDATotalWeight){
		verifyText(eleeleDATotalWeight, dataeleDATotalWeight);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleDCTotalWeight;
	public DeliveryChallan verifyValueeleDCTotalWeight(String dataeleDCTotalWeight){
		verifyText(eleeleDCTotalWeight, dataeleDCTotalWeight);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleProductCode;
	public DeliveryChallan storeTexteleProductCode(){
		getText(eleeleProductCode);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleDATypeinDetails;
	public DeliveryChallan verifyExactTexteleDATypeinDetails(String dataeleDATypeinDetails){
		verifyText(eleeleDATypeinDetails, dataeleDATypeinDetails);
		return this;
	}
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleeleDANumberinDetails;
	public DeliveryChallan verifyExactTexteleDANumberinDetails(String dataeleDANumberinDetails){
		verifyText(eleeleDANumberinDetails, dataeleDANumberinDetails);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@aria-owns='txtModeofTransport_listbox']/span")

	public WebElement eleModeofTransport;
	public DeliveryChallan selectModeofTransport(){
		String mode="";
		click(eleModeofTransport);
		pause(2);
		Object[][] dataFromDB = getDataFromDB("select top 1 UTM_Description from PDSMAS.SYN_GEN_U_Transport_Mode order by newid()");
		for (Object[] objects : dataFromDB) {
			for (Object object : objects) {
				mode = object.toString();
			}
		}
		click(locateElement("xpath", "//li[text()='"+mode+"']"));
		return this;
	}
	@FindBy(how=How.ID,using="lblwindowmsg")

	public WebElement eleWindowMsg;
	public DeliveryChallan verifyWindowMsg(){
		String text = eleWindowMsg.getText();
		if (text.equals(text)) {
			reportStep("Text Matched", "Pass");
		}else {
			reportStep("Text Not Matched", "Fail");
		}
		return this;
	}
	

}
