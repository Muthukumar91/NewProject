package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;





public class ViewDespatchAdvice extends AbstractPage  {

	public List<String> text1, text2, text3;
public ViewDespatchAdvice(){
		
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

}

@FindBy(how=How.XPATH,using="//input[@id='Create']")

public WebElement eleCreate;
public CreateDespatchAdvice ClickCreate(){
	click(eleCreate);
	pause(3);
	return new CreateDespatchAdvice();
}



@FindBy(how=How.XPATH,using="//input[@id='update']")

public WebElement eleEdit;
public EditDespatchAdvice ClickEdit(){
	click(eleEdit);
	pause(3);
	return new EditDespatchAdvice();
}




@FindBy(how=How.ID,using="txtOrderNumber")

public WebElement eleOrderNumber;
public ViewDespatchAdvice typeAndChooseOrderNumber(String dataOrderNumber){
	typeAndChoose(eleOrderNumber, dataOrderNumber);
	return this;
}




@FindBy(how=How.XPATH,using="//input[@id='fromDate']/following::span")
public WebElement eleFromDateicon;
public ViewDespatchAdvice clickFromDateicon(String Year, String month, String day, String date){
	int input = StringToInteger(date);
	input= input-1;
	pause(2);
	click(eleFromDateicon);
	pause(2);
	click(locateElement("xpath", "//div[@id='fromDate_dateview']//a[2]"));
	pause(2);
	click(locateElement("xpath", "//div[@id='fromDate_dateview']//a[2]"));
	pause(2);
	click(locateElement("linkText", Year));

	pause(2);
	click(locateElement("linkText", month));

	click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));


	return this;
}



@FindBy(how=How.XPATH,using="//input[@id='toDate']/following::span")
public WebElement eleToDateicon;
public ViewDespatchAdvice clickToDateicon(String Year, String month, String day, String date){
	
	int input = StringToInteger(date);
	input= input-1;
	pause(2);
	click(eleToDateicon);
	pause(2);
	click(locateElement("xpath", "//div[@id='toDate_dateview']//a[2]"));
	pause(2);
	click(locateElement("xpath", "//div[@id='toDate_dateview']//a[2]"));
	pause(2);
	click(locateElement("linkText", Year));

	pause(2);
	click(locateElement("linkText", month));

	try {
		click(locateElement("xpath", "(//a[@data-value='"+Year+"/"+day+"/"+date+"'])[2]"));
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return this;
}

@FindBy(how=How.ID,using="rdbPanel")

public WebElement elePanelCheckbox;
public ViewDespatchAdvice checkPanelCheckbox(){
	click(elePanelCheckbox);
	return this;
}
@FindBy(how=How.ID,using="rdbNonPanel")

public WebElement eleNonPanelCheckbox;
public ViewDespatchAdvice checkNonPanelCheckbox(){
	click(eleNonPanelCheckbox);
	return this;
}

@FindBy(how=How.ID,using="txtDANumber")

public WebElement eleDANumber;
public ViewDespatchAdvice typeDANumber(String DANumber){
	typeAndChoose(eleDANumber, DANumber);
	return this;
}
@FindBy(how=How.ID,using="GetData")

public WebElement eleGo;
public ViewDespatchAdvice ClickGoButton(){
	click(eleGo);
	return this;
}

@FindBy(how=How.ID,using="ClearData")
public WebElement eleReset;
public ViewDespatchAdvice ClickResetButton(){
	click(eleReset);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleGridDate;
public ViewDespatchAdvice verifyExistsGridDate(){
	verifyExists(eleGridDate);
	return this;
}	
	
	
	
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleGridDANumber;
public ViewDespatchAdvice verifyGridDANumber(){
	verifyExists(eleGridDANumber);
	return this;
}	
		
	
	
@FindBy(how=How.XPATH,using="Dummy")

public WebElement GridCreatedOn;
public ViewDespatchAdvice verifyGridCreatedOn(){
	verifyExists(GridCreatedOn);
	return this;
}	
		

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleCreatedBy;
public ViewDespatchAdvice verifyGridCreatedBy(){
	verifyExists(eleCreatedBy);
	return this;
}	

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleDANumberGridValue;
public ViewDespatchAdvice ClickDANumber(){
	click(eleDANumberGridValue);
	return this;
}

/* Verifying Despatch Advice Details for Panel  */

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleDAType;
public ViewDespatchAdvice verifyExistsDATypeResults(){
	verifyExists(eleDAType);
	return this;
}	


@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleLotNumber;
public ViewDespatchAdvice verifyExistsLotNumber(){
	verifyExists(eleLotNumber);
	return this;
}	


@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleLDespatchMode;
public ViewDespatchAdvice verifyExistsDespatchMode(){
	verifyExists(eleLDespatchMode);
	return this;
}



@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleProductCode;
public ViewDespatchAdvice verifyExistsProductCode(){
	verifyExists(eleProductCode);
	return this;
}	


@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleOrderNumberResult;
public ViewDespatchAdvice verifyExistsOrderNumber(){
	verifyExists(eleOrderNumberResult);
	return this;
}	

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleConsigneeCode;
public ViewDespatchAdvice verifyExistsConsgineeCode(){
	verifyExists(eleConsigneeCode);
	return this;
}	


@FindBy(how=How.XPATH,using="Dummy")

public WebElement elePanelCode;
public ViewDespatchAdvice verifyExistsPanelCode(){
	verifyExists(elePanelCode);
	return this;
}	

public WebElement eleBundleSequence;
public ViewDespatchAdvice verifyExistsBundleAdviceSequence(){
	verifyExists(eleBundleSequence);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleCode;
public ViewDespatchAdvice verifyExistsBundleCode(){
	verifyExists(eleBundleCode);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleType;
public ViewDespatchAdvice verifyExistsBundleType(){
	verifyExists(eleBundleType);
	return this;
}


@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBundleWeight;
public ViewDespatchAdvice verifyExistsBundleWeight(){
	verifyExists(eleBundleWeight);
	return this;
}

@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleDATotalWeight;
public ViewDespatchAdvice verifyExistsDATotalWeight(){
	verifyExists(eleDATotalWeight);
	return this;
}


@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleCloseDADetails;
public ViewDespatchAdvice ClicktoCloseDADetails(){
	click(eleCloseDADetails);
	return this;
}


@FindBy(how=How.XPATH,using="//span[text()='items per page']/span/span")

public WebElement itemsPerPage;
public ViewDespatchAdvice clickItemsPerPage(String page){
	click(itemsPerPage);
	pause(1);
	click(locateElement("xpath", "//li[text()='"+page+"']"));
	return this;
}



@FindBy(how=How.XPATH,using="//div[@id='LinkageDetails']/div[3]/span[1]")
public WebElement totalpage;
@FindBy(how=How.XPATH,using="//div[@id='LinkageDetails']/div[3]//li[1]/a")
public WebElement pageindex;
public ViewDespatchAdvice ClickNextPage(){
	
		click(locateElement("xpath", "//a[@title='Go to the next page']"));

	return this;
}

public ViewDespatchAdvice ClickPreviousPage(){
	click(locateElement("xpath", "//a[@title='Go to the previous page']"));

	return this;
}
public ViewDespatchAdvice ClickLastPage(){
	click(locateElement("xpath", "//a[@title='Go to the previous page']"));

	return this;
}
public ViewDespatchAdvice ClickFirstPage(){
	click(locateElement("xpath", "//a[@title='Go to the first page']"));

	return this;
}


public ViewDespatchAdvice UiValidation() {
	
	text1= new ArrayList<String>();
	pause(3);
	int sum =0;
	int page = 0;
	String pagenumber = getText(locateElement("xpath", "//span[@class='k-pager-input k-label']")).replaceAll("\\D", "");
	int number = StringToInteger(pagenumber);
	do {
		List<WebElement> elegridDetails = getEventDriver().findElements(By.xpath("//div[@id='DAViewDetails']/div[2]/table/tbody/tr"));
		for (WebElement details : elegridDetails) {
			String text = getText(details);
			System.out.println("Grid value from UI:" +text);
			text1.add(text);
			}

		String attributeText = getAttributeText(locateElement("xpath", "//div[@id='DAViewDetails']/div[3]/a[2]"), "data-page");
		System.out.println("attributeText:" +attributeText);
		page = StringToInteger(attributeText);
		page=page+sum;
		sum++;
		System.out.println("sum: "+ sum);
		System.out.println("page: "+ page);
		ClickNextPage();
	}
	while(number!=page);

	return this;
}


public ViewDespatchAdvice UiValidationForDB() {
	
	text1= new ArrayList<String>();
	pause(3);
	int sum =0;
	int page = 0;
	String pagenumber = getText(locateElement("xpath", "//span[@class='k-pager-input k-label']")).replaceAll("\\D", "");
	int number = StringToInteger(pagenumber);
	do {
		List<WebElement> elegridDetails = getEventDriver().findElements(By.xpath("//div[@id='DAViewDetails']/div[2]/table/tbody/tr/td[2]/span"));
		for (WebElement details : elegridDetails) {
			String text = getText(details);
			System.out.println("Grid value from UI:" +text);
			text1.add(text);
			}

		String attributeText = getAttributeText(locateElement("xpath", "//div[@id='DAViewDetails']/div[3]/a[2]"), "data-page");
		System.out.println("attributeText:" +attributeText);
		page = StringToInteger(attributeText);
		page=page+sum;
		sum++;
		System.out.println("sum: "+ sum);
		System.out.println("page: "+ page);
		ClickNextPage();
	}
	while(number!=page);

	return this;
}

public ViewDespatchAdvice DBValidation(){
	String string = "";
	text2= new ArrayList<String>();
	Object[][] dataFromDb = getDataFromDb("select HDA_DA_Number from EIPPDSS.PDSSAL.SAL_H_Despatch_Advice where HDA_Date between '2018-07-16' and '2018-07-24'");
	for (Object[] objects : dataFromDb) {
		for (Object object : objects) {
					
			string = object.toString();
			text2.add(string);
			System.out.println("Text From DB:" +string);
		}


	}
	return this;

}




public ViewDespatchAdvice compareString() {
	if(text2.equals(text1)) {
		System.out.println("DB VALIDATION SUCCESSFULLY");	
	}else {
		System.out.println("DB VALIDATION FAILED");
	}
	return this;

}


public ViewDespatchAdvice clickDANumber() {
	text1= new ArrayList<String>();
	pause(3);
	int sum =0;
	int page = 0;
	String pagenumber = getText(locateElement("xpath", "//span[@class='k-pager-input k-label']")).replaceAll("\\D", "");
	int number = StringToInteger(pagenumber);
	do {
		List<WebElement> elegridDetails = getEventDriver().findElements(By.xpath("//div[@id='DAViewDetails']/div[2]/table/tbody/tr/td[2]/span"));
		for (WebElement details : elegridDetails) {
			String text = getText(details);
			System.out.println("Grid value from UI:" +text);
			text1.add(text);
			click(details);
			pause(3);
			WebDriverWait wait = new WebDriverWait(getEventDriver(), 10);
			wait.until(ExpectedConditions.visibilityOf(locateElement("id", "lblDANumber")));
			String daNumber = locateElement("id", "lblDANumber").getText();
			VerifyDANumber(text, daNumber);
			closeDAView();
		}

		String attributeText = getAttributeText(locateElement("xpath", "//div[@id='DAViewDetails']/div[3]/a[2]"), "data-page");
		System.out.println("attributeText:" +attributeText);
		page = StringToInteger(attributeText);
		page=page+sum;
		sum++;
		System.out.println("sum: "+ sum);
		System.out.println("page: "+ page);
		ClickNextPage();
	}
	while(number!=page);
	
	return this;

}


public ViewDespatchAdvice VerifyDANumber(String text1, String text2) {
	if(text1.equals(text2)) {
		reportStep("Text Matched", "Pass");
	}else {
		reportStep("Text Not Matched", "Fail");
	}
	
	return this;

}
@FindBy(how=How.ID,using="myDAViewModalClose")
public WebElement DAViewClose;
public ViewDespatchAdvice closeDAView() {
	click(DAViewClose);
	
	return this;

}





}