package pages;

import base.WdMethods;
public class AbstractPage extends WdMethods{
	public static String WindowMessage;


	

}
