package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class BBUEssentialsView extends AbstractPage  {

public BBUEssentialsView(){
	

		PageFactory.initElements(driver, this);

}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsCreate;
public BBUEssentialsCreate clickBBUEssentialsCreate(){
	click(eleBBUEssentialsCreate);
	return new BBUEssentialsCreate();
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsEdit;
public BBUEssentialsView clickBBUEssentialsEdit(){
	click(eleBBUEssentialsEdit);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsOrderNumber;
public BBUEssentialsView typeBBUEssentialsOrderNumber(String dataBBUEssentialsOrderNumber){
	type(eleBBUEssentialsOrderNumber, dataBBUEssentialsOrderNumber);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUProductCode;
public BBUEssentialsView selectUsingTextBBUProductCode(String dataBBUProductCode){
	selectUsingText(eleBBUProductCode, dataBBUProductCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsBBUCode;
public BBUEssentialsView selectUsingTextBBUEssentialsBBUCode(String dataBBUEssentialsBBUCode){
	selectUsingText(eleBBUEssentialsBBUCode, dataBBUEssentialsBBUCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsBBUDesc;
public BBUEssentialsView typeBBUEssentialsBBUDesc(String dataBBUEssentialsBBUDesc){
	type(eleBBUEssentialsBBUDesc, dataBBUEssentialsBBUDesc);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsGO;
public BBUEssentialsView clickBBUEssentialsGO(){
	click(eleBBUEssentialsGO);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUEssentialsReset;
public BBUEssentialsView clickBBUEssentialsReset(){
	click(eleBBUEssentialsReset);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsBBUCode;
public BBUEssentialsView verifyExactTextBBUDetailsBBUCode(String dataBBUDetailsBBUCode){
	verifyText(eleBBUDetailsBBUCode, dataBBUDetailsBBUCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsPartCode;
public BBUEssentialsView verifyExactTextBBUDetailsPartCode(String dataBBUDetailsPartCode){
	verifyText(eleBBUDetailsPartCode, dataBBUDetailsPartCode);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsPartDescription;
public BBUEssentialsView verifyExistsBBUDetailsPartDescription(){
	verifyExists(eleBBUDetailsPartDescription);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsQuantityProduct;
public BBUEssentialsView verifyExistsBBUDetailsQuantityProduct(){
	verifyExists(eleBBUDetailsQuantityProduct);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsWeightPiece;
public BBUEssentialsView verifyExistsBBUDetailsWeightPiece(){
	verifyExists(eleBBUDetailsWeightPiece);
	return this;
}
@FindBy(how=How.XPATH,using="Dummy")

public WebElement eleBBUDetailsTotalWeight;
public BBUEssentialsView verifyExistsBBUDetailsTotalWeight(){
	verifyExists(eleBBUDetailsTotalWeight);
	return this;
}


}
