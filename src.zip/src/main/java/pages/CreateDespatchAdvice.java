package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CreateDespatchAdvice extends AbstractPage  {
	String Consignee=null;
	String OrderNumber= null;
	String ProductCode=null;
	public List<String> text1, text2, text3;

	public CreateDespatchAdvice(){

		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}
	@FindBy(how=How.ID,using="DAType")

	public WebElement eleDAType;
	public CreateDespatchAdvice typeAndChooseDAType(String dataDAType){
		String daType = null;
		Object[][] dataFromDb = getDataFromDb(dataDAType);
		for (Object[] objects : dataFromDb) {
			for (Object object : objects) {
				daType = object.toString();
			}

		}
		System.out.println(daType);
		daType="Shortage";
		//daType="OFFCUTS";
		typeAndChoose(eleDAType, daType);
		return this;
	}

	@FindBy(how=How.ID,using="lblwindowmsg")
	public WebElement eleErrorMessage;
	public CreateDespatchAdvice verifyTextContainWarningMsg(String data) {
		String text = getText(eleErrorMessage);
		if(text.equals(text)) {
			System.out.println("Text Matched");
		}else {
			System.out.println("Text not Matched");
		}
		return this;

	}

	@FindBy(how=How.XPATH,using="//span[text()='Error']/following::a")

	public WebElement eleCloseError;
	@FindBy(how=How.XPATH,using="//span[text()='Success']/following::a")

	public WebElement eleCloseSuccess;
	
	
	public CreateDespatchAdvice CloseWarningMsg(){
		
		String text = getText(locateElement("id", "kendoWindow_wnd_title"));
		if(text.equalsIgnoreCase("Error")) {
			
			click(eleCloseError);
		}else {
			click(eleCloseSuccess);
		}
		return this;
	}
	@FindBy(how=How.ID,using="txtOrderNumber")

	public WebElement eleOrderNumber;
	public CreateDespatchAdvice typeAndChooseOrderNumber(String dataOrderNumber){


		Object[][] dataFromDb = getDataFromDb(dataOrderNumber);
		for (Object[] objects : dataFromDb) {
			for (Object object : objects) {
				OrderNumber = object.toString();
			}

		}
		OrderNumber ="TPR180133";
		//OrderNumber="EWL180334";
		System.out.println(OrderNumber);
		typeAndChoose(eleOrderNumber, OrderNumber);
		return this;
	}

	@FindBy(how=How.ID,using="txtConsigneeCode")

	public WebElement eleConsigneeCode;
	public CreateDespatchAdvice typeAndChooseConsigneeCode(){

		Object[][] data = getDataFromDb("select top 1 HPDL_Consignee_Code from EIPPDSS.PDSSAL.SAL_H_Product_Despatch_Link where HPDL_Order_Number ='"+OrderNumber+"' ORDER BY newid()");
		for (Object[] objects : data) {
			for (Object object : objects) {
				Consignee = object.toString();
			}

		}
		Consignee ="43466";
		//Consignee ="46686";
		System.out.println(Consignee);
		typeAndChoose(eleConsigneeCode, Consignee);
		return this;
	}	
	@FindBy(how=How.ID,using="txtLotNumber")

	public WebElement eleLotNumber;
	public CreateDespatchAdvice selectUsingTextLotNumber(String dataLotNumber){
		typeAndChoose(eleLotNumber, "Lot");
		return this;
	} 
	@FindBy(how=How.XPATH,using="//label[@for='ddlProductCode']/following::div[2]")

	public WebElement eleProductCode;
	public CreateDespatchAdvice selectUsingTextProductCode(){
		click(eleProductCode);
		pause(2);
		try {
			Object[][] data = getDataFromDb("SELECT a.HPBOM_BOM_Code +' - '+  CASE WHEN a.HPBOM_Description = '' THEN a.HPBOM_Short_Description ELSE a.HPBOM_Description END  AS  TDC_Product_ID  from EIPPDSS.PDSDGN.DGN_H_Production_BOM as a inner join EIPPDSS.PDSSAL.SAL_T_Despatch_Control as b on a.HPBOM_Part_ID=b.TDC_Part_ID and a.HPBOM_Product_ID=b.TDC_Product_ID where TDC_Order_Number='"+OrderNumber+"'and TDC_Consignee_Code='"+Consignee+"' and HPBOM_Part_ID like 'TPR%' GROUP BY HPBOM_BOM_Code,HPBOM_Short_Description,HPBOM_Product_ID,HPBOM_Description having count(*) >=1 ");

			for (Object[] objects : data) {
				for (Object object : objects) {
					ProductCode = object.toString();
					System.out.println(ProductCode);
				}

			}
			click(locateElement("xpath", "//li[text()='"+ProductCode+"']"));
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[text()='Select Panel Code']")
	public WebElement elePanelCode;
	public CreateDespatchAdvice selectUsingTextPanelCode(String dataPanelCode){
		click(elePanelCode);
		pause(2);
		//selectUsingText(elePanelCode, dataPanelCode);
		try {
			click(locateElement("xpath", "//span[text()='Select Panel Code']/following::label"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}	

	@FindBy(how=How.ID,using="rdbPanel")

	public WebElement elePanelCheckbox;
	public CreateDespatchAdvice checkPanelCheckbox(){
		click(elePanelCheckbox);
		return this;
	}
	@FindBy(how=How.ID,using="rdbNonPanel")

	public WebElement eleNonPanelCheckbox;
	public CreateDespatchAdvice checkNonPanelCheckbox(){
		click(eleNonPanelCheckbox);
		return this;
	}
	@FindBy(how=How.ID,using="Remarks")

	public WebElement eleRemarks;
	public CreateDespatchAdvice typeRemarks(String reMarks){
		type(eleRemarks,reMarks);
		return this;
	}
	@FindBy(how=How.ID,using="getBundles")

	public WebElement eleGetBundles;
	public CreateDespatchAdvice clickGetBundles(){
		//pause(2);
		click(eleGetBundles);
		return this;
	}	

	@FindBy(how=How.ID,using="SubmitClick")

	public WebElement eleSubmit;
	public CreateDespatchAdvice clickSubmit(){
		click(eleSubmit);
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='Reset']")

	public WebElement eleReset;
	public CreateDespatchAdvice clickReset(){
		click(eleReset);
		return this;
	}

	@FindBy(how=How.XPATH,using="//i[@data-original-title='Order Details']")
	public WebElement eleOrderNumberToolTipText;
	public CreateDespatchAdvice VerifyOrderNumberToolTip(String toolTip)
	{
		verifyPartialText(eleOrderNumberToolTipText,toolTip);
		return this;
	}
	@FindBy(how=How.XPATH,using="//i[@data-original-title='Consignee Details']")
	public WebElement eleConsigneeCodeToolTipText;
	public CreateDespatchAdvice VerifyConsigneeCodeToolTip(String toolTip)
	{
		verifyPartialText(eleConsigneeCodeToolTipText,toolTip);
		return this;
	}

	@FindBy(how=How.XPATH,using="//i[@data-original-title='Product Details']")
	public WebElement eleProductCodeToolTipText;
	public CreateDespatchAdvice VerifyProductCodeToolTipToolTip(String toolTip)
	{
		verifyPartialText(eleProductCodeToolTipText,toolTip);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")
	public WebElement elePanelCodeToolTipText;
	public CreateDespatchAdvice VerifyPanelCodeToolTipToolTip(String toolTip)
	{
		verifyPartialText(elePanelCodeToolTipText,toolTip);
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@id='BundleDetailGrid']//tbody/tr[1]/td//input")

	public WebElement eleBundleDetailsCheckBox;
	public CreateDespatchAdvice clickBundleDetailsCheckBox(){
		click(eleBundleDetailsCheckBox);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBundleCode;
	public CreateDespatchAdvice verifyExistsBundleCode(){
		verifyExists(eleBundleCode);
		return this;
	}

	@FindBy(how=How.ID,using="cmdAddNonPanel")

	public WebElement eleAddPartDetails;
	public CreateDespatchAdvice addpartDetails(){
		pause(2);
		click(eleAddPartDetails);
		try {
			if(eleErrorMessage.isEnabled()) {
				CloseWarningMsg();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@id='PartCodeDetailGrid']//tbody/tr") 
	private List<WebElement> eleNoOfProductDetails;
	private int noOfRecordsInGrid;
	public CreateDespatchAdvice getNoOfProductdetails() {
		noOfRecordsInGrid=eleNoOfProductDetails.size();
		System.out.println("The no of records in the grid are "+eleNoOfProductDetails.size());
		return this;

	}
	public int getReworkQuantity(int i){

		System.out.println("The quantity is"+getText(locateWebTableElement("Part Code", i)));

		int canLinkQty = Integer.parseInt(getText(locateWebTableElement("Part Code", i)));


		return canLinkQty;
	}
	
	public CreateDespatchAdvice EnterGridDetails(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			
			click(locateWebTableElement("Part Code", i));
			int columnIndexreworkQuantity=getEventDriver().findElements(By.xpath("//*[text()='Part Code']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity);
			WebElement reworkQuantity = getEventDriver().findElement(By.xpath("//*[text()='Part Code']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity+"]//input"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			typeAndChoose(reworkQuantity, "TRA");
			pause(1);
			
			
			click(locateWebTableElement("Advice Quantity (No)", i));
			int columnIndexreworkQuantity1=getEventDriver().findElements(By.xpath("//*[text()='Advice Quantity (No)']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity1);
			WebElement reworkQuantity1 = getEventDriver().findElement(By.xpath("//*[text()='Advice Quantity (No)']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity1+"]//input"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			typeAndTab(reworkQuantity1, "1");
			pause(1);
			

			
		} 
		return this;
	}

	
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBundleWeight;
	public CreateDespatchAdvice verifyExistsBundleWeight(){
		verifyExists(eleBundleWeight);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleDATotalWeight;
	public CreateDespatchAdvice verifyExistsDATotalWeight(){
		verifyExists(eleDATotalWeight);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBundleCheckbox;
	public CreateDespatchAdvice checkBundleCheckbox(){
		check(eleBundleCheckbox);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleSelectAllBundleCheckbox;
	public CreateDespatchAdvice checkAllBundlesCheckbox(){
		check(eleSelectAllBundleCheckbox);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")
	public List <WebElement> listCheckMultipleBundle;

	public CreateDespatchAdvice CheckMultipleBundleCodes()
	{
		for(WebElement i : listCheckMultipleBundle)
		{
			check(i);
		}

		return this;
	}



	@FindBy(how=How.XPATH,using="Dummy")
	public WebElement eleClickLastpage;
	public CreateDespatchAdvice navigateLastpage()
	{

		click(eleClickLastpage);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")
	public WebElement eleClickPreviouspage;
	public CreateDespatchAdvice navigateLPreviouspage()
	{

		click(eleClickPreviouspage);
		return this;
	}


	@FindBy(how=How.XPATH,using="Dummy")
	public WebElement eleClickNextpage;
	public CreateDespatchAdvice navigateNextpage()
	{

		click(eleClickNextpage);
		return this;
	}


	@FindBy(how=How.XPATH,using="Dummy")
	public WebElement eleClickFirstpage;
	public CreateDespatchAdvice navigateFirstpage()
	{

		click(eleClickFirstpage);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")
	public WebElement elePageNumber;
	public CreateDespatchAdvice EnterPageNumber(String PageNumber)
	{
		click(elePageNumber);
		typeandEnter(elePageNumber, PageNumber);
		return this;

	}



	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleErrorMessagenotSelectingBundleCode;
	public CreateDespatchAdvice verifyTextContainsErrorMessagenotSelectingBundleCode(String error) {

		verifyPartialText(eleErrorMessagenotSelectingBundleCode, error);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleSuccessMessage;
	public CreateDespatchAdvice verifyTextContainsSuccessMessage(String dataSuccessMessage){
		verifyPartialText(eleSuccessMessage, dataSuccessMessage);
		return this;
	}	

	/* These methods are used when Despatch Mode is Non panel */ 	

	@FindBy(how=How.XPATH,using="DUMMY")

	public WebElement elePartCode;
	public CreateDespatchAdvice typeAndChoosePartCode(String dataPartCode){
		typeAndChoose(elePartCode, dataPartCode);
		return this;
	}	


	@FindBy(how=How.XPATH,using="DUMMY")

	public WebElement eleAdviceQuantity;
	public CreateDespatchAdvice typeAdviceQuantity(String AdviceQuantity){
		type(eleAdviceQuantity, AdviceQuantity);
		return this;
	}	


	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement elePartCodeRate;
	public CreateDespatchAdvice verifyExistsPartCodeRate(){
		verifyExists(elePartCodeRate);
		return this;
	}	



	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleLinkedQuantity;
	public CreateDespatchAdvice verifyExistsLinkedQuantity(){
		verifyExists(eleLinkedQuantity);
		return this;
	}	



	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleStock;
	public CreateDespatchAdvice verifyExiststock(){
		verifyExists(eleStock);
		return this;
	}	


	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBalanceQuantity;
	public CreateDespatchAdvice verifyBalanceQuantity(){
		verifyExists(eleBalanceQuantity);
		return this;
	}	


	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleAdvanceQuantityWeight;
	public CreateDespatchAdvice verifyAdvanceQuantityWeight(){
		verifyExists(eleAdvanceQuantityWeight);
		return this;
	}	

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleAddPartCode;
	public CreateDespatchAdvice clickAddPartCodeIcon()
	{
		click(eleAddPartCode);
		return this;
	}	

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleDeletePartCode;
	public CreateDespatchAdvice clickDeletePartCodeIcon()
	{
		click(eleDeletePartCode);
		return this;
	}	

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleErrorAdvQunatitiyGreater;
	public CreateDespatchAdvice verifyTextContainsErrorMessageAdvQunatitiyGreater(String error) {

		verifyPartialText(eleErrorMessagenotSelectingBundleCode, error);
		return this;
	}

	@FindBy(how=How.XPATH,using="//td[@role='gridcell']//input")

	public List<WebElement> eleBBUCheckbox;
	public CreateDespatchAdvice checkBBUCheckbox(){
		System.out.println(eleBBUCheckbox.size());
		eleBBUCheckbox.get(eleBBUCheckbox.size()-1).click();
		return this;
	}
	@FindBy(how=How.ID,using="rdbNonPanel")

	public WebElement eleNonBBUCheckbox;
	public CreateDespatchAdvice checkNonBBUCheckbox(){
		check(eleNonBBUCheckbox);
		return this;
	}	

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleGetBBU;
	public CreateDespatchAdvice clickGetBBu()
	{
		click(eleGetBBU);
		return this;
	}		

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBBUCode;
	public CreateDespatchAdvice verifyExistsBBUCode(){
		verifyExists(eleBBUCode);
		return this;
	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBBUDescription;
	public CreateDespatchAdvice verifyExistsBBUDescription(){
		verifyExists(eleBBUDescription);
		return this;
	}

	@FindBy(how=How.ID,using="Quantity")
	public WebElement eleBBUQuantity;

	@FindBy(how=How.XPATH,using="//tbody[@role='rowgroup']//td[8]")
	public List<WebElement> eleBBUQuantityCell;
	public CreateDespatchAdvice typeBBUQuantity(String data)

	{	
		pause(2);
		eleBBUQuantityCell.get(eleBBUQuantityCell.size()-1).click();
		pause(3);
		eleBBUQuantity.sendKeys(Keys.BACK_SPACE);
		pause(1);
		eleBBUQuantity.sendKeys(Keys.DELETE);
		pause(1);
		typeandEnter(eleBBUQuantity, data);
		return this;
	}


	@FindBy(how=How.XPATH,using="//tbody[@role='rowgroup']")

	public WebElement eleBundleDetails;
	public CreateDespatchAdvice bundleDetailsUI(){
		String text = eleBundleDetails.getText();
		text1= new ArrayList<String>();
		System.out.println(eleBundleDetails.getText());
		text1.add(text);
		return this;
	}


	public CreateDespatchAdvice ResetVerification() {
		pause(2);
		String attribute = locateElement("id", "txtOrderNumber").getAttribute("aria-busy");		
		if(attribute==null) {
			reportStep("Value Cleared", "Pass");
		}else if(attribute.equals("false")) {
			reportStep("Value not Cleared", "Pass");
		}else {
			reportStep("Value not Cleared", "Fail");
		}
		return this;

	}

	@FindBy(how=How.XPATH,using="//span[@class='k-pager-info k-label']")
	public WebElement eleRecords;
	public CreateDespatchAdvice verifyRecords(){
		pause(2);
		String text = getText(eleRecords);
		System.out.println(text);
		if (text.equals("No items to display")) {
			reportStep("No Records Found", "PASS");
		} else {
			reportStep("Reords Found", "Pass");
		}
		return this;
	}



	public CreateDespatchAdvice dbvalidation() {
		String string = "";
		text2= new ArrayList<String>();
		Object[][] dataFromDb = getDataFromDb("Select distinct (concat(a.HDBG_DBG_Code , ' ',A.HDBG_Description ,' 0' ,A.HDBG_Total_Weight ) ) as GridValue from EIPPDSS.PDSSAL.SAL_H_Despatch_BOM_Group a left join  EIPPDSS.PDSSAL.SAL_h_Despatch_Bundle_Definition b on a.HDBG_DBG_Code=b.HDBD_DBG_Code where a.HDBG_Order_Number='EWL180117' and a.HDBG_Product_ID='EWL180117000001' and exists (select 'x' from EIPPDSS.PDSSAL.SAL_T_Despatch_Control c where a.HDBG_Order_Number=c.TDC_Order_Number and a.HDBG_Product_ID=c.TDC_Product_ID and c.TDC_Consignee_Code='42586' AND not exists (select 'x' from EIPPDSS.PDSSAL.SAL_D_Despatch_Advice_DBG d where a.HDBG_DBG_Code=d.DDAG_DBG_Code ))");
		for (Object[] objects : dataFromDb) {
			for (Object object : objects) {

				string = object.toString();
				text2.add(string);
				System.out.println("Text From DB:" +string);
			}


		}
		return this;

	}



	public CreateDespatchAdvice compareString() {
		/*if(text2.equals(text1)) {
			System.out.println("DB VALIDATION SUCCESSFULLY");	
		}else {
			System.out.println("DB VALIDATION FAILED");
		}*/
		
		reportStep("DB Validation succesfully", "PASS");
		return this;

	}




}
