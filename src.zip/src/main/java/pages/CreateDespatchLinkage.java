package pages;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.When;



public class CreateDespatchLinkage extends AbstractPage {
	
public static String dialogMessage,muName,orderNumber,consigneeCode,despatchLinkageNumber,dialogTitle,lotNumber;


	public CreateDespatchLinkage(){ 

		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);
 
	}

	@FindBy(how=How.ID,using="view")
	WebElement eleview;
	public ViewDespatchLinkage clickView()
	{
		click(eleview);
		return new ViewDespatchLinkage();
	}

	@FindBy(how=How.CLASS_NAME,using="mandatory-star")
	private List<WebElement> eleMandatory;

	public CreateDespatchLinkage verifyMandatoryFields()
	{
		String[] elements = {"Order Number","Consignee Code","Lot Number"};
		System.out.println(verifyMandatory(elements));
		return this;

	}
	@FindBy(how=How.XPATH,using="//input[@id='OrderNumber']/../following-sibling::i")

	public WebElement eleClickOrderinfo;
	public CreateDespatchLinkage clickOrderinfo(){
		click(eleClickOrderinfo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@class='popover fade bottom in']")

	public WebElement eleGetIconinfo;
	public CreateDespatchLinkage verifyInfoDetails(){
		String text = getText(eleGetIconinfo);
		System.out.println(text);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ConsigneeCode']/../following-sibling::i")

	public WebElement eleConsigneeinfo;
	public CreateDespatchLinkage clickConsigneeInfo(){
		click(eleConsigneeinfo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//a[@class='showroles']/img")
	private WebElement eleRoles;
	public CreateDespatchLinkage clickRoles() throws InterruptedException
	{
		click(eleRoles);
		Thread.sleep(2000);
		muName=getText(locateElement("id","factoryDescription"));
		System.out.println( "The factory selected is "+muName);
		return new CreateDespatchLinkage();
	}
	

	
	@FindBy(how=How.ID,using="OrderNumber")
	
	public WebElement eleOrderNumber;
	@When ("The orderNumber entered")
	public CreateDespatchLinkage typeOrderNumber(String username,String factoryName){
		
	String orderNumbersql="select top 1 HJORD_Order_Number from eippdss.PDSSAL.SAL_H_Job_Orders  WHERE  HJORD_Order_Number in (select hpl_order_number from eippdss.PDSPLN.PLN_H_Production_Linkage h inner join eippdss.PDSPLN.PLN_D_Production_Linkage d on h.HPL_PL_Number=d.DPL_PL_Number where d.DPL_Batch_Quantity !=0) and HJORD_Order_Number in (select distinct HJORD_Order_Number from eippdss.PDSSAL.SAL_H_Job_Orders inner join  eippdss.PDSPLN.PLN_H_Production_Linkage on HJORD_Order_Number=HPL_Order_Number where hpl_lot_number in ( select hpl_lot_number from eippdss.PDSPLN.PLN_H_Production_Linkage  where hpl_lot_number not in( select hpl_lot_number from eippdss.PDSPLN.PLN_H_Production_Linkage  inner join eippdss.PDSSAL.SAL_H_Product_Despatch_Link on hpl_lot_number=hpdl_lot_number )) ) and HJORD_DS_Code = 3 and HJORD_Job_Code in(SELECT (LUJDO_Job_Code) FROM eip.SQLACS.ACS_L_User_Job_Document_Operations WHERE LUJDO_DT_Code IN (Select MDOCT_DT_Code from EIP.SQLMAS.GEN_M_Document_Transaction WHERE MDOCT_Name = 'Despatch Linkage') and LUJDO_User_ID IN (SELECT MUSER_USER_ID FROM EIP.SQLMAS.GEN_M_Users WHERE MUSER_Login_Name = '"+username+"') group By LUJDO_Job_Code having count(LUJDO_Job_Code)=2) and HJORD_MU_Code in (select mmu_mu_code from EIPPDSS.PDSMAS.GEN_M_Manufacturing_Units where MMU_Name='"+factoryName+"') ORDER BY newid()";
		//System.out.println(orderNumbersql);
		Object[][] dataFromDb = getDataFromDB(orderNumbersql);
		String[] string= {""};
	
		for(Object[] eachObject:dataFromDb)
		{
			
			for(int i=0;i<eachObject.length;i++) 
			{
				
				 string[i] = string[i]+eachObject[i].toString(); 
				 System.out.println(string[i]);
				 orderNumber=string[i];
				 typeAndChoose(eleOrderNumber,orderNumber);
			}
		}
		//typeAndChoose(eleOrderNumber,"EWL180253");
		return this;
	}

	public CreateDespatchLinkage getorderNumber()
	{
			System.out.println("The order number chose is "+getAttributeText(eleOrderNumber, "value"));
			return this;
	}
	
	public CreateDespatchLinkage typeOrderNumberNegative(String username,String factoryName){
		boolean present;
		String orderNumbersql="select top 1 HJORD_Order_Number from eippdss.PDSSAL.SAL_H_Job_Orders  WHERE  HJORD_Order_Number in (select hpl_order_number from eippdss.PDSPLN.PLN_H_Production_Linkage h inner join eippdss.PDSPLN.PLN_D_Production_Linkage d on h.HPL_PL_Number=d.DPL_PL_Number where d.DPL_Batch_Quantity !=0) and HJORD_Order_Number in (select distinct HJORD_Order_Number from eippdss.PDSSAL.SAL_H_Job_Orders inner join  eippdss.PDSPLN.PLN_H_Production_Linkage on HJORD_Order_Number=HPL_Order_Number where hpl_lot_number in ( select hpl_lot_number from eippdss.PDSPLN.PLN_H_Production_Linkage  where hpl_lot_number not in( select hpl_lot_number from eippdss.PDSPLN.PLN_H_Production_Linkage  inner join eippdss.PDSSAL.SAL_H_Product_Despatch_Link on hpl_lot_number=hpdl_lot_number )) ) and HJORD_DS_Code = 3 and HJORD_Job_Code in(SELECT (LUJDO_Job_Code) FROM eip.SQLACS.ACS_L_User_Job_Document_Operations WHERE LUJDO_DT_Code IN (Select MDOCT_DT_Code from EIP.SQLMAS.GEN_M_Document_Transaction WHERE MDOCT_Name = 'Despatch Linkage') and LUJDO_User_ID IN (SELECT MUSER_USER_ID FROM EIP.SQLMAS.GEN_M_Users WHERE MUSER_Login_Name = '"+username+"') group By LUJDO_Job_Code having count(LUJDO_Job_Code)=2) and HJORD_MU_Code not in (select mmu_mu_code from EIPPDSS.PDSMAS.GEN_M_Manufacturing_Units where MMU_Name='"+factoryName+"') ORDER BY newid()";
		//System.out.println(orderNumbersql);
		Object[][] dataFromDb = getDataFromDB(orderNumbersql);
		String[] string= {"",""};
	
		for(Object[] eachObject:dataFromDb)
		{
			
			for(int i=0;i<eachObject.length;i++) 
			{
				
				 string[i] = string[i]+eachObject[i].toString(); 
				 System.out.println(string[i]);
				 orderNumber=string[i];
				 
				 type(eleOrderNumber,orderNumber);
				 try {
					locateElement("xpath", "//ul[@id='OrderNumber_listbox']/li");
					present=true;
					 			
				 }catch(Exception e)
				 {
					 present = false;
					 System.out.println("The ordernumber which doesnot belong to the selected fctory is not autopopulated");
				 }
				 if(present)
					 System.out.println("The ordernumber which doesnot belong to the selected fctory is autopopulated");

			}
		}
		
		return this;
	}


	@FindBy(how=How.ID,using="ConsigneeCode")
 
	public WebElement eleConsignee;
	@When ("Enter the  Consignee Code")
	public CreateDespatchLinkage typeConsignee(String factoryName){
		String consigneeNumSql="SELECT top 1 CL.Consignee_Location_Code FROM CRM.dbo.CRM_L_Invoic_Consignee_Location_Details CLD LEFT JOIN crm.dbo.CRM_M_Invoice_Consignee_Location CL ON  CL.Consignee_Location_Code=CLD.Consignee_Location_Code LEFT JOIN eip.sqlmas.GEN_U_Countries c1 ON Consignee_Country = c1.UCOUN_Country_Code LEFT JOIN EIP.sqlmas.GEN_U_States s1 ON Consignee_State = s1.USTAT_State_Code AND c1.UCOUN_Country_Code=s1.USTAT_Country_Code LEFT JOIN EIP.SQLMAS.GEN_U_Districts d1 ON Consignee_District = d1.UDIS_District_Code AND c1.UCOUN_Country_Code=d1.UDIS_Country_Code AND s1.USTAT_State_Code=d1.UDIS_State_Code LEFT JOIN eip.sqlmas.GEN_U_Cities ci1 ON Consignee_City = ci1.UCITY_City_Code AND c1.UCOUN_Country_Code=ci1.UCITY_Country_Code AND s1.USTAT_State_Code=ci1.UCITY_State_Code AND d1.UDIS_District_Code=ci1.UCITY_District_Code LEFT JOIN eip.SQLMAS.GEN_U_Areas a1 ON Consignee_Area = a1.UAREA_Area_Code AND a1.UAREA_Country_Code=c1.UCOUN_Country_Code AND a1.UAREA_State_Code=s1.USTAT_State_Code AND a1.UAREA_District_Code=d1.UDIS_District_Code AND a1.UAREA_City_Code=ci1.UCITY_City_Code WHERE CLD.Job_Code in(select MMU_AC_Code from eippdss.PDSMAS.GEN_M_Manufacturing_Units where MMU_Name ='"+factoryName+"') and cld.invoice_type = 'O' and exists(select top 1 'x' from crm.dbo.CRM_M_Invoice_Consignee_Location micl where cld.Consignee_Location_Code = micl.Consignee_Location_Code) and CL.Consignee_Location_Code NOT in (45967,45968,45969,45970,45971) order by newid()";
		Object[][] dataFromDb = getDataFromDB(consigneeNumSql);
		String[] string= {"",""};
		for(Object[] eachObject:dataFromDb)
		{
			for(int i=0;i<eachObject.length;i++)
			{
				 string[i] = string[i]+eachObject[i].toString();
				 System.out.println(string[i]);
				 consigneeCode=string[i];
				 typeAndChoose(eleConsignee,consigneeCode);
			}
		}
		
		return this;
	}

	public CreateDespatchLinkage getConsigneeCode()
	{
			System.out.println("The consignee number chose is "+getAttributeText(eleConsignee, "value"));
			return this;
	}
	
	
	@FindBy(how=How.XPATH,using="(//span[text()='select'])[1]")   

	public WebElement eleSelectLotNumber;

	public CreateDespatchLinkage clickLotNumber(){
		click(eleSelectLotNumber);
		return this;
	}



	@FindBy(how=How.XPATH,using="(//span[text()='select'])[2]/../preceding-sibling::span")   

	public WebElement eleItemsDropdownText;

	public CreateDespatchLinkage getItemsDropdownText(){

		System.out.println(getText(eleItemsDropdownText));
		return this;
	}

	
	@FindBy(how=How.XPATH,using="//li[@id='LotNumber_option_selected']/following-sibling::li")
	private List<WebElement> eleLotNumber;
	@When ("Select the lot number")
	public CreateDespatchLinkage VerifyLotNumbers()
	{
		String verifyLotNumberSql="select hpl_lot_number from eippdss.PDSPLN.PLN_H_Production_Linkage where HPL_Order_Number ='"+orderNumber+"'";
		Object[][] dataFromDb = getDataFromDB(verifyLotNumberSql);
		String[] string= {"",""};
		if(eleLotNumber.size()==dbRowCount)
			System.out.println("Lot numbers in the UI and from DB got matched");
		else
			System.out.println("Lot numbers in the UI and from DB are not matched");
	
		return this;
	}
	public CreateDespatchLinkage  verifyProductCodeColumn()
	{
		for(int i=1;i<noOfRecordsInGrid;i++) {
			//locateWebTableElement("", rowIndex)

		}
		return this;

	}

	
	public CreateDespatchLinkage enterLotNumber(String lotNumber)
	{
		
		 selectUsingText(locateElement("xpath", "//li[text()='"+lotNumber+"']"),lotNumber);
		return this;
		
		
	}
		
	
	public CreateDespatchLinkage enterLotNumber()
	{
		String lotNumbersql="select top 1 hpl_lot_number from eippdss.PDSPLN.PLN_H_Production_Linkage where HPL_Order_Number ='"+orderNumber+"' and hpl_lot_number not in (select HPDL_LOT_Number from eippdss.pdssal.sal_h_product_despatch_link where HPDL_Order_Number='"+orderNumber+"') order by newid()";
		Object[][] dataFromDb = getDataFromDB(lotNumbersql);
		String[] string= {"",""};
		for(Object[] eachObject:dataFromDb)
		{
			for(int i=0;i<eachObject.length;i++)
			{
				 string[i] = string[i]+eachObject[i].toString();
				 System.out.println(string[i]);
				 lotNumber=string[i];
				 selectUsingText(locateElement("xpath", "//li[text()='"+string[i]+"']"),string[i]);
			}
		}
		
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@class='k-input']")
	private WebElement eleLotChosen;
	public CreateDespatchLinkage getLotNumber()
	{
		System.out.println("The lotNumber chose is "+getText(eleLotChosen));
		return this;
	}
	
	
	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleGo;
	@And ("Click Get Products")

	public CreateDespatchLinkage clickGetProducts(){
		click(eleGo);
	
		return this;
	}


	@FindBy(how=How.XPATH,using="//span[@class='k-pager-info k-label']")//grid right corner message

	public WebElement eleDisplayItems;

	public CreateDespatchLinkage getDisplayOfItems(){
		System.out.println(getText(eleDisplayItems)); 
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@class='k-pager-sizes k-label']")

	public WebElement eleItemsPerPage;

	public CreateDespatchLinkage getItemsPerPage(){
		
		System.out.println(eleItemsPerPage.getText());
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@class='k-pager-sizes k-label']//span[text()='select']")

	public WebElement eleItemsPerPageDropdown;

	public CreateDespatchLinkage clickItemsPerPageDropdown(){
		
		click(eleItemsPerPageDropdown);
		return this;
	}

	

	public CreateDespatchLinkage selectItemsPerPage(int numberOfItems){
	
		
		click(locateElement("xpath", "//li[text()='"+numberOfItems+"']")) ;
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[text()='seek-w']")

	public WebElement eleLeftDoubleArrow;

	public CreateDespatchLinkage clickDoubleLeftArrow(){ 
		click(eleLeftDoubleArrow);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']")

	public WebElement eleLeftArrow;

	public CreateDespatchLinkage clickLeftArrow(){
		click(eleLeftArrow);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")

	public WebElement eleRightArrow;

	public CreateDespatchLinkage clickRightArrow(){
		click(eleRightArrow);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[text()='seek-e']")

	public WebElement eleRightDoubleArrow;

	public CreateDespatchLinkage clickDoubleRightArrow(){
		click(eleRightDoubleArrow);
		return this;
	}

	@FindBy(how=How.ID,using="btnyes")    

	public WebElement eleYesConfirmation;
	@When ("Click on Yes")
	public CreateDespatchLinkage clickYesConfirmation(){
		System.out.println(getText(eleYesConfirmation));
		click(eleYesConfirmation);
		return this;
	}


	@FindBy(how=How.ID,using="btnno")    

	public WebElement eleNoConfirmation;
	@When ("Click on Yes")
	public CreateDespatchLinkage clickNoConfirmation(){
		System.out.println(getText(eleYesConfirmation));
		click(eleNoConfirmation);
		return this;
	}
/*
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following-sibling::div/a")    
	public WebElement eleSuccess;
	public CreateDespatchLinkage closeSuccess(){
		click(eleSuccess);
		return this; 
	}*/




	/*@FindBy(how=How.ID,using="lblwindowmsg")    
	public WebElement eleMessage;
	public CreateDespatchLinkage getDispatchLinkageNumber(){
		System.out.println(getText(eleMessage));
		return this;
	}
*/

	@FindBy(how=How.ID,using="btnSubmit")    

	public WebElement eleSubmit;
	@When ("Click on submit")
	public CreateDespatchLinkage clickSubmit(){
		if(eleSubmit.isEnabled())
			click(eleSubmit);
		else
			reportStep("The Submit button is not enabled","FAIL");
		return this;
	}


	public CreateDespatchLinkage verifyInsertionOfDLNum()
	{
	
		String Hsql="select hpdl_lot_number from eippdss.PDSSAL.SAL_H_Product_Despatch_Link where hPDL_DL_Number='"+despatchLinkageNumber+"'";
		
		System.out.println(Hsql);
		Object[][] dataFromDb = getDataFromDB(Hsql);
		
		String[] string= {"",""};
		for(Object[] eachObject:dataFromDb)
		{
			for(int i=0;i<eachObject.length;i++)
			{
				 string[i] = string[i]+eachObject[i].toString();
				 System.out.println(string[i]);
			}
		}
		/*if(dbRowCount!=0)
			System.out.println("The entry of despatch linkageNumber is present in H table");
		else
			System.out.println("The entry of despatch linkageNumber is not present in H table");
		
		String Dsql="select * from eippdss.PDSSAL.SAL_D_Product_Despatch_Link where DPDL_DL_Number='"+despatchLinkageNumber+"'";
		getDataFromDB(Dsql);
		if(dbRowCount!=0)
			System.out.println("The entry of despatch linkageNumber is present in D table");
		else
			System.out.println("The entry of despatch linkageNumber is not present in D table");*/
		
		return this;
		
	}
	@FindBy(how=How.ID,using="btnReset")

	public WebElement eleReset;
	public CreateDespatchLinkage clickReset(){
		click(eleReset);
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@id='grdDespatchLinkage']//tbody/tr")
	List<WebElement> elerecords;
	public int noOfRecordsInGrid;
	public CreateDespatchLinkage getNumberOfDispatchRecords()
	{
		System.out.println("rows are"+elerecords.size());
		noOfRecordsInGrid= elerecords.size();
		return this;
	}

	
	public int getToBeLinkedQuantity(int i){

		System.out.println("The quantity is"+getText(locateWebTableElement("Quantity", i)));
		System.out.println("The quantity is"+getText(locateWebTableElement("Previous Linked Quantity", i)));
		int canLinkQty = Integer.parseInt(getText(locateWebTableElement("Quantity", i))) - Integer.parseInt(getText(locateWebTableElement("Previous Linked Quantity", i)));
		int quantity= new Random().nextInt((canLinkQty-1)+1);
		//System.out.println(quantity);
		return quantity;
	}

	public int getQuantity(int i){
		return Integer.parseInt(getText(locateWebTableElement("Quantity", i)));
	}


	@And ("Enter the quantity to be linked")
	

	public CreateDespatchLinkage enterQuantityForAllToBeLinked() {

		
		if(noOfRecordsInGrid>0) {
		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			click(locateWebTableElement("To be Linked", i));
			WebElement linkedQty = locateElement("xpath", "(//textarea[@placeholder='Enter Linked Quantity'])["+i+"]");
			type(linkedQty, ""+(getToBeLinkedQuantity(i)+1));
		}
		}
		/*else
			ele*/
		
		return this;
	}

	public CreateDespatchLinkage enterQuantityZero() {

		
		
		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			
			click(locateWebTableElement("To be Linked", i));
			WebElement linkedQty = locateElement("xpath", "(//textarea[@placeholder='Enter Linked Quantity'])["+i+"]");
			type(linkedQty, "0");
			}
		

		return this;
	}
	
	@And ("Enter the quantity to be linked")
	public CreateDespatchLinkage enterQuantityAboveExpected() {

		
		for (int i = 1; i <= noOfRecordsInGrid; i++) {
		click(locateWebTableElement("To be Linked",i));
		WebElement linkedQty = locateElement("xpath", "(//textarea[@placeholder='Enter Linked Quantity'])["+i+"]");
		try {
		typeAndTab(linkedQty, ""+(getQuantity(1)+1));
		}catch(Exception e)
		{
			System.out.println("Enter quantity is more than expected");
		}
		finally
		{
			getdialogTitle();
			getdialogMsg();
			CloseMessage();
			if(CreateDespatchLinkage.dialogTitle.contains("Error")&&CreateDespatchLinkage.dialogMessage.contains("Previous Linked Quantity + To be Linked Quantity should not be greater than Total Quantity."))
				System.out.println("To be linked more than balance validation success");
			else
				System.out.println("To be linked more than balance validation not success");
			
		}
		}
		return this;
	}


	
	@FindBy(how=How.ID,using="kendoWindow_wnd_title")
	public WebElement eledialogTitle;
	public CreateDespatchLinkage getdialogTitle() 
	{
		System.out.println(getText(eledialogTitle));
		dialogTitle=getText(eledialogTitle);
		return this;
	}


	@FindBy(how=How.ID,using="lblwindowmsg")
	private WebElement eledialogMsg;
	public CreateDespatchLinkage getdialogMsg() 
	{
		dialogMessage = getText(eledialogMsg);		
		String[] split= {""};
		if(dialogMessage.contains("Despatch Linkage")) {
			split = dialogMessage.split(" ");
			despatchLinkageNumber=split[3];
		}
		
		System.out.println(dialogMessage);
		return this;
	}


	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	public WebElement closeMessage; 
	public CreateDespatchLinkage  CloseMessage()
	{
		click(closeMessage);
		return this;
	}
	


}
