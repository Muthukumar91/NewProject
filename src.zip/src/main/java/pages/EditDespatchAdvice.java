package pages;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class EditDespatchAdvice extends AbstractPage {
	public List<String> text1, text2, text3;

	public EditDespatchAdvice(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	
	@FindBy(how=How.XPATH,using="//input[@id='FromDate']/following::span")
	public WebElement eleFromDateicon;
	public EditDespatchAdvice clickFromDateicon(String Year, String month, String day, String date){
		int input = StringToInteger(date);
		input= input-1;
		pause(2);
		click(eleFromDateicon);
		pause(2);
		click(locateElement("xpath", "//div[@id='FromDate_dateview']//a[2]"));
		pause(2);
		click(locateElement("xpath", "//div[@id='FromDate_dateview']//a[2]"));
		pause(2);
		click(locateElement("linkText", Year));

		pause(2);
		click(locateElement("linkText", month));

		click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));


		return this;
	}

	

	@FindBy(how=How.XPATH,using="//input[@id='ToDate']/following::span")
	public WebElement eleToDateicon;
	public EditDespatchAdvice clickToDateicon(String Year, String month, String day, String date){
		
		int input = StringToInteger(date);
		input= input-1;
		pause(2);
		click(eleToDateicon);
		pause(2);
		click(locateElement("xpath", "//div[@id='ToDate_dateview']//a[2]"));
		pause(2);
		click(locateElement("xpath", "//div[@id='ToDate_dateview']//a[2]"));
		pause(2);
		click(locateElement("linkText", Year));

		pause(2);
		click(locateElement("linkText", month));

		click(locateElement("xpath", "(//a[@data-value='"+Year+"/"+day+"/"+date+"'])[2]"));

		return this;
	}
	
	@FindBy(how=How.ID,using="DANumber")

	public WebElement eleDANumber;
	public EditDespatchAdvice typeDANumber(String data){
		
		data="";
		type(eleDANumber, data);
		return this;
	}
	
	
	@FindBy(how=How.ID,using="submit")

	public WebElement eleGoButton;
	public EditDespatchAdvice ClickGoButton(){
		click(eleGoButton);
		
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//button[@name='reset']")

	public WebElement eleResetButton;
	public EditDespatchAdvice ClickResetButton(){
		click(eleResetButton);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//div[@id='DADetails']//tbody//td[6]/span")

	public WebElement eleEdit;
	public EditDespatchAdvice clickEditbutton(){
		click(eleEdit);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleDANumberGrid;
	public EditDespatchAdvice verifyDANumber(String DataDANumber){
		verifyText(eleDANumberGrid, DataDANumber);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleDespatchModeGrid;
	public EditDespatchAdvice verifyDespatchMode(String DataDespatchMode){
		verifyText(eleDespatchModeGrid, DataDespatchMode);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleCreateOnGrid;
	public EditDespatchAdvice verifyeleCreateOnGrid(String DataCreateOn){
		verifyText(eleCreateOnGrid, DataCreateOn);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleCreateByGrid;
	public EditDespatchAdvice verifyeleCreateByGrid(String DataCreateBy){
		verifyText(eleCreateByGrid, DataCreateBy);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="dummy")

	public WebElement eleActionGrid;
	public EditDespatchAdvice verifyeleActionGrid(String DataAction){
		verifyText(eleActionGrid, DataAction);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='items per page']/span/span")

	public WebElement itemsPerPage;
	public EditDespatchAdvice clickItemsPerPage(String page){
		click(itemsPerPage);
		pause(1);
		click(locateElement("xpath", "//li[text()='"+page+"']"));
		return this;
	}



	@FindBy(how=How.XPATH,using="//div[@id='LinkageDetails']/div[3]/span[1]")
	public WebElement totalpage;
	@FindBy(how=How.XPATH,using="//div[@id='LinkageDetails']/div[3]//li[1]/a")
	public WebElement pageindex;
	public EditDespatchAdvice ClickNextPage(){
		
			click(locateElement("xpath", "//a[@title='Go to the next page']"));
	
		return this;
	}

	public EditDespatchAdvice ClickPreviousPage(){
		click(locateElement("xpath", "//a[@title='Go to the previous page']"));
	
		return this;
	}
	public EditDespatchAdvice ClickLastPage(){
		click(locateElement("xpath", "//a[@title='Go to the previous page']"));
	
		return this;
	}
	public EditDespatchAdvice ClickFirstPage(){
		click(locateElement("xpath", "//a[@title='Go to the first page']"));
	
		return this;
	}
	
	public EditDespatchAdvice UiValidation() {
		
		text1= new ArrayList<String>();
		pause(3);
		int sum =0;
		int page = 0;
		String pagenumber = getText(locateElement("xpath", "//span[@class='k-pager-input k-label']")).replaceAll("\\D", "");
		int number = StringToInteger(pagenumber);
		do {
			List<WebElement> elegridDetails = getEventDriver().findElements(By.xpath("//div[@id='DADetails']/div[2]/table/tbody/tr"));
			for (WebElement details : elegridDetails) {
				String text = getText(details);
				System.out.println("Grid value from UI:" +text);
				text1.add(text);
				}

			String attributeText = getAttributeText(locateElement("xpath", "//div[@id='DADetails']/div[3]/a[2]"), "data-page");
			System.out.println("attributeText:" +attributeText);
			page = StringToInteger(attributeText);
			page=page+sum;
			sum++;
			System.out.println("sum: "+ sum);
			System.out.println("page: "+ page);
			ClickNextPage();
		}
		while(number!=page);

		return this;
	}
	

	public EditDespatchAdvice UiValidationForDB() {
		
		text1= new ArrayList<String>();
		pause(3);
		int sum =0;
		int page = 0;
		String pagenumber = getText(locateElement("xpath", "//span[@class='k-pager-input k-label']")).replaceAll("\\D", "");
		int number = StringToInteger(pagenumber);
		do {
			List<WebElement> elegridDetails = getEventDriver().findElements(By.xpath("//div[@id='DADetails']/div[2]/table/tbody/tr/td[2]"));
			for (WebElement details : elegridDetails) {
				String text = getText(details);
				System.out.println("Grid value from UI:" +text);
				text1.add(text);
				}

			String attributeText = getAttributeText(locateElement("xpath", "//div[@id='DADetails']/div[3]/a[2]"), "data-page");
			System.out.println("attributeText:" +attributeText);
			page = StringToInteger(attributeText);
			page=page+sum;
			sum++;
			System.out.println("sum: "+ sum);
			System.out.println("page: "+ page);
			ClickNextPage();
		}
		while(number!=page);

		return this;
	}
	
	public EditDespatchAdvice DBValidation(){
		String string = "";
		text2= new ArrayList<String>();
		Object[][] dataFromDb = getDataFromDb("select HDA_DA_Number from EIPPDSS.PDSSAL.SAL_H_Despatch_Advice where HDA_Date between '2018-07-16' and '2018-07-24'");
		for (Object[] objects : dataFromDb) {
			for (Object object : objects) {
						
				string = object.toString();
				text2.add(string);
				System.out.println("Text From DB:" +string);
			}


		}
		return this;

	}



	public EditDespatchAdvice compareString() {
		if(text2.equals(text1)) {
			System.out.println("DB VALIDATION SUCCESSFULLY");	
		}else {
			System.out.println("DB VALIDATION FAILED");
		}
		return this;

	}

	public EditDespatchAdvice clickDANumber() {
		text1= new ArrayList<String>();
		pause(3);
		int sum =0;
		int page = 0;
		String pagenumber = getText(locateElement("xpath", "//span[@class='k-pager-input k-label']")).replaceAll("\\D", "");
		int number = StringToInteger(pagenumber);
		do {
			List<WebElement> elegridDetails = getEventDriver().findElements(By.xpath("//div[@id='DAViewDetails']/div[2]/table/tbody/tr/td[2]/span"));
			for (WebElement details : elegridDetails) {
				String text = getText(details);
				System.out.println("Grid value from UI:" +text);
				text1.add(text);
				click(details);
				pause(3);
				WebDriverWait wait = new WebDriverWait(getEventDriver(), 10);
				wait.until(ExpectedConditions.visibilityOf(locateElement("id", "lblDANumber")));
				String daNumber = locateElement("id", "lblDANumber").getText();
				VerifyDANumber(text, daNumber);
				closeDAView();
			}

			String attributeText = getAttributeText(locateElement("xpath", "//div[@id='DAViewDetails']/div[3]/a[2]"), "data-page");
			System.out.println("attributeText:" +attributeText);
			page = StringToInteger(attributeText);
			page=page+sum;
			sum++;
			System.out.println("sum: "+ sum);
			System.out.println("page: "+ page);
			ClickNextPage();
		}
		while(number!=page);
		
		return this;

	}


	public EditDespatchAdvice VerifyDANumber(String text1, String text2) {
		if(text1.equals(text2)) {
			reportStep("Text Matched", "Pass");
		}else {
			reportStep("Text Not Matched", "Fail");
		}
		
		return this;

	}
	@FindBy(how=How.ID,using="myDAViewModalClose")
	public WebElement DAViewClose;
	public EditDespatchAdvice closeDAView() {
		click(DAViewClose);
		
		return this;

	}

	
}

