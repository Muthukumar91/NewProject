package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class CreateBundleAdvice extends AbstractPage  {

	public CreateBundleAdvice(){
		// This is to load all the elements in the page
		PageFactory.initElements(driver, this);

	}
	@FindBy(how=How.XPATH,using="Dummy")
	public WebElement eleOrderNumber;
	public CreateBundleAdvice typeAndChooseOrderNumber(String dataOrderNumber){
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleLotNumber;
	public CreateBundleAdvice selectUsingTextLotNumber(String dataLotNumber){
		selectUsingText(eleLotNumber, dataLotNumber);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleProductCode;
	public CreateBundleAdvice selectUsingTextProductCode(String dataProductCode){
		selectUsingText(eleProductCode, dataProductCode);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement elePanelCode;
	public CreateBundleAdvice selectUsingTextPanelCode(String dataPanelCode){
		selectUsingText(elePanelCode, dataPanelCode);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBundleCheckbox;
	public CreateBundleAdvice checkBundleCheckbox(String bundleCode){
		check(eleBundleCheckbox);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleRequiredBundleQuantityText;
	public CreateBundleAdvice clickRequiredBundleQuantityText(){
		click(eleRequiredBundleQuantityText);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleSubmit;
	public CreateBundleAdvice clickSubmit(){
		click(eleSubmit);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBundleQuantity;
	public CreateBundleAdvice typeBundleQuantity(String dataBundleQuantity){
		type(eleBundleQuantity, dataBundleQuantity);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleSuccessMessage;
	public CreateBundleAdvice verifyTextContainsSuccessMessage(){
		verifyPartialText(eleSuccessMessage, "Success");
		return this;
	}
	
	public WebElement eleErrorMessage;
	public CreateBundleAdvice verifyTextContainsErrorMessage(String error){
		verifyPartialText(eleErrorMessage, error);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//*[contains(text(),'Required Quantity should not exceed the stock Quantity')]")

	public WebElement eleWarningMessage;
	
	public CreateBundleAdvice verifyTextContainsWarningMessage(){
		verifyPartialText(eleWarningMessage, "Warning");
		return this;
	}
	
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleViewBundleSequenceNumbers;
	public CreateBundleAdvice clickViewBundleSequenceNumbers(){
		click(eleViewBundleSequenceNumbers);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleCloseSuccessMessage;
	public CreateBundleAdvice clickCloseSuccessMessage(){
		click(eleCloseSuccessMessage);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleCloseWarningMessage;
	public CreateBundleAdvice clickCloseWarningMessage(){
		click(eleCloseWarningMessage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBundleCodeDetails;
	public CreateBundleAdvice verifyExistsBundleCodeDetails(){
		verifyExists(eleBundleCodeDetails);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBundleAdviceGenerated;
	public CreateBundleAdvice verifyExistsBundleAdviceGenerated(){
		verifyExists(eleBundleAdviceGenerated);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleFromBundleSequenceNumber;
	public CreateBundleAdvice verifyExistsFromBundleSequenceNumber(){
		verifyExists(eleFromBundleSequenceNumber);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleToBundleSequenceNumber;
	public CreateBundleAdvice verifyExistsToBundleSequenceNumber(){
		verifyExists(eleToBundleSequenceNumber);
		return this;
	}
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleCloseBundleSequenceNumberDetails;
	public CreateBundleAdvice clickCloseBundleSequenceNumberDetails(){
		click(eleCloseBundleSequenceNumberDetails);
		return this;
	}


}
