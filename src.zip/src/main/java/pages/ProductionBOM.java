package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;



public class ProductionBOM extends AbstractPage  {
	
	
	public ProductionBOM(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="Create")
	public WebElement eleCreate;
	public ProductionBOM clickCreate(){
		pause(2);
		click(eleCreate);
		pause(2); 
		return this;
	}
	
	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	public ProductionBOM TypeOrderNumber(){
		pause(2); 
		String data=WindowMessage;
		System.out.println(data);
		typeAndChoose(eleOrderNumber, data);
		return this;
	}
	
	public ProductionBOM TypeOrderNumber(String data){
		
		typeAndChoose(eleOrderNumber, data);
		pause(2);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//span[@aria-owns='ProductCode_listbox']")

	public WebElement eleProductCode;
	public ProductionBOM SelectProductCode(){
		click(eleProductCode);
		pause(2);
		click(locateElement("xpath", "//ul[@id='ProductCode_listbox']/li[3]"));
		
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//a[text()='Excel Upload']")

	public WebElement eleExcelUpload;
	public ProductionBOM clickExcelUpload(){
		click(eleExcelUpload);
		pause(2);
		return this;
	}
	
	
	
	@FindBy(how=How.XPATH,using="//input[@type='file']")

	public WebElement eleUpload;
	public ProductionBOM clickUpload(){
	
		//eleUpload.sendKeys("C:\\Users\\muthukumarmm\\Documents\\Copy of BOMTemplate.xlsm");
		eleUpload.sendKeys("C:\\Users\\muthukumarmm\\Documents\\SrujanaBOM.xlsm");
			return this;
	}
	

	
		
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following::a")

	public WebElement eleclose;
	public ProductionBOM ClickClose(){

		try {
			click(eleclose);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@id='kendoWindowRedirect_wnd_title']/following::a")

	public WebElement elecloseSuccess;
	public ProductionBOM ClickCloseSucess(){

		try {
			click(elecloseSuccess);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		
		return this;
	}
	
	@FindBy(how=How.ID,using="authorize")
	public WebElement eleauthorize;
	public ProductionBOM clickAuthorize(){
		pause(2);
		click(eleauthorize);
		pause(2); 
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@id='ProductDetails']//thead//th/input")

	public WebElement elechkASelectAll;
	public ProductionBOM ClickChkASelectAll(){
		pause(2);
		try {
			click(elechkASelectAll);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return this;
	}

	@FindBy(how=How.XPATH,using="//button[text()='APPROVE']")

	public WebElement eleAPPROVE;
	public ProductionBOM ClickAPPROVE(){

		click(eleAPPROVE);
		pause(2);
		
		return this;
	}
	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;
		public LeftMenuPage clickNavigation() {
		pause(2);
		click(eleNavigation); 
		return new LeftMenuPage(); 
	}
	
	}

	

