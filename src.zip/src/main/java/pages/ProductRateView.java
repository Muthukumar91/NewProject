package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ProductRateView extends AbstractPage  {

	public ProductRateView(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}
	
	
	
	@FindBy(how=How.ID,using="Create")
	public WebElement eleCreate;
	public ProductRateCreate clickCreateButton(){
		System.out.println("***********************");
		pause(2);
		click(eleCreate);
		pause(2);
		return new ProductRateCreate();
	}
	
	@FindBy(how=How.ID,using="authorize")
	public WebElement eleAuthorize;
	public ProductRateApproval clickAuthorizeButton(){
		System.out.println("***********************");
		pause(2);
		click(eleAuthorize);
		pause(2);
		return new ProductRateApproval();
	}
	@FindBy(how=How.ID,using="txtOrderNumber")
	public WebElement eleOrderNumber;
	public ProductRateView typeAndChooseOrderNumber(String dataOrderNumber){
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@class='k-widget k-dropdown k-header form-control']/span")

	public WebElement eleProductCode;
	public ProductRateView selectProductCode(String type){
		click(eleProductCode);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@class='k-dropdown-wrap k-state-default']")

	public WebElement eleRateType;
	public ProductRateView selectRateType(String type){
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//h3[text()='Order Details']/following::div/div")

	public WebElement eleOrderNumberTooltext;
	public ProductRateView clickToolTipText(){
		getText(eleOrderNumberTooltext);

		return this;
	}
	
	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleGo;
	public ProductRateView clickGoButton(){
		click(eleGo);
		return this;
	}
	@FindBy(how=How.ID,using="btnReset")

	public WebElement eleReset;
	public ProductRateView clickResetButton(){
		click(eleReset);
		
		return this;
	}
	public ProductRateView ResetVerification() {

		String attribute = locateElement("id", "txtOrderNumber").getAttribute("aria-busy");		
		if(attribute==null) {
			reportStep("Value Cleared", "Pass");
		}else if(attribute.equals("false")) {
			reportStep("Value not Cleared", "Pass");
		}else {
			reportStep("Value not Cleared", "Fail");
		}
		return this;

	}
	@FindBy(how=How.XPATH,using="//div[@class='lti-alert-msg']/label")
	public WebElement eleWindowMsg;
	public ProductRateView clickWindowMsg(){
		try {
			String text = getText(eleWindowMsg);
			if (text.equals(text)) {
				reportStep("Text Matched", "Pass");
			}else {
				reportStep("Text not Matched", "Fail");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;
	}



	@FindBy(how=How.XPATH,using="//span[text()='Close']/..")

	public WebElement eleCloseMessage;
	public ProductRateView clickCloseMessage(){
		click(eleCloseMessage);

		return this;
	}

	
	
	


}
