package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ApprovalDespatchBOMBundle extends AbstractPage {
	public static String dialogMessage,dialogTitle;
	public ApprovalDespatchBOMBundle(){
		PageFactory.initElements(getEventDriver(), this);
	}

	
	public ApprovalDespatchBOMBundle verifyMandatoryFields()
	{
		String[] elements = {"Order Number ","Product Code "};
		System.out.println(verifyMandatory(elements));
		return this;

	}
	
	
	@FindBy(how=How.ID,using="view")
    private WebElement eleView;

	public ViewDespatchBOMBundle clickView(){
	
		click(eleView);
		return new ViewDespatchBOMBundle();
	}
	
	@FindBy(how=How.ID,using="update")
    private WebElement eleEdit;

	public EditDespatchBomBundle clickEdit(){
	
		click(eleEdit);
		return new EditDespatchBomBundle();
	}
	@FindBy(how=How.ID,using="Create")
    private WebElement eleCreate;

	public CreateDespatchBOMBundle clickCreate(){
	
		click(eleCreate);
		return new CreateDespatchBOMBundle();
	}
	
	
	@FindBy(how=How.ID,using="OrderNumber")
    private WebElement eleOrderNumber;

	public ApprovalDespatchBOMBundle typeOrderNumber(String dataOrderNumber){
	
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}

	@FindBy(how=How.XPATH,using="//i[@title='Order Details']")
    private WebElement eleOrderInfoIcon;

	public ApprovalDespatchBOMBundle clickOrderInfoIcon(){
	
		click(eleOrderInfoIcon);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//i[@title='Product Details']")
    private WebElement eleProductInfoIcon;

	public ApprovalDespatchBOMBundle clickProductInfoIcon(){
	
		click(eleProductInfoIcon);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="dummy")
    private WebElement eleOrderDetails;

	public ApprovalDespatchBOMBundle getOrderDetails(){
	
		getText(eleOrderDetails);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="dummy")
    private WebElement eleProductDetails;

	public ApprovalDespatchBOMBundle getProductDetails(){
	
		getText(eleProductDetails);
		return this;
	}
	@FindBy(how=How.XPATH,using="//input[@id='Product']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleProductCodeDd;
	public ApprovalDespatchBOMBundle clickProductCodeDd(){
		click(eleProductCodeDd);
		return this;
	}
	
	
	public ApprovalDespatchBOMBundle selectProductCode(String productCode){
		selectUsingText(locateElement("xpath", "//li[text()='"+productCode+"']"), productCode);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='PanelCode']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement elePanelCodeDd;
	public ApprovalDespatchBOMBundle clickPanelCodeDd(){
		click(elePanelCodeDd);
		return this;
	}
	
	
	public ApprovalDespatchBOMBundle selectPanelCode(String panelCode){
		selectUsingText(locateElement("xpath", "//li[text()='"+panelCode+"']"), panelCode);
		return this;
	}
	
	@FindBy(how=How.ID,using="GoBtn")

	public WebElement eleGo;
	public ApprovalDespatchBOMBundle clickGo(){
		click(eleGo);
		return this;
	}
	
	@FindBy(how=How.ID,using="ResetBtn")

	public WebElement eleReset;
	public ApprovalDespatchBOMBundle clickReset(){
		click(eleReset);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//button[text()='Approve']")

	public WebElement eleApprove;
	public ApprovalDespatchBOMBundle clickApprove(){
		click(eleApprove);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='Reject']")

	public WebElement eleReject;
	public ApprovalDespatchBOMBundle clickReject(){
		click(eleReject);
		return this;

	}
	@FindBy(how=How.ID,using="chkSelectAll")

	public WebElement eleBundlesCheckbox;
	public ApprovalDespatchBOMBundle checkBundlesCheckbox(){
		check(eleBundlesCheckbox);
		return this;
	}
	
	@FindBy(how=How.ID,using="txtRemarks")

	public WebElement txtRemarks;
	public ApprovalDespatchBOMBundle typeRemarks(String remarks){
		type(txtRemarks,remarks);
		if(txtRemarks.getAttribute("value").equals(remarks))
			System.out.println("User is able to enter remarks");;
		return this;
	}
	
	@FindBy(how=How.ID,using="help")
    private WebElement eleHelp;

	public ApprovalDespatchBOMBundle clickHelp(){
	
		click(eleHelp);
		return this;
	}
	
	@FindBy(how=How.ID,using="kendoWindow_wnd_title")
	public WebElement eledialogTitle;
	public ApprovalDespatchBOMBundle getdialogTitle() 
	{
		System.out.println(getText(eledialogTitle));
		dialogTitle=getText(eledialogTitle);
		return this;
	}
	
	@FindBy(how=How.ID,using="lblwindowmsg")
	private WebElement eledialogMsg;
	public ApprovalDespatchBOMBundle getdialogMsg() 
	{
		dialogMessage = getText(eledialogMsg);		
		System.out.println(dialogMessage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	public WebElement closeMessage; 
	public ApprovalDespatchBOMBundle  CloseMessage()
	{
		click(closeMessage);
		return this;
	}
	@FindBy(how=How.XPATH,using="//div[@id='PartDetails']//tbody/tr") 
	private List<WebElement> eleNoOfBundleDetails;
	private int noOfRecordsInGrid;
	public ApprovalDespatchBOMBundle getNoOfBundledetails() {
		noOfRecordsInGrid=eleNoOfBundleDetails.size();
		System.out.println("The no of records in the grid are "+eleNoOfBundleDetails.size());
		return this;
		
	}
	
	public ApprovalDespatchBOMBundle checkSelectedRecords(int noOfrecords)
	{
		int count=0;
		for(int i=1;i<=noOfrecords;i++) {
		WebElement ele=locateElement("xpath", "//*[@id='chkSelectAll']/parent::th/following::tr["+i+"]/td[1]");
		if(!ele.isSelected())
			ele.click();
			count++;
		}
		if(count==noOfrecords)
			System.out.println("The given records are selected");
		return this;
	}
	
	public ApprovalDespatchBOMBundle verifyAllCheckBoxesSelectedInGird()
	{
		int count=0;
		for(int i=1;i<=noOfRecordsInGrid;i++) {
		WebElement ele=locateElement("xpath", "//*[@id='chkSelectAll']/parent::th/following::tr["+i+"]/td[1]");
		if(ele.isSelected())
			count++;
		
		}
		if(count==noOfRecordsInGrid)
			System.out.println("All the check box are selected in the grid");
		return this;
	}
	
	
}
