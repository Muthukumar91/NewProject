package pages;

import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;



public class NARReviewCreate extends AbstractPage  {

	public NARReviewCreate(){

		PageFactory.initElements(getEventDriver(), this);

	}
	@FindBy(how=How.ID,using="NarNumber")

	public WebElement eleNARNumber;
	public NARReviewCreate typeNARNumber(String dataNARNumber){
		pause(3);
		typeAndChoose(eleNARNumber, dataNARNumber);
		return this;
	}
	public NARReviewCreate getNARNumber(){
		System.out.println("The NAR entered is "+getAttributeText(eleNARNumber, "value"));
		return this;
	}
	@FindBy(how=How.ID,using="number")

	public WebElement eleRouteCardNumber;
	public NARReviewCreate verifyValueRouteCardNumber(){
		System.out.println("It is in disabled state "+getAttributeText(eleRouteCardNumber, "disabled"));
		System.out.println(getAttributeText(eleRouteCardNumber,"value"));
		return this;
	}
	@FindBy(how=How.ID,using="partCode")

	public WebElement elePartCode;
	public NARReviewCreate verifyValuePartCode(){
		System.out.println("It is in disabled state "+getAttributeText(elePartCode, "disabled"));
		System.out.println(getAttributeText(elePartCode,"value"));
		return this;
	}
	@FindBy(how=How.XPATH,using="//label[text()='Reviewed By (PROD)']//following::span[1]")

	public WebElement eleReviewedByPROD;
	public NARReviewCreate verifyExactTextReviewedByPROD(){
		System.out.println("It is in disabled state "+getAttributeText(elePartCode, "disabled"));
		System.out.println(getText(eleReviewedByPROD));
		return this;
	}


	@FindBy(how=How.XPATH,using="//div[@id='NarDetails']//tbody/tr") 
	private List<WebElement> eleNoOfNARDetails;
	private int noOfRecordsInGrid;
	public NARReviewCreate getNoOfNARdetails() {
		noOfRecordsInGrid=eleNoOfNARDetails.size();
		System.out.println("The no of records in the grid are "+eleNoOfNARDetails.size());
		return this;

	}
	public int getReworkQuantity(int i){

		System.out.println("The quantity is"+getText(locateWebTableElement("NAR Quantity", i)));

		int canLinkQty = Integer.parseInt(getText(locateWebTableElement("NAR Quantity", i)));
		
	
		return canLinkQty;
	}
	
	
	
	public NARReviewCreate enterReworkedQuantity() {



		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			click(locateWebTableElement("Reworked Qty", i));
			int columnIndexreworkQuantity=getEventDriver().findElements(By.xpath("//*[text()='Reworked Qty']/parent::th/preceding-sibling::*")).size()+1;
			WebElement reworkQuantity = getEventDriver().findElement(By.xpath("//*[text()='Reworked Qty']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity+"]/textarea"));
			

			System.out.println((getReworkQuantity(i)+1));
			reworkQuantity.sendKeys(Keys.BACK_SPACE);
			pause(2);
			typeAndTab(reworkQuantity, ""+(getReworkQuantity(i)));
			
		}

		

		return this;
	}
	
	public NARReviewCreate enterGreaterReworkedQuantity() {



		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			click(locateWebTableElement("Reworked Qty", i));
			int columnIndex=getEventDriver().findElements(By.xpath("//*[text()='Reworked Qty']/parent::th/preceding-sibling::*")).size()+1;
			WebElement reworkQuantity = getEventDriver().findElement(By.xpath("//*[text()='Reworked Qty']/parent::th/following::tr["+i+"]/td["+columnIndex+"]/textarea"));
			System.out.println("The quantity is"+getText(locateWebTableElement("NAR Quantity", i)));

			int canLinkQty = Integer.parseInt(getText(locateWebTableElement("NAR Quantity", i)));

			
			reworkQuantity.sendKeys(Keys.BACK_SPACE);
			pause(2);
			typeAndTab(reworkQuantity, ""+canLinkQty+1);
		}

		

		return this;
	}
	public NARReviewCreate clearReworkedQuantity() {



		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			click(locateWebTableElement("Reworked Qty", i));
			int columnIndex=getEventDriver().findElements(By.xpath("//*[text()='Reworked Qty']/parent::th/preceding-sibling::*")).size()+1;
			WebElement reworkQuantity = getEventDriver().findElement(By.xpath("//*[text()='Reworked Qty']/parent::th/following::tr["+i+"]/td["+columnIndex+"]/textarea"));
			

			reworkQuantity.clear();
		}

		

		return this;
	}
	public NARReviewCreate enterRemarks(String remarks) {



		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			click(locateWebTableElement("Review Remarks", i));
			int columnIndex=getEventDriver().findElements(By.xpath("//*[text()='Review Remarks']/parent::th/preceding-sibling::*")).size()+1;
			WebElement remarksCol = getEventDriver().findElement(By.xpath("//*[text()='Review Remarks']/parent::th/following::tr["+i+"]/td["+columnIndex+"]/input"));
			
			
			typeAndTab(remarksCol,remarks );
		}

		

		return this;
	}
	
	
	public NARReviewCreate enterCorrectiveAction(String correctiveAction) {
		pause(2);


		for (int i = 1; i <= noOfRecordsInGrid; i++) {
	
			//pause(4);
			click(locateWebTableElement(" Corrective Action", i));
			int columnIndex=getEventDriver().findElements(By.xpath("//*[text()=' Corrective Action']/parent::th/preceding-sibling::*")).size()+1;
			WebElement CorrectivAction = getEventDriver().findElement(By.xpath("//*[text()=' Corrective Action']/parent::th/following::tr["+i+"]/td["+columnIndex+"]/input"));
			//click(locateWebTableElement("Corrective Action", i));
		//	WebElement CorrectivAction=locateElement("xpath","//input[@id='correctiveAction']");
			
			typeAndTab(CorrectivAction,correctiveAction );
		}

		

		return this;
	}
	//it didnot come in UI
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleNARNumberIcon;
	public NARReviewCreate verifyTextContainsNARNumberIcon(String dataNARNumberIcon){
		verifyText(eleNARNumberIcon, dataNARNumberIcon);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//button[text()='Submit']")

	public WebElement eleSUBMIT;
	public NARReviewCreate clickSUBMIT(){
		click(eleSUBMIT);
		return this;
	}
	@FindBy(how=How.NAME,using="reset")

	public WebElement eleRESET;
	public NARReviewCreate clickRESET(){
		click(eleRESET);
		return this;
	}

	//not present in UI
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleReviewDate;
	public NARReviewCreate verifyValueReviewDate(String dataReviewDate){
		verifyText(eleReviewDate, dataReviewDate);
		return this;
	}
	public NARReviewCreate verifyMandatoryFields() {

		String[] elements = {"NAR Number"};
		System.out.println(verifyMandatory(elements));
		return this;
		
	}
	@FindBy(how=How.ID,using="kendoWindow_wnd_title")

	public WebElement eleDialogTitle;
	public NARReviewCreate getDialogTitle(){
		System.out.println(getText(eleDialogTitle));
		return this;
	}
	
	@FindBy(how=How.ID,using="lblwindowmsg")

	public WebElement eleDialogMsg;
	public NARReviewCreate getDialogMsg(){
		System.out.println(getText(eleDialogMsg));
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='Close']/..")

	public WebElement eleCloseDialogMsg;
	public NARReviewCreate closeDialogMsg(){
		click(eleCloseDialogMsg);
		return this;
	}

}
