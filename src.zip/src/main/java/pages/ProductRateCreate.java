package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ProductRateCreate extends AbstractPage  {

	public ProductRateCreate(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}
	@FindBy(how=How.ID,using="authorize")
	public WebElement eleAuthorize;
	public ProductRateCreate clickAuthorizeButton(){
		System.out.println("***********************");
		pause(2);
		click(eleAuthorize);
		pause(2);
		return new ProductRateCreate();
	}
	@FindBy(how=How.ID,using="txtOrderNumber")
	public WebElement eleOrderNumber;
	public ProductRateCreate typeAndChooseOrderNumber(String dataOrderNumber){
		dataOrderNumber="TPR180157";
		pause(2);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}

	public ProductRateCreate typeAndChooseOrderNumberPW(String dataOrderNumber){
		dataOrderNumber="TPR180155";
		pause(2);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	public ProductRateCreate typeAndChooseOrderNumberBB(String dataOrderNumber){
		dataOrderNumber="TPR180156";
		pause(2);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@class='k-widget k-dropdown k-header form-control']/span")

	public WebElement eleProductCode;
	public ProductRateCreate selectProductCode(String type){
		type="TPR180114000001 - FOR PANEL FLOW";
		click(eleProductCode);
		pause(2);
		
		try {
			locateElement("xpath", "//ul[@id='ProductCode_listbox']/li[2]").click();
		} catch (Exception e) {
		
			e.printStackTrace();
		}
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@aria-owns='ddlRateType_listbox']")

	public WebElement eleRateType;
	public ProductRateCreate selectRateType(String type){
		type="Raw Material Category";
		pause(2);
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}
	public ProductRateCreate selectRateType1(String type){
		type="Customer Product";
		pause(2);
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}
	public ProductRateCreate selectRateType3(String type){
		type="Design Product";
		pause(2);
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}
	
	public ProductRateCreate selectRateType2(String type){
		type="Billing BreakUp";
		pause(2);
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}

	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleGo;
	public ProductRateCreate clickGoButton(){
	
		click(eleGo);
		return this;
	}
	@FindBy(how=How.ID,using="btnReset")

	public WebElement eleReset;
	public ProductRateCreate clickResetButton(){
		click(eleReset);

		return this;
	}

	public ProductRateCreate ResetVerification() {

		String attribute = locateElement("id", "txtOrderNumber").getAttribute("aria-busy");		
		if(attribute==null) {
			reportStep("Value Cleared", "Pass");
		}else if(attribute.equals("false")) {
			reportStep("Value not Cleared", "Pass");
		}else {
			reportStep("Value not Cleared", "Fail");
		}
		return this;

	}
	@FindBy(how=How.ID,using="btnSubmit")

	public WebElement eleSubmit;
	public ProductRateCreate clickSubmitButton(){
		pause(2);
		click(eleSubmit);
		return this;
	}


	@FindBy(how=How.XPATH,using="//div[@id='grdProductDetails']//tbody/tr") 
	private List<WebElement> eleNoOfProductDetails;
	private int noOfRecordsInGrid;
	public ProductRateCreate getNoOfProductdetails() {
		noOfRecordsInGrid=eleNoOfProductDetails.size();
		System.out.println("The no of records in the grid are "+eleNoOfProductDetails.size());
		return this;

	}
	public int getReworkQuantity(int i){

		System.out.println("The quantity is"+getText(locateWebTableElement("Sale Rate", i)));

		int canLinkQty = Integer.parseInt(getText(locateWebTableElement("Sale Rate", i)));


		return canLinkQty;
	}

	public ProductRateCreate EnterDataInFields(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			locateWebTableElement("UOM", i);
			int columnIndexreworkQuantity6=getEventDriver().findElements(By.xpath("//*[text()='UOM']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity6);
			WebElement reworkQuantity6 = getEventDriver().findElement(By.xpath("//*[text()='UOM']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity6+"]/select"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			selectUsingText(reworkQuantity6, "Kilogram");
			pause(1);


			click(locateWebTableElement("HSN", i));
			int columnIndexreworkQuantity3=getEventDriver().findElements(By.xpath("//*[text()='HSN']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity3);
			WebElement reworkQuantity3 = getEventDriver().findElement(By.xpath("//*[text()='HSN']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity3+"]/span/input"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			type(reworkQuantity3, "54034130");
			reworkQuantity3.sendKeys(Keys.DOWN,Keys.ENTER);
			pause(1);

			

			click(locateWebTableElement("Sale Rate", i));
			int columnIndexreworkQuantity=getEventDriver().findElements(By.xpath("//*[text()='Sale Rate']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity);
			WebElement reworkQuantity = getEventDriver().findElement(By.xpath("//*[text()='Sale Rate']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity+"]/textarea"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			try {
				reworkQuantity.clear();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			reworkQuantity.sendKeys(String.valueOf(100000));
			pause(1);
			
			
			locateWebTableElement("Sale Currency", i);
			int columnIndexreworkQuantity4=getEventDriver().findElements(By.xpath("//*[text()='Sale Currency']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity4);
			WebElement reworkQuantity4 = getEventDriver().findElement(By.xpath("//*[text()='Sale Currency']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity4+"]/select"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			selectUsingText(reworkQuantity4, "INR");
			pause(1);

			int columnIndexreworkQuantity1=getEventDriver().findElements(By.xpath("//*[text()='Prime Cost']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity1);
			click(locateWebTableElement("Prime Cost", i));
			WebElement reworkQuantity1 = getEventDriver().findElement(By.xpath("//*[text()='Prime Cost']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity1+"]/textarea"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			reworkQuantity1.sendKeys(String.valueOf(100000));
			pause(1);

			click(locateWebTableElement("Overhead", i));
			int columnIndexreworkQuantity2=getEventDriver().findElements(By.xpath("//*[text()='Overhead']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity2);
			WebElement reworkQuantity2 = getEventDriver().findElement(By.xpath("//*[text()='Overhead']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity2+"]/textarea"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			reworkQuantity2.sendKeys(String.valueOf(100000));


			locateWebTableElement("Overhead Currency", i);
			int columnIndexreworkQuantity5=getEventDriver().findElements(By.xpath("//*[text()='Overhead Currency']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity5);
			WebElement reworkQuantity5 = getEventDriver().findElement(By.xpath("//*[text()='Overhead Currency']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity5+"]/select"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			selectUsingText(reworkQuantity5, "USD");
			pause(1);


		} 
		return this;
	}

	public ProductRateCreate EnterProductCode(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			
			click(locateWebTableElement("Product Code", i));
			int columnIndexreworkQuantity=getEventDriver().findElements(By.xpath("//*[text()='Product Code']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity);
			WebElement ProductCode = getEventDriver().findElement(By.xpath("//*[text()='Product Code']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity+"]/textarea"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			type(ProductCode, "TPR180132");
			ProductCode.sendKeys(Keys.DOWN,Keys.DOWN,Keys.ENTER);
			pause(1);

			
		} 
		return this;
	}
	public ProductRateCreate EnterSaleRate(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			
			click(locateWebTableElement("Sale Rate", i));
			int columnIndexreworkQuantity=getEventDriver().findElements(By.xpath("//*[text()='Sale Rate']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity);
			WebElement reworkQuantity = getEventDriver().findElement(By.xpath("//*[text()='Sale Rate']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity+"]/textarea"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			reworkQuantity.sendKeys(String.valueOf(100000));
			pause(1);

			
		} 
		return this;
	}
	
	public ProductRateCreate EnterPrimeCost(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			
			int columnIndexreworkQuantity1=getEventDriver().findElements(By.xpath("//*[text()='Prime Cost']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity1);
			click(locateWebTableElement("Prime Cost", i));
			WebElement reworkQuantity1 = getEventDriver().findElement(By.xpath("//*[text()='Prime Cost']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity1+"]/textarea"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			reworkQuantity1.sendKeys(String.valueOf(100000));
			pause(1);

			} 
		return this;
	}
	
	public ProductRateCreate EnterOverHead(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
		

			click(locateWebTableElement("Overhead", i));
			int columnIndexreworkQuantity2=getEventDriver().findElements(By.xpath("//*[text()='Overhead']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity2);
			WebElement reworkQuantity2 = getEventDriver().findElement(By.xpath("//*[text()='Overhead']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity2+"]/textarea"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			reworkQuantity2.sendKeys(String.valueOf(100000));


			
		} 
		return this;
	}
	public ProductRateCreate EnterOverheadCurrency(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			
			locateWebTableElement("Overhead Currency", i);
			int columnIndexreworkQuantity5=getEventDriver().findElements(By.xpath("//*[text()='Overhead Currency']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity5);
			WebElement reworkQuantity5 = getEventDriver().findElement(By.xpath("//*[text()='Overhead Currency']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity5+"]/select"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			selectUsingText(reworkQuantity5, "USD");
			pause(1);


		} 
		return this;
	}
	public ProductRateCreate EnterUOM(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			locateWebTableElement("UOM", i);
			int columnIndexreworkQuantity6=getEventDriver().findElements(By.xpath("//*[text()='UOM']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity6);
			WebElement reworkQuantity6 = getEventDriver().findElement(By.xpath("//*[text()='UOM']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity6+"]/select"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			selectUsingText(reworkQuantity6, "Kilogram");
			pause(1);


			
		} 
		return this;
	}
	
	
	public ProductRateCreate EnterSaleCurrency(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			
			locateWebTableElement("Sale Currency", i);
			int columnIndexreworkQuantity4=getEventDriver().findElements(By.xpath("//*[text()='Sale Currency']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity4);
			WebElement reworkQuantity4 = getEventDriver().findElement(By.xpath("//*[text()='Sale Currency']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity4+"]/select"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			selectUsingText(reworkQuantity4, "INR");
			pause(1);

			
		} 
		return this;
	}
	public ProductRateCreate EnterHSNFields(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {


			click(locateWebTableElement("HSN", i));
			int columnIndexreworkQuantity3=getEventDriver().findElements(By.xpath("//*[text()='HSN']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity3);
			WebElement reworkQuantity3 = getEventDriver().findElement(By.xpath("//*[text()='HSN']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity3+"]/span/input"));
			//System.out.println((getReworkQuantity(i)+1));
			pause(2);
			typeAndChoose(reworkQuantity3, "54034130");
			//reworkQuantity3.sendKeys(String.valueOf(100000));
			pause(1);


		} 
		return this;
	}
	public ProductRateCreate clickRefresh(){
		getEventDriver().navigate().refresh();

		return this;
	}

	@FindBy(how=How.XPATH,using="//i[@data-original-title='Order Details']")

	public WebElement eleOrderNumberToolTip;
	public ProductRateCreate clickOrderNumberToolTip(){
		click(eleOrderNumberToolTip);

		return this;
	}

	@FindBy(how=How.XPATH,using="//h3[text()='Order Details']/following::div/div")

	public WebElement eleOrderNumberTooltext;
	public ProductRateCreate clickToolTipText(){
		getText(eleOrderNumberTooltext);

		return this;
	}



	@FindBy(how=How.XPATH,using="//div[@class='lti-alert-msg']/label")
	public WebElement eleWindowMsg;
	public ProductRateCreate clickWindowMsg(){
		try {
			String text = getText(eleWindowMsg);
			if (text.equals(text)) {
				reportStep("Text Matched", "Pass");
			}else {
				reportStep("Text not Matched", "Fail");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;
	}



	@FindBy(how=How.XPATH,using="//span[text()='Close']/..")

	public WebElement eleCloseMessage;
	public ProductRateCreate clickCloseMessage(){
		click(eleCloseMessage);

		return this;
	}

	@FindBy(how=How.ID,using="btnno")

	public WebElement eleNo;
	public ProductRateCreate clickNO(){
		click(eleNo);

		return this;
	}

	@FindBy(how=How.ID,using="btnyes")

	public WebElement eleYes;
	public ProductRateCreate clickYes(){
		click(eleYes);

		return this;
	}
	@FindBy(how=How.ID,using="lblwindowmsg")

	public WebElement eleMessage;
	public ProductRateCreate clickConfirmMessage(){
		String text = getText(eleMessage);
		if (text.equals(text)) {
			reportStep("Text Matched", "Pass");
		}else {
			reportStep("Text not Matched", "Fail");
		}

		return this;
	}
	@FindBy(how=How.ID,using="cmdAddGridRow")

	public WebElement eleAddRow;
	public ProductRateCreate clickAddRow(){
		
		click(eleAddRow);

		return this;
	}
	
	//*[@id='cmdAddGridRow']/parent::th/following::tr[1]/td[12]/div/i
	
	public ProductRateCreate RemoveRow(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {


			//click(locateWebTableElement("HSN", i));
			int columnIndexreworkQuantity3=getEventDriver().findElements(By.xpath("//*[@id='cmdAddGridRow']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity3);
			WebElement Row = getEventDriver().findElement(By.xpath("//*[@id='cmdAddGridRow']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity3+"]/div/i"));
			//System.out.println((getReworkQuantity(i)+1));
			click(Row);


		} 
		return this;
	}
	
}
