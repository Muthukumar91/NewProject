package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class DeliveryChallanView extends AbstractPage  {
	public DeliveryChallanView(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}


	@FindBy(how=How.ID,using="Create")

	public WebElement eleCreate;
	public DeliveryChallan clickCreate(	){
		click(eleCreate);
		pause(2);
		return new DeliveryChallan();
	}
	@FindBy(how=How.XPATH,using="//input[@id='fromDate']/following::span")

	public WebElement eleFromDateicon;
	public DeliveryChallanView clickFromDateIcon(String Year, String month, String day, String date){
		pause(2);
		click(eleFromDateicon);
		pause(2);
		click(locateElement("xpath", "//div[@id='fromDate_dateview']//a[2]"));
		pause(2);
		click(locateElement("xpath", "//div[@id='fromDate_dateview']//a[2]"));
		pause(2);
		click(locateElement("linkText", Year));

		pause(2);
		click(locateElement("linkText", month));

		click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));

		return this;
	}
	
	@FindBy(how=How.XPATH,using="//input[@id='toDate']/following::span")

	public WebElement eletoDateicon;
	public DeliveryChallanView clickToDateIcon(String Year, String month, String day, String date){
		pause(2);
		click(eletoDateicon);
		pause(2);
		click(locateElement("xpath", "//div[@id='toDate_dateview']//a[2]"));
		pause(2);
		click(locateElement("xpath", "//div[@id='toDate_dateview']//a[2]"));
		pause(2);
		click(locateElement("linkText", Year));

		pause(2);
		click(locateElement("linkText", month));
		
		click(locateElement("xpath", "//a[@data-value='"+Year+"/"+day+"/"+date+"']"));
		return this;
	}
	@FindBy(how=How.ID,using="txtDCNumber")

	public WebElement eleDCNumber;
	public DeliveryChallanView typeAndChooseDCNumber(String DCNumber){
		typeAndChoose(eleDCNumber, DCNumber);
		return this;
	}
	@FindBy(how=How.ID,using="txtOrderNumber")

	public WebElement eleOrderNumber;
	public DeliveryChallanView typeAndChooseOrderNumber(String OrderNumber){
		typeAndChoose(eleOrderNumber, OrderNumber);
		return this;
	}
	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleClickGo;
	public DeliveryChallanView clickGo(){
		click(eleClickGo);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()=' Reset']")

	public WebElement eleClickReset;
	public DeliveryChallanView clickReset(){
		click(eleClickReset);
		return this;
	}


}
