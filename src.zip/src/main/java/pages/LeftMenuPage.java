package pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;

public class LeftMenuPage extends AbstractPage{
	
	public LeftMenuPage() {
		PageFactory.initElements(getEventDriver(), this);		
	}

	
	@FindBy(how = How.XPATH, using = "//a[@class='bottom showroles']/i")
	private WebElement eleManIcon;
	
	@FindBy(how = How.ID, using = "pdssFactory")
	private WebElement eleFactoryOptions;

	@FindBy(how = How.LINK_TEXT, using = "Document")
	private WebElement eleDocument;

	@FindBy(how = How.LINK_TEXT, using = "Order Mgmt.")
	private WebElement eleOrderMgmt;

	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;
	
	@And ("Click on Despatch Menu Item")
	public LeftMenuPage clickNavigation() {
		pause(2);
		click(eleNavigation); 
		return this; 
	}
	
	
	public LeftMenuPage clickManIcon() {
		click(eleManIcon);
		return this; 
	}
	
	public LeftMenuPage clickFactoryOptions() {
		click(eleFactoryOptions);
		return this; 
	}
	
	public LeftMenuPage selectFactory(String factoryName) {
		WebElement eleFactoryName = locateElement("xpath", "//label[text()='"+factoryName+"']/input");
		String checkedAttribute = eleFactoryName.getAttribute("checked");
		if(checkedAttribute==null)
			click(eleFactoryName);
		else
		{
			System.out.println("The factory is already selected");
		}
		
		return this; 
	}
	
	@And ("Click on Documents Sub Menu")
	public LeftMenuPage clickDocument() {
		click(eleDocument);
		return this;
	}

	public LeftMenuPage clickOrderMgmt() {
		click(eleOrderMgmt);
		return this;
	}

	public ManufacturingOrderCreate clickManufacturingOrders() {
		click(eleManufacturingOrders);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {			
		}
		return new ManufacturingOrderCreate();
	}


	@FindBy(how=How.LINK_TEXT,using="Order and Sales")

	public WebElement eleSalesandDistribution;
	public LeftMenuPage clickSalesandDistribution(){
		click(eleSalesandDistribution);
		return this;
	}
	
	@FindBy(how=How.LINK_TEXT,using="Delivery Challan")

	public WebElement eleDeliveryChallan;
	public DeliveryChallanView clickDeliveryChallan(){
		click(eleDeliveryChallan);
		return new DeliveryChallanView();
	}
	
	@FindBy(how=How.LINK_TEXT,using="Despatch Advice")

	public WebElement eleDespatchAdvice;
	public ViewDespatchAdvice clickDespatchAdvice(){
		click(eleDespatchAdvice);
		return new ViewDespatchAdvice();
	}
	 
	@FindBy(how=How.LINK_TEXT,using="Despatch BOM - Panel")

	public WebElement eleDespatchBOMPanel;
	public PanelEssentialsView clickDespatchBOMPanel(){
		click(eleDespatchBOMPanel);
		return new PanelEssentialsView();
	}
	
	@FindBy(how=How.XPATH,using="//ul[@id='Despatch']/preceding-sibling::a")
	
	public WebElement eleDespatch;
	@And ("Click on Despatch Menu Item")
	public LeftMenuPage clickDespatch(){
		click(eleDespatch);
		return this;
	}
	
	//@FindBy(how=How.XPATH,using="//ul[@id='Despatch']//a")
	@FindBy(how=How.LINK_TEXT,using="Despatch Linkage")

	public WebElement eleDespatchLinkage;
	@And ("Click on Despatch Linkage")
	public ViewDespatchLinkage clickDespatchLinkage(){;
		click(eleDespatchLinkage);
		return new ViewDespatchLinkage();
	}
	
	@FindBy(how=How.LINK_TEXT,using="Bundle Advise")

	public WebElement eleBundleAdvise;
	public ViewBundleAdvice clickBundleAdvise(){
		click(eleBundleAdvise);
		return new ViewBundleAdvice();
	}
	

	/*@FindBy(how=How.LINK_TEXT,using="Dummy")

	private WebElement eleDespatchBOMBBU;
	public BBUEssentialsView clickDespatchBBU(){   //Despatch BOM-Panel  will be changed into  Despatch BOM-BBU  as per manufacturing unit configuration
		click(eleBundleAdvise);
		return new BBUEssentialsView();
	}*/
	
	@FindBy(how=How.XPATH,using="//a[text()=' Despatch BOM - Bundle  ']")

	private WebElement eleDespatchBOMBBU;
	public ViewDespatchBOMBundle clickViewDespatchBOMBundle(){
		click(eleDespatchBOMBBU);
		return new ViewDespatchBOMBundle();
	}
	
	 
	
	 @FindBy(how=How.XPATH,using="//a[text()=' Product Rate  ']")

		public WebElement eleProdutRate;
		public ProductRateView clickProductRate(){
			click(eleProdutRate);
			return new ProductRateView();
		}

		@FindBy(how = How.LINK_TEXT, using = "Manufacturing Orders")
		private WebElement eleManufacturingOrders;
		public ManufacturingOrderCreate clickManuOrder(){
			click(eleManufacturingOrders);
			return new ManufacturingOrderCreate();
		}

		@FindBy(how = How.LINK_TEXT, using = "Design")
		private WebElement eleDesign;
		public LeftMenuPage clickDesign(){
			click(eleDesign);
			return this;
		}
		
		@FindBy(how = How.LINK_TEXT, using = "Products")
		private WebElement eleProducts;
		public ProductsCreate clickProducts(){
			click(eleProducts);
			return new ProductsCreate();
		}
		@FindBy(how = How.LINK_TEXT, using = "Production BOM")
		private WebElement eleProductionBOM;
		public ProductionBOM clickProductionBOM(){
			click(eleProductionBOM);
			return new ProductionBOM();
		}
		
		@FindBy(how = How.LINK_TEXT, using = "BOM Association")
		private WebElement eleBOMAssociation;
		public BOMAssociation clickBOMAssociation(){
			click(eleBOMAssociation);
			return new BOMAssociation();
		}
		
		@FindBy(how = How.LINK_TEXT, using = "Planning")
		private WebElement elePlanning;
		public LeftMenuPage clickPlanning(){
			click(elePlanning);
			return this;
		}
		
		@FindBy(how = How.LINK_TEXT, using = "Production Linkage")
		private WebElement eleProductionLinkage;
		public ProductionLinkage clickProductionLinkage(){
			click(eleProductionLinkage);
			return new ProductionLinkage();
		}
		
		@FindBy(how = How.LINK_TEXT, using = "Process Flow")
		private WebElement eleProcessFlow;
		public ProcessFlow clickProcessFlow(){
			click(eleProcessFlow);
			return new ProcessFlow();
		}
		
		
		@FindBy(how = How.LINK_TEXT, using = "RouteCard Generation")
		private WebElement eleRouteCardGeneration;
		public RouteCardGeneration clickRouteCardGeneration(){
			click(eleRouteCardGeneration);
			return new RouteCardGeneration();
		}
		
		@FindBy(how = How.LINK_TEXT, using = "Reports")
		private WebElement eleReports;
		public LeftMenuPage clickReports(){
			click(eleReports);
			return this;
		}
		
		@FindBy(how = How.LINK_TEXT, using = "Despatch Advice Report")
		private WebElement eleDespatchAdviceReport;
		public DespatchAdviceReport clickDespatchAdviceReport(){
			click(eleDespatchAdviceReport);
			pause(2);
			return new DespatchAdviceReport() ;
		}
		

		@FindBy(how = How.LINK_TEXT, using = "Delivery Challan Report")
		private WebElement eleDeliveryChallanReport;
		public DespatchAdviceReport clickDeliveryChallanReport(){
			click(eleDeliveryChallanReport);
			pause(2);
			return new DespatchAdviceReport() ;
		}
		
		
		
			
		
		
		
}
