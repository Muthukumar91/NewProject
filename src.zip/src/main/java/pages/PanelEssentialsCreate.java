package pages;

import java.awt.Robot;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;

import cucumber.api.java.en.When;


public class PanelEssentialsCreate extends AbstractPage  {

	String text;
	public List<String> text1, text2, text3;
	public PanelEssentialsCreate(){
		PageFactory.initElements(getEventDriver(), this);
	}
	@FindBy(how=How.XPATH,using="//span[@onclick='UserSelectClick()']")

	public WebElement eleMovetoRight;
	public PanelEssentialsCreate clickMovetoRight(){
		click(eleMovetoRight);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Right']")

	public WebElement eleMoveAllRight;
	public PanelEssentialsCreate clickMoveAllRight(){
		click(eleMoveAllRight);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//i[@class='glyphicon glyphicon-menu-left'])[1]")

	public WebElement eleMovetoLeft;
	public PanelEssentialsCreate clickMovetoLeft(){
		click(eleMovetoLeft);
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Left']")

	public WebElement eleMoveAllLeft;
	public PanelEssentialsCreate clickMoveAllLeft(){
		pause(4);
		click(eleMoveAllLeft);
		return this;
	}

	@FindBy(how=How.ID,using="OrderNumber")

	public WebElement eleOrderNumber;
	@When ("The OrderNumber entered")
	public PanelEssentialsCreate typeAndChooseOrderNumberDB(String sql){
		/*click(eleOrderNumber);*/
		String orderNumber = null;
		Object[][] db = getDataFromDb(sql);
		for (Object[] objects : db) {
			for (Object object : objects) {
				orderNumber = object.toString();
			}
		}
		pause(3);
		orderNumber="TPR180115";
		typeAndChoose(eleOrderNumber, orderNumber);
		return this;
	}
	public PanelEssentialsCreate typeAndChooseOrderNumber(String orderNumber){
		/*click(eleOrderNumber);*/
		orderNumber="TPR180115";
		pause(3);
		typeAndChoose(eleOrderNumber, orderNumber);
		eleOrderNumber.sendKeys(Keys.TAB);
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@aria-activedescendant='ProductCode_option_selected']")

	public WebElement eleProductCode;
	@FindBy(how=How.XPATH,using="//li[@id='ProductCode_option_selected']")

	public WebElement eleProductCodeOption2;

	public PanelEssentialsCreate selectUsingTextProductCode(String options){
		options="1";
		click(eleProductCode);
		pause(2);
		click(locateElement("xpath", "(//li[@id='ProductCode_option_selected']/following::li[@class='k-item'])["+options+"]"));
		return this;
	}
	@FindBy(how=How.ID,using="PannelCode")

	public WebElement elePanelCode;
	public PanelEssentialsCreate typePanelCode(String dataPanelCode){
		//selectUsingText(elePanelCode, dataPanelCode);
		long number = (long) Math.floor(Math.random() * 900000000L) + 10000000L; 
		System.out.println(dataPanelCode+number);
		type(elePanelCode,dataPanelCode+number);

		return this;
	}
	@FindBy(how=How.ID,using="txtRemarks")

	public WebElement eleRemarks;
	public PanelEssentialsCreate typeRemarks(String dataRemarks){
		type(eleRemarks, dataRemarks);
		return this;
	}
	@FindBy(how=How.ID,using="PannelDescription")

	public WebElement elePanelDescription;
	public PanelEssentialsCreate typePanelDescription(String dataPanelDescription){
		type(elePanelDescription, dataPanelDescription);
		return this;
	}

	@FindBy(how=How.XPATH,using="(//tbody[@role='rowgroup'])[1]/tr")

	public List<WebElement> elePartCodeText;
	public PanelEssentialsCreate PartCodeDbText(){
		text1= new ArrayList<String>();
		for (WebElement ele : elePartCodeText) {

			text = ele.getText();
			text1.add(text);

			System.out.println("PartCodeText for UI:" + text);

		}
		return this;
	}

	public PanelEssentialsCreate dbvalidation(String sql) {
		String string = "";
		text2= new ArrayList<String>();
		Object[][] dataFromDb = getDataFromDb(sql);
		for (Object[] objects : dataFromDb) {
			for (int i = 0; i < objects.length; i++) {
				string = objects[i].toString();
				text2.add(string);
				System.out.println("Text From DB:" +string);
			}


		}
		return this;

	}

	public PanelEssentialsCreate compareString() {
		if(text1.containsAll(text2)) {
			System.out.println("DB VALIDATION SUCCESSFULLY");	
			reportStep("DB VALIDATION SUCCESSFULLY", "Pass");
		}else {
			System.out.println("DB VALIDATION FAILED");
		}
		return this;

	}

	@FindBy(how=How.ID,using="SubmitAssociation")

	public WebElement eleSubmit;
	public PanelEssentialsCreate clickSubmit(){
		pause(2);
		click(eleSubmit);
		return this;
	}
	@FindBy(how=How.ID,using="Search")

	public WebElement eleSearch;
	public PanelEssentialsCreate typeSearch(String dataSearch){
		type(eleSearch, dataSearch);
		return this;
	}
	@FindBy(how=How.XPATH,using="//input[@value='Part']")

	public WebElement elePart;
	public PanelEssentialsCreate clickPart(){
		click(elePart);
		return this;
	}
	@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']/div[2]/table/tbody/tr[1]/td[1]")

	//tbody[@role='rowgroup']/tr) 
	//a[href='/EIPPDSS/Despatch/DBOMPanel/DBOMPCreate/DBOMPCreateUI?PanelPartDetails-sort=ProductID-asc']
	public WebElement eleBOMPartDetailsFirst;

	public PanelEssentialsCreate clickBOMPartDetailsFirst(){
		pause(2);
		
		/*String pageSource = getEventDriver().getPageSource();
		System.out.println(pageSource);
		

		for (int i = 0; i <20; i++) {
			JavascriptExecutor js = (JavascriptExecutor) getEventDriver();
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", eleBOMPartDetailsFirst, "color: yellow; border: 2px solid yellow;");
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", eleBOMPartDetailsFirst, "");
		}

		Point location = eleBOMPartDetailsFirst.getLocation();
		new Actions(getEventDriver()).moveByOffset(location.getX(), location.getY()+20).clickAndHold().perform();
		pause(1);
		
		
		for (int i = 0; i <20; i++) {
			JavascriptExecutor js = (JavascriptExecutor) getEventDriver();
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", eleBOMPartDetailsFirst, "color: yellow; border: 2px solid yellow;");
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);", eleBOMPartDetailsFirst, "");
		}
*/
		//jsClick(eleBOMPartDetailsFirst);
		click(eleBOMPartDetailsFirst);

		return this;
	}
	/*	
	@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']//tbody/tr") //Need to implement
	public List<WebElement> eleBOMPartDetails;
	 */

	@FindBy(how=How.XPATH,using="//tbody[@role='rowgroup']//td[4]")

	public List<WebElement> eleBOMPartDetails;

	public PanelEssentialsCreate MultipleSelectPartDetails() {
		int size = eleBOMPartDetails.size()-1;
		System.out.println(eleBOMPartDetails.size());
		WebDriverWait wait = new WebDriverWait(getDriver(), 30);
		//wait.until(ExpectedConditions.elementToBeClickable(eleBOMPartDetails.get(2)));

		boolean displayed = eleBOMPartDetails.get(2).isDisplayed();
		System.out.println(displayed);
		WebElement element = eleBOMPartDetails.get(1);

		//locateElement("xpath", "//div[@class='col-md-1 col-lg-1 col-xs-12']/..")));
		try {
			//	wait.until(ExpectedConditions.visibilityOf(eleBOMPartDetails.get(2)));
			//eleBOMPartDetails.get(2).sendKeys("");
			//eleBOMPartDetails.get(2).click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {	
			//getEventDriver().executeScript("scroll(0, 250)","");
			getEventDriver().executeScript("element.focus();");

			getEventDriver().executeScript("arguments[0].click();",element);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return this;
	}

	@FindBy(how=How.ID,using="Reset")

	private WebElement eleReset;
	public  PanelEssentialsCreate clickReset(){
		click(eleReset);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='OrderNumber']/../following::i")

	public WebElement eleOrderNuminfo;
	public PanelEssentialsCreate clickOrderNumberInfo(){
		pause(2);
		click(eleOrderNuminfo);
		return this;
	}

	public PanelEssentialsCreate clickOrderNumberInfoAfter(String order){
		pause(2);
		click(eleOrderNuminfo);
		String number = getText(locateElement("xpath", "//td[text()='Order Number']/following::td"));
		if (number.equals(order)) {
			reportStep("Text Matched", "Pass");

		}else {
			reportStep("Text not Matched", "Fail");
		}
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ProductCode']/../following::i")

	public WebElement eleProductCodeinfo;
	public PanelEssentialsCreate clickProductCodeInfo(){
		pause(2);
		click(eleProductCodeinfo);

		return this;
	}

	public PanelEssentialsCreate clickProductCodeInfoAfter(){
		String options = getText(locateElement("xpath", "//span[@aria-activedescendant='ProductCode_option_selected']/span/span"));

		pause(2);
		click(eleProductCodeinfo);

		String number = getText(locateElement("xpath", "//td[text()='Short Description']/following::td"));
		if (options.contains(number)) {
			reportStep("Text Matched", "Pass");

		}else {
			reportStep("Text not Matched", "Fail");
		}
		return this;
	}


	@FindBy(how=How.XPATH,using="//*[text()='Success']")

	public WebElement eleSuccessDespatchLinkage;
	public PanelEssentialsCreate verifySuccessMsg(String data){
		String orderNumber = getText(eleSuccessDespatchLinkage);
		System.out.println(orderNumber);
		verifyPartialText(eleSuccessDespatchLinkage, data);
		//System.out.println(eleSuccessDespatchLinkage.getText());
		return this;
	}


	@FindBy(how=How.ID,using="btnyes")    

	public WebElement eleYesSuccess;
	@When ("Click on Yes")
	public PanelEssentialsCreate clickYesSuccess(){
		click(eleYesSuccess);
		return this;
	}

	public PanelEssentialsCreate clickReferesh(){
		getEventDriver().navigate().refresh();
		pause(2);
		return this;
	}

	public PanelEssentialsCreate ResetVerification() {

		String attribute = locateElement("id", "OrderNumber").getAttribute("aria-busy");		
		if(attribute==null) {
			reportStep("Value Cleared", "Pass");
		}else if(attribute.equals("false")) {
			reportStep("Value not Cleared", "Pass");
		}else {
			reportStep("Value not Cleared", "Fail");
		}
		return this;

	}


	@FindBy(how=How.ID,using="btnno")    

	public WebElement eleNoSuccess;
	@When ("Click on No")
	public PanelEssentialsCreate clickNoSuccess(){

		click(eleNoSuccess);
		return this;
	}

	@FindBy(how=How.XPATH,using="//div[@class='lti-alert-msg']")

	public WebElement eleErrorMessage;
	public PanelEssentialsCreate verifyTextContainWarningMsg(String warning) {
		
		String text = getText(eleErrorMessage);
		if(text.equals(text))
			System.out.println("text matched");
		else
			System.out.println("text not matched");
		return this;
	}

	public PanelEssentialsCreate getTextWithSuccesMsg() {

		System.out.println(getText(eleErrorMessage));
		return this;
	}


	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	private WebElement closeMessage; 
	public PanelEssentialsCreate  CloseWarningMsg()
	{
		click(closeMessage);
		return this;
	}



	public PanelEssentialsCreate OrderNumberIsNull(String value)
	{


		String OrdeNumberAttribute = getAttributeText(eleOrderNumber,value);
		if(OrdeNumberAttribute.isEmpty())
		{
			reportStep("The element "+eleOrderNumber+" is contains value", "PASS");
		}else {
			reportStep("The element "+eleOrderNumber+" is Empty", "WARNING");
		}

		return this;

	}

	public PanelEssentialsCreate ProductCodeIsNull(String value,String ProductCode)
	{


		String ProductCodeAttribute = getAttributeText(eleProductCode, value);
		if(ProductCodeAttribute.contains(ProductCode))
		{
			reportStep("The element "+eleProductCode+" is contains value", "PASS");
		}else {
			reportStep("The element "+eleProductCode+" is Empty", "WARNING");
		}

		return this;

	}

	public PanelEssentialsCreate PanelCodeIsNull(String value,String PanelCode)
	{


		String ProductCodeAttribute = getAttributeText(elePanelCode, value);
		if(ProductCodeAttribute.contains(PanelCode))
		{
			reportStep("The element "+elePanelCode+" is contains value", "PASS");
		}else {
			reportStep("The element "+elePanelCode+" is Empty", "WARNING");
		}

		return this;

	}

	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleBBUWeightinCreate;
	public PanelEssentialsCreate verifyExactTextPanelWeightinCreate(String dataWeightinCreate){
		verifyText(eleBBUWeightinCreate, dataWeightinCreate);
		return this;
	}


	@FindBy(how=How.XPATH,using="//span[@class='k-pager-input k-label']")
	public WebElement eleNoOfPages;
	public int getNoOfPages() 
	{
		String noOfPagesText = getText(eleNoOfPages);
		int noOfPages=Integer.parseInt(noOfPagesText.replaceAll("Pageof: ", ""));
		return noOfPages;
	}
	@FindBy(how=How.XPATH,using="//div[@id='grdBAView']//tbody/tr")
	public List<WebElement> eleNoOfAdvicedetails;
	public int getNoOfAdvicedetails() 
	{
		int noOfAdviceDetailsInCurrentpage = eleNoOfAdvicedetails.size();
		System.out.println(noOfAdviceDetailsInCurrentpage);
		return noOfAdviceDetailsInCurrentpage;
	}

	@FindBy(how=How.XPATH,using="(//span[@class='k-input'])[3]")
	public WebElement eleNoOfPagesDd;
	public int getNoOfPagesInDd() 
	{
		String noOfPagesText = getText(eleNoOfPagesDd);
		int noOfItemsSelected=Integer.parseInt(noOfPagesText.replaceAll("Pageof: ", ""));
		return noOfItemsSelected;
	}

	public PanelEssentialsCreate verifyAllRecordsDisplayed(int noOfRecordsFromDB)//as of now take hardcode value
	{
		int noOfAdviceDetails=getNoOfAdvicedetails(),totalNoOfPages=1;
		if(getNoOfPages()==1&&noOfRecordsFromDB<=getNoOfPagesInDd()&&noOfRecordsFromDB!=0)
		{
			for (int i = 1; i <= noOfAdviceDetails; i++) {
				WebElement ele=locateWebTableElement("Bundle Quantity Ready for DA", i);
				System.out.println(ele.getText());
			}
		}
		else
		{
			System.out.println("No of records are less than items per page selected");
			while(totalNoOfPages<=totalNoOfpages) {

				for (int i = 1; i <= noOfAdviceDetails; i++) {
					WebElement ele=locateWebTableElement("Bundle Quantity Ready for DA", i);
					System.out.println(ele.getText());
				}

				clickSingleRightArrow();
				totalNoOfPages++;
			}
		}
		return this;
	}

	@FindBy(how=How.XPATH,using="//ul[@class='k-pager-numbers k-reset']//a[@class='k-link']")
	private List<WebElement> eleTotalNoOfPages;
	private int totalNoOfpages;
	public PanelEssentialsCreate getTotalNoOfPages()
	{
		clickDoubleRightArrow();
		int noOfElements=eleTotalNoOfPages.size();
		try {
			totalNoOfpages=Integer.parseInt(getText(locateElement("xpath", "(//ul[@class='k-pager-numbers k-reset']//a[@class='k-link'])["+noOfElements+"]")))+1;
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		clickDoubleLeftArrow();
		return this;
	}


	@FindBy(how=How.XPATH,using="//span[text()='arrow-e']")
	private WebElement eleSingleRightArrow;
	public PanelEssentialsCreate clickSingleRightArrow()
	{
		click(eleSingleRightArrow);
		return this;

	}


	@FindBy(how=How.XPATH,using="//span[text()='arrow-w']/..")
	private WebElement eleSingleLeftArrow;
	public PanelEssentialsCreate clickSingleLeftArrow()
	{
		click(eleSingleLeftArrow);
		return this;

	}

	@FindBy(how=How.XPATH,using="//span[text()='seek-e']/..")
	private WebElement eleDoubleRightArrow;
	public PanelEssentialsCreate clickDoubleRightArrow()
	{
		click(eleDoubleRightArrow);
		return this;

	}

	@FindBy(how=How.XPATH,using="//span[text()='seek-w']/..")
	private WebElement eleDoubleLeftArrow;
	public PanelEssentialsCreate clickDoubleLeftArrow()
	{
		click(eleDoubleLeftArrow);
		return this;

	}



}
