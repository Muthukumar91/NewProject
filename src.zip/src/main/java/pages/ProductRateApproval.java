package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ProductRateApproval extends AbstractPage  {

	public ProductRateApproval(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}
	
	
	
	@FindBy(how=How.ID,using="txtOrderNumber")
	public WebElement eleOrderNumber;
	public ProductRateApproval typeAndChooseOrderNumber(String dataOrderNumber){
		dataOrderNumber="TPR180157";
		pause(2);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}

	public ProductRateApproval typeAndChooseOrderNumberCP(String dataOrderNumber){
		dataOrderNumber="TPR180155";
		pause(2);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	
	public ProductRateApproval typeAndChooseOrderNumberDP(String dataOrderNumber){
		dataOrderNumber="TPR180155";
		pause(2);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	
	
	public ProductRateApproval typeAndChooseOrderNumberBB(String dataOrderNumber){
		dataOrderNumber="TPR180156";
		pause(2);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@class='k-widget k-dropdown k-header form-control']/span")

	public WebElement eleProductCode;
	public ProductRateApproval selectProductCode(String type){
		type="TPR180114000001 - FOR PANEL FLOW";
		click(eleProductCode);
		pause(2);
		
		try {
			locateElement("xpath", "//ul[@id='ProductCode_listbox']/li[2]").click();
		} catch (Exception e) {
		
			e.printStackTrace();
		}
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@aria-owns='ddlRateType_listbox']")

	public WebElement eleRateType;
	public ProductRateApproval selectRateType(String type){
		type="Raw Material Category";
		pause(2);
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}
	public ProductRateApproval selectRateType1(String type){
		type="Customer Product";
		pause(2);
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}
	public ProductRateApproval selectRateType3(String type){
		type="Design Product";
		pause(2);
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}
	
	public ProductRateApproval selectRateType2(String type){
		type="Billing BreakUp";
		pause(2);
		click(eleRateType);
		pause(2);
		locateElement("xpath", "//li[text()='"+type+"']").click();
		return this;
	}

	@FindBy(how=How.ID,using="btnGo")

	public WebElement eleGo;
	public ProductRateApproval clickGoButton(){
	
		click(eleGo);
		return this;
	}
	@FindBy(how=How.ID,using="btnReset")

	public WebElement eleReset;
	public ProductRateApproval clickResetButton(){
		click(eleReset);

		return this;
	}

	public ProductRateApproval ResetVerification() {

		String attribute = locateElement("id", "txtOrderNumber").getAttribute("aria-busy");		
		if(attribute==null) {
			reportStep("Value Cleared", "Pass");
		}else if(attribute.equals("false")) {
			reportStep("Value not Cleared", "Pass");
		}else {
			reportStep("Value not Cleared", "Fail");
		}
		return this;

	}
	@FindBy(how=How.ID,using="btnSubmit")

	public WebElement eleSubmit;
	public ProductRateApproval clickSubmitButton(){
		pause(2);
		click(eleSubmit);
		return this;
	}
	
	@FindBy(how=How.ID,using="remarks")

	public WebElement eleRemarks;
	public ProductRateApproval clickRemarksButton(){
		pause(2);
		click(eleRemarks);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='Approve']")

	public WebElement eleApprove;
	public ProductRateApproval clickApproveButton(){
		pause(2);
		click(eleApprove);
		return this;
	}
	@FindBy(how=How.XPATH,using="//button[text()='Reject']")

	public WebElement eleReject;
	public ProductRateApproval clickRejectButton(){
		pause(2);
		click(eleReject);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//i[@data-original-title='Order Details']")

	public WebElement eleOrderNumberToolTip;
	public ProductRateApproval clickOrderNumberToolTip(){
		click(eleOrderNumberToolTip);

		return this;
	}

	@FindBy(how=How.XPATH,using="//h3[text()='Order Details']/following::div/div")

	public WebElement eleOrderNumberTooltext;
	public ProductRateApproval clickToolTipText(){
		getText(eleOrderNumberTooltext);

		return this;
	}



	@FindBy(how=How.XPATH,using="//div[@class='lti-alert-msg']/label")
	public WebElement eleWindowMsg;
	public ProductRateApproval clickWindowMsg(){
		try {
			String text = getText(eleWindowMsg);
			if (text.equals(text)) {
				reportStep("Text Matched", "Pass");
			}else {
				reportStep("Text not Matched", "Fail");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return this;
	}



	@FindBy(how=How.XPATH,using="//span[text()='Close']/..")

	public WebElement eleCloseMessage;
	public ProductRateApproval clickCloseMessage(){
		click(eleCloseMessage);

		return this;
	}

	@FindBy(how=How.ID,using="btnno")

	public WebElement eleNo;
	public ProductRateApproval clickNO(){
		click(eleNo);

		return this;
	}

	@FindBy(how=How.ID,using="btnyes")

	public WebElement eleYes;
	public ProductRateApproval clickYes(){
		click(eleYes);

		return this;
	}
	@FindBy(how=How.ID,using="lblwindowmsg")

	public WebElement eleMessage;
	public ProductRateApproval clickConfirmMessage(){
		String text = getText(eleMessage);
		if (text.equals(text)) {
			reportStep("Text Matched", "Pass");
		}else {
			reportStep("Text not Matched", "Fail");
		}

		return this;
	}
	@FindBy(how=How.ID,using="cmdAddGridRow")

	public WebElement eleAddRow;
	public ProductRateApproval clickAddRow(){
		
		click(eleAddRow);

		return this;
	}
	
	
	
}
