package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ViewDespatchBOMBundle extends AbstractPage{
	public static String dialogMessage,dialogTitle;
	public ViewDespatchBOMBundle(){
		PageFactory.initElements(getEventDriver(), this);
	}
	
	@FindBy(how=How.ID,using="update")
    private WebElement eleEdit;

	public ViewDespatchBOMBundle clickEdit(){
	
		click(eleEdit);
		return new ViewDespatchBOMBundle();
	}
	@FindBy(how=How.ID,using="Create")
    private WebElement eleCreate;

	public ViewDespatchBOMBundle clickCreate(){
	
		click(eleCreate);
		return new ViewDespatchBOMBundle();
	}
	
	@FindBy(how=How.ID,using="help")
    private WebElement eleHelp;

	public ViewDespatchBOMBundle clickHelp(){
	
		click(eleHelp);
		return this;
	}
	

	@FindBy(how=How.ID,using="authorize")
    private WebElement eleApprove;

	public ApprovalDespatchBOMBundle clickApprove(){
	
		click(eleApprove);
		return new ApprovalDespatchBOMBundle();
	}
	
	@FindBy(how=How.CLASS_NAME,using="mandatory-star")
	private List<WebElement> eleMandatory;

	public ViewDespatchBOMBundle verifyMandatoryFields()
	{
		String[] elements = {"Order Number ","Product Code "};
		System.out.println(verifyMandatory(elements));
		return this;

	}
	@FindBy(how=How.ID,using="lbltext")
    private WebElement eleLableText;

	public ViewDespatchBOMBundle verifyTreeViewLabletextBeforeorderEntry(){
	
		System.out.println(getText(eleLableText));
		
		System.out.println("Verification for label text is"+getText(eleLableText).contains("Select the Order Number and Product Code to view the Bundle in a Treeview"));
		return this;
	}
	//this label text should be refactored after page comes 
	public ViewDespatchBOMBundle verifyTreeViewLabletextAfterorderEntry(){
	
		System.out.println(getText(eleLableText));
		String TreeviewLabelText = getText(eleLableText);
	
		System.out.println("Verification for label text is"+getText(eleLableText).contains("You are Viewing Bundles for the Order ORD1800001-Desc Product Code PROD0001-Desc"));
		
		return this;
	}
	
	@FindBy(how=How.ID,using="OrderNumber")
    private WebElement eleOrderNumber;

	public ViewDespatchBOMBundle typeOrderNumber(String dataOrderNumber){
		pause(2);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		return this;
	}
	
	
	
	

	public ViewDespatchBOMBundle getOrderDetails(){
	
		System.out.println(getAttributeText(eleOrderNumber, "value"));
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//i[@data-toggle='destOrderPopover']/following-sibling::div")
    private WebElement eleOrderInfoDetails;

	public ViewDespatchBOMBundle getOrderInfoIcon(){
	
		System.out.println(getText(eleOrderInfoDetails));
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//i[@data-toggle='destProductPopover']/following-sibling::div")
    private WebElement eleProductInfo;

	public ViewDespatchBOMBundle getProductInfoIcon(){
		
		System.out.println(getText(eleProductInfo));
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='ProductList']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleProductCodeDd;
	public ViewDespatchBOMBundle clickProductCodeDd(){
		click(eleProductCodeDd);
		return this;
	}
	
	
	public ViewDespatchBOMBundle selectProductCode(String productCode){
		selectUsingText(locateElement("xpath", "//li[text()='"+productCode+"']"), productCode);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//input[@id='PanelList']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement elePanelCodeDd;
	public ViewDespatchBOMBundle clickPanelCodeDd(){
		click(elePanelCodeDd);
		return this;
	}
	
	public ViewDespatchBOMBundle selectPanelCode(String panelCode){
		selectUsingText(locateElement("xpath", "//li[text()='"+panelCode+"']"), panelCode);
		return this;
	}
	

	@FindBy(how=How.XPATH,using="//input[@id='BundleList']/preceding-sibling::span/span[@class='k-select']/span")

	public WebElement eleBundleCodeDd;
	public ViewDespatchBOMBundle clickBundleCodeDd(){
		click(eleBundleCodeDd);
		return this;
	}
	

	public ViewDespatchBOMBundle selectBundleCode(String bundleCode){
		selectUsingText(locateElement("xpath", "//li[text()='"+bundleCode+"']"), bundleCode);
		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//i[@data-toggle='destOrderPopover']")

	public WebElement eleOrderInfo;
	public ViewDespatchBOMBundle clickOrderInfo(){
		click(eleOrderInfo);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//i[@data-toggle='destProductPopover']")

	public WebElement eleProductinfo;
	public ViewDespatchBOMBundle clickProductinfo(){
		click(eleProductinfo);
		return this;
	}
	
	@FindBy(how=How.ID,using="Submit")

	public WebElement eleGo;
	public ViewDespatchBOMBundle clickGo(){
		click(eleGo);
		return this;
	}
	
	@FindBy(how=How.NAME,using="reset")

	private WebElement eleReset;
	public  ViewDespatchBOMBundle clickReset(){
		click(eleReset);
		return this;
	}
	
	@FindBy(how=How.ID,using="kendoWindow_wnd_title")
	public WebElement eledialogTitle;
	public ViewDespatchBOMBundle getdialogTitle() 
	{
		System.out.println(getText(eledialogTitle));
		dialogTitle=getText(eledialogTitle);
		return this;
	}
	
	@FindBy(how=How.ID,using="lblwindowmsg")
	private WebElement eledialogMsg;
	public ViewDespatchBOMBundle getdialogMsg() 
	{
		dialogMessage = getText(eledialogMsg);		
		System.out.println(dialogMessage);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	public WebElement closeMessage; 
	public ViewDespatchBOMBundle  CloseMessage()
	{
		click(closeMessage);
		return this;
	}
	
	@FindBy(how=How.ID,using="lblwindowmsg")
	public WebElement eleErrorMessage;
	public ViewDespatchBOMBundle verifyTextContainWarningMsg(String data) {
		boolean text = verifyPartialText(eleErrorMessage, data);
		if(text==true) {
			System.out.println("Text Matched");
		}else {
			System.out.println("Text not Matched");
		}
		return this;

	}
	
	@FindBy(how=How.XPATH,using="//span[text()='Error']/following::a")

	public WebElement eleClose;
	public ViewDespatchBOMBundle CloseWarningMsg(){
		click(eleClose);
		return this;
	}
}
