	package pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Sleeper;

import cucumber.api.java.en.When;


public class PanelEssentialsEdit extends AbstractPage  {

	public PanelEssentialsEdit(){
		PageFactory.initElements(getEventDriver(), this);
	}
	@FindBy(how=How.XPATH,using="//span[@onclick='UserSelectClick()']")

	public WebElement eleMovetoRight;
	public PanelEssentialsEdit clickMovetoRight(){
		click(eleMovetoRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Right']")

	public WebElement eleMoveAllRight;
	public PanelEssentialsEdit clickMoveAllRight(){
		click(eleMoveAllRight);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//i[@class='glyphicon glyphicon-menu-left'])[1]")

	public WebElement eleMovetoLeft;
	public PanelEssentialsEdit clickMovetoLeft(){
		click(eleMovetoLeft);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[@title='MoveAll to Left']")

	public WebElement eleMoveAllLeft;
	public PanelEssentialsEdit clickMoveAllLeft(){
		pause(4);
		click(eleMoveAllLeft);
		return this;
	}
	@FindBy(how=How.ID,using="OrderNumber")
    
	public WebElement eleOrderNumber;
	@When ("The OrderNumber entered")
	public PanelEssentialsEdit typeAndChooseOrderNumber(String dataOrderNumber){
		click(eleOrderNumber);
		pause(3);
		typeAndChoose(eleOrderNumber, dataOrderNumber);
		eleOrderNumber.sendKeys(Keys.TAB);
		return this;
	}
	@FindBy(how=How.XPATH,using="//span[@aria-activedescendant='ProductCode_option_selected']")
	public WebElement eleProductCode;
	@FindBy(how=How.XPATH,using="//li[@id='ProductCode_option_selected']")

	public WebElement eleProductCodeOption2;
	
	public PanelEssentialsEdit selectUsingTextProductCode(String options){
		click(eleProductCode);
		pause(2);
		click(locateElement("xpath", "//li[text()='--Select the Product Code--']/following::li["+options+"]"));
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//span[text()='Select Design Product']")

	public WebElement eleDesignProductCode;
	public PanelEssentialsEdit selectUsingTextDesignProductCode(){
		click(eleDesignProductCode);
		return this;
	}
	@FindBy(how=How.XPATH,using="//input[@id='PannelCode']/../span")

	public WebElement elePanelCode;
	public PanelEssentialsEdit selectUsingTextelePanelCode(String PanelCode){
		click(elePanelCode);
		pause(2);
		click(locateElement("xpath", "//li[text()='"+PanelCode+"']"));
		return this;
	}
	
	@FindBy(how=How.ID,using="PannelDescription")

	public WebElement elePanelDescription;
	public PanelEssentialsEdit typePanelDescription(String dataPanelDescription){
		type(elePanelDescription, dataPanelDescription);
		return this;
	}
	
	@FindBy(how=How.ID,using="txtRemarks")

	public WebElement eleRemarks;
	public PanelEssentialsEdit typeRemarks(String dataRemarks){
		type(eleRemarks, dataRemarks);
		return this;
	}
	
	@FindBy(how=How.ID,using="SubmitAssociation")

	public WebElement eleUpdate;
	public PanelEssentialsEdit clickUpdate(){
		click(eleUpdate);
		return this;
	}
	
	@FindBy(how=How.ID,using="Reset")

	private WebElement eleReset;
	public PanelEssentialsEdit clickReset(){
		click(eleReset);
		return this;
	}
	
	@FindBy(how=How.ID,using="Search")

	public WebElement eleSearch;
	public PanelEssentialsEdit typeSearch(String dataSearch){
		type(eleSearch, dataSearch);
		return this;
	}
	@FindBy(how=How.XPATH,using="//input[@value='Part']")

	public WebElement elePart;
	public PanelEssentialsEdit clickPart(){
		click(elePart);
		return this;
	}
	@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']/div[2]//tbody/tr")

	public WebElement eleBOMPartDetailsFirst;
	public PanelEssentialsEdit clickBOMPartDetailsLeft(){
		click(eleBOMPartDetailsFirst);
		return this;
	}
	
	public PanelEssentialsEdit clickBOMPartDetailsFirst(){
		pause(2);
		
	click(eleBOMPartDetailsFirst);

		return this;
	}
	
	
	@FindBy(how=How.XPATH,using="//div[@id='PanelPartDetails']/div[2]//tbody/tr/td")

	public WebElement eleBOMPartDetailsRight;
	public PanelEssentialsEdit clickBOMPartDetailsRight(){
		pause(2);
		//click(eleBOMPartDetailsFirst);
		jsClick(eleBOMPartDetailsFirst);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@id='BOMPartDetails']//tbody/tr") //Need to implement
	public List<WebElement> eleBOMPartDetails;
	public PanelEssentialsEdit MultipleSelectPartDetails() {
		
		
		return this;
	}
		
	
	@FindBy(how=How.XPATH,using="//input[@id='OrderNumber']/../following::i ")

	public WebElement eleOrderNuminfo;
	public PanelEssentialsEdit clickOrderNumberInfo(){
		click(eleOrderNuminfo);
		return this;
	}

	@FindBy(how=How.XPATH,using="//input[@id='ProductCode']/../following::i")

	public WebElement eleProductCodeinfo;
	public PanelEssentialsEdit clickProductCodeInfo(){
		click(eleProductCodeinfo);
		return this;
	}
	
	
	
	@FindBy(how=How.XPATH,using="//*[text()='Success']")

	public WebElement eleSuccessMessage;
	public PanelEssentialsEdit verifyTextContainSuccessMessage(String Success) {

		//verifyPartialText(eleErrorMessage, Success);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="Dummy")

	public WebElement eleErrorMessage;
	public PanelEssentialsEdit verifyTextContainWarningMsg(String warning) {

		verifyPartialText(eleErrorMessage, warning);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="(//span[text()='Close']/..)[1]") 
	private WebElement closeMessage; 
	public PanelEssentialsEdit  CloseWarningMsg()
	{
		click(closeMessage);
		return this;
	}
	
	
	
	public PanelEssentialsEdit OrderNumberIsNull(String value)
	{
		
		
		String OrdeNumberAttribute = getAttributeText(eleOrderNumber,value);
		if(OrdeNumberAttribute.isEmpty())
		{
			reportStep("The element "+eleOrderNumber+" is contains value", "PASS");
		}else {
			reportStep("The element "+eleOrderNumber+" is Empty", "WARNING");
		}
		
		return this;

	}
	
	public PanelEssentialsEdit ProductCodeIsNull(String value,String ProductCode)
	{
		
		
		String ProductCodeAttribute = getAttributeText(eleProductCode, value);
		if(ProductCodeAttribute.contains(ProductCode))
		{
			reportStep("The element "+eleProductCode+" is contains value", "PASS");
		}else {
			reportStep("The element "+eleProductCode+" is Empty", "WARNING");
		}
		
		return this;

	}
	
	public PanelEssentialsEdit PanelCodeIsNull(String value,String PanelCode)
	{
		
		
		String ProductCodeAttribute = getAttributeText(elePanelCode, value);
		if(ProductCodeAttribute.contains(PanelCode))
		{
			reportStep("The element "+elePanelCode+" is contains value", "PASS");
		}else {
			reportStep("The element "+elePanelCode+" is Empty", "WARNING");
		}
		
		return this;

	}
	
	
	
	@FindBy(how=How.XPATH,using="dummy")
	private WebElement eleItemsPerPage; 
	public PanelEssentialsEdit  ItemsPerPage()
	{
		
		return this;
	}

	


}
