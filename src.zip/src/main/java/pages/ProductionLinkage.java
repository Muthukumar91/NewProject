package pages;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import cucumber.api.java.en.And;



public class ProductionLinkage extends AbstractPage  {
	
	
	public ProductionLinkage(){
		// This is to load all the elements in the page
		PageFactory.initElements(getEventDriver(), this);

	}

	@FindBy(how=How.ID,using="Create")
	public WebElement eleCreate;
	public ProductionLinkage clickCreate(){
		pause(2);
		click(eleCreate);
		pause(2); 
		return this;
	}
	
	@FindBy(how=How.ID,using="txtOrderNumber")

	public WebElement eleOrderNumber;
	public ProductionLinkage TypeOrderNumber(){
		String data=WindowMessage;
		System.out.println(data);
	
		typeAndChoose(eleOrderNumber, data);
		pause(2);
		return this;
	}
	
	public ProductionLinkage TypeOrderNumber(String data){
		
		typeAndChoose(eleOrderNumber, data);
		pause(2);
		return this;
	}
	
	@FindBy(how=How.XPATH,using="//div[@id='ProductionDetails']//tbody/tr") 
	private List<WebElement> eleNoOfProductDetails;
	private int noOfRecordsInGrid;
	public ProductionLinkage getNoOfProductdetails() {
		noOfRecordsInGrid=eleNoOfProductDetails.size();
		System.out.println("The no of records in the grid are "+eleNoOfProductDetails.size());
		return this;

	}
	public int getReworkQuantity(int i){

		System.out.println("The quantity is"+getText(locateWebTableElement("Sale Rate", i)));

		int canLinkQty = Integer.parseInt(getText(locateWebTableElement("Sale Rate", i)));


		return canLinkQty;
	}

	public ProductionLinkage EnterQuantity(){

		for (int i = 1; i <= noOfRecordsInGrid; i++) {
			locateWebTableElement("To Be Load Quantity", i);
			int columnIndexreworkQuantity6=getEventDriver().findElements(By.xpath("//*[text()='To Be Load Quantity']/parent::th/preceding-sibling::*")).size()+1;
			System.out.println(columnIndexreworkQuantity6);
			WebElement Quantity = getEventDriver().findElement(By.xpath("//*[text()='To Be Load Quantity']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity6+"]/input"));
			//System.out.println((getReworkQuantity(i)+1));
			getEventDriver().findElement(By.xpath("//*[text()='To Be Load Quantity']/parent::th/following::tr["+i+"]/td["+columnIndexreworkQuantity6+"]")).click();
			pause(1);
			Quantity.sendKeys(Keys.BACK_SPACE);
			type(Quantity, "10");
			pause(1);
		}
		return this;
		}
		

	
	@FindBy(how=How.XPATH,using="//button[text()='SUBMIT']")

	public WebElement eleSubmitAssociation;
	public ProductionLinkage clickSubmit(){
	
		click(eleSubmitAssociation);
			return this;
	}
	
	

		
	@FindBy(how=How.XPATH,using="//span[@id='kendoWindow_wnd_title']/following::a")

	public WebElement eleclose;
	public ProductionLinkage ClickClose(){

		try {
			click(eleclose);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		getEventDriver().navigate().refresh();
		
		return this;
	}

	@FindBy(how=How.XPATH,using="//span[@id='kendoWindowRedirect_wnd_title']/following::a")

	public WebElement elecloseSuccess;
	public ProductionLinkage ClickCloseSucess(){

		try {
			click(elecloseSuccess);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pause(2);
		
		return this;
	}
	
	@FindBy(how=How.ID,using="btnyes")
	public WebElement elebtnyes;
	public ProductionLinkage clickYes(){
		pause(2);
		click(elebtnyes);
		getEventDriver().navigate().refresh();
		return this;
	}
	
	
	@FindBy(how = How.XPATH, using = "(//i[@class='PDSSNavigation fa fa-bars'])[2]")
	private WebElement eleNavigation;
		public LeftMenuPage clickNavigation() {
		pause(2);
		click(eleNavigation); 
		return new LeftMenuPage(); 
	}
	
	}

	

