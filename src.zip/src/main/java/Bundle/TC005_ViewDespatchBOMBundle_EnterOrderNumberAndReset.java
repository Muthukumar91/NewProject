package Bundle;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC005_ViewDespatchBOMBundle_EnterOrderNumberAndReset extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_ViewDespatchBOMBundle_EnterOrderNumberAndReset";
		testDescription="EnterOrderNumberAndReset";
		category="smoke";
		dataSource="excel";
		dataSheetName="Bundle/TC002_ViewDespatchBOMBundle_EnterOrderNumberAndClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password, String OrderNumber,String data) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickViewDespatchBOMBundle()
		.typeOrderNumber(OrderNumber)
		.clickReset()
		.verifyTreeViewLabletextBeforeorderEntry();
	
		
			
		
		
		
	}


}
