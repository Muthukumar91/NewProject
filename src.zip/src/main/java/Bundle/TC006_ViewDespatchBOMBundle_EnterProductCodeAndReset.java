package Bundle;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC006_ViewDespatchBOMBundle_EnterProductCodeAndReset extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC006_ViewDespatchBOMBundle_EnterProductCodeAndReset";
		testDescription="EnterProductCodeAndReset";
		category="smoke";
		dataSource="excel";
		dataSheetName="Bundle/TC003_ViewDespatchBOMBundle_EnterProductCodeAndClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password, String OrderNumber,String productCode) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickViewDespatchBOMBundle()
		.typeOrderNumber(OrderNumber)
		.clickProductCodeDd()
		.selectProductCode(productCode)
		.verifyTreeViewLabletextBeforeorderEntry()
		.clickReset()
		.verifyTreeViewLabletextAfterorderEntry();
		
			
		
		
		
	}


}
