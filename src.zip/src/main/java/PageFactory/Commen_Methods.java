package PageFactory;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.sikuli.script.Pattern;
import org.sikuli.script.Screen;
import org.sikuli.script.SikuliException;

public class Commen_Methods {
	public static WebDriver driver;
	public Actions ref ;

	
	//Logins
	public void login(String userName, String Password) throws InterruptedException {

		//clear(locators("id", "txtUserName"));
		type(locators("id", "txtUserName"), userName);

		//clear(locators("id", "txtPassword"));
		type(locators("id", "txtPassword"), Password);
		
		click(locators("id", "btnLogin"));
		
		System.out.println("Login Succesful");
		waitforaction();
	}
	//Navigations
	public  void Navigation() throws InterruptedException, SikuliException, AWTException {

		ref = new Actions (driver);

		//Down Arrow
		Screen s=new Screen();
		Pattern p=new Pattern("./img/Capture.PNG");
		s.click(p);

		waitforaction();
		//PDSS4.0
		Screen sd=new Screen();
		Pattern pd=new Pattern("./img/PDSS4.0.PNG");
		sd.click(pd);
		waitforaction();
		//Navigation Menu	
		Screen sn=new Screen();
		Pattern pn=new Pattern("./img/NavigationMenu.PNG");
		sn.click(pn);
		waitforaction();
		//Driver close
			}
	
	public void waitforaction() throws InterruptedException	{
		
		Thread.sleep(3000);
	}
	//Locators Methods
	public WebElement locators(String Name, String Values)
	{

		WebElement ele=null;

		switch (Name) {

		case "id" :
			ele=driver.findElement(By.id(Values));
			break;
		case "Name" :
			ele=driver.findElement(By.name(Values));
			break;
		case "Link":
			ele=driver.findElement(By.linkText(Values));
			break;
		case "PLink": 
			ele=driver.findElement(By.partialLinkText(Values));
			break;
		case "xpath": 
			ele=driver.findElement(By.xpath(Values));
			break;
		case "TName": 
			ele=driver.findElement(By.tagName(Values));
			break;
		case "CName":
			ele=driver.findElement(By.tagName(Values));
			break;
		case "CSS": 
			ele=driver.findElement(By.cssSelector(Values));
			break;
		}
		return ele;
	}
	
	public void Actionperform(WebElement ele) {
		
		ref.moveToElement(ele).click().build().perform();

	}
		
	//Clear Methods
	public void clear(WebElement ele) {
		ele.clear();

	}

	//Sendkeys Methods
	public void type(WebElement ele, String Values)
	{

		ele.sendKeys(Values);
	}
	
	public void typeAndtab(WebElement ele, String Values)
	{
		ele.clear();
		ele.sendKeys(Values,Keys.TAB);
	}
	public void tabs(WebElement ele)
	{
		
		ele.sendKeys(Keys.TAB);
	}
//Driver Close Method

	public void click(WebElement ele) {
		ele.click();
	} 
	
	public void Jscrolldown()
	{
		WebElement element = driver.findElement(By.xpath("//button[text()='Submit']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;

		js.executeScript("arguments[0].scrollIntoView();", element);
		}
	}


