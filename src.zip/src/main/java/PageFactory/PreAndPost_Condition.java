package PageFactory;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.sikuli.script.SikuliException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

public class PreAndPost_Condition extends Commen_Methods {
	
	
	@BeforeMethod
	
	public  void browser() throws InterruptedException, SikuliException {
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		 driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://eportal.htcindia.com/_index.php");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
	}
	
	@AfterMethod
	public void Quit()
	{
		
			//driver.quit();	
	}

	
}
