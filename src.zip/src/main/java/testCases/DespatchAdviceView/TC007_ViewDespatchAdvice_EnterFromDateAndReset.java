package testCases.DespatchAdviceView;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC007_ViewDespatchAdvice_EnterFromDateAndReset extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC007_ViewDespatchAdvice_EnterFromDateAndReset";
		testDescription="EnterFromDateAndReset";
		category="smoke";
		dataSource="excel";
		dataSheetName="ViewDespatchAdvice/TC001_ViewDespatchAdvice_ClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String Year,String month,String day,String date,String Year1, String month1, String day1, String date1) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchAdvice()
		
		.clickFromDateicon(Year,month,day,date)
		.ClickResetButton();
		
			
		
		
		
	}


}
