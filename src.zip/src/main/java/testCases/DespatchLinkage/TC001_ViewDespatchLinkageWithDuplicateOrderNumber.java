package testCases.DespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC001_ViewDespatchLinkageWithDuplicateOrderNumber extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_ViewDespatchLinkageWithDuplicateOrderNumber";
		testDescription="ResetButtonValidationWithNo";
		category="Functional";
		dataSource="excel";
		dataSheetName="DespacthLinkageView/TC001_ViewDespatchLinkageWithDuplicateOrderNumber";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password, String number, String message) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin(number)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchLinkage()
		.typeOrderNumber("EWL180200")
		.NoRecordsValidation(message);
		
			
		
		
		
	}


}
