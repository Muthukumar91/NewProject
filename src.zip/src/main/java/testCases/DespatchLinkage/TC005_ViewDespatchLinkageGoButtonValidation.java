package testCases.DespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC005_ViewDespatchLinkageGoButtonValidation extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_ViewDespatchLinkageGoButtonValidation";
		testDescription="GoButtonValidation";
		category="Functional";
		dataSource="excel";
		dataSheetName="DespacthLinkageView/TC005_ViewDespatchLinkageGoButtonValidation";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String message) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchLinkage()
		.clickgo()
		.errorMessageValidation(message)
		.CloseError();
			
		
		
		
	}


}
