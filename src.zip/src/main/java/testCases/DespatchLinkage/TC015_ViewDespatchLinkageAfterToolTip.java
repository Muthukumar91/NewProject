package testCases.DespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC015_ViewDespatchLinkageAfterToolTip extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC015_ViewDespatchLinkageAfterToolTip";
		testDescription="AfterClickingToolTipforOrderNumberl";
		category="Functional";
		dataSource="excel";
		dataSheetName="DespacthLinkageView/TC015_ViewDespatchLinkageAfterToolTip";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String orderNumber,String dataWarningMessage,String code,String Message) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin(orderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchLinkage()
		.typeOrderNumber(orderNumber)
		.clickOrderinfoAfter(dataWarningMessage)
		.typeConsignee(code)
		.clickConsigneeInfoAfter(Message)
		.clickgo();
				
		
		
		
	}


}
