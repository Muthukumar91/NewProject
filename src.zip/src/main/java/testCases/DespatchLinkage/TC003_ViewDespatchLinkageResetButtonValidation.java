package testCases.DespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC003_ViewDespatchLinkageResetButtonValidation extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC003_ViewDespatchLinkageResetButtonValidation";
		testDescription="ResetButtonValidationWithYes";
		category="smoke";
		dataSource="excel";
		dataSheetName="DespacthLinkageView/TC003_ViewDespatchLinkageResetButtonValidation";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String message) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchLinkage()
		.clickReset()
		.errorMessageValidation(message)
		.clickBtnYes();
			
		
		
		
	}


}
