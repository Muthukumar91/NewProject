package testCases.DespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC014_ViewDespatchLinkageBeforeToolTip extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC014_ViewDespatchLinkageBeforeToolTip";
		testDescription="BeforeClickingToolTipforOrderNumberl";
		category="Functional";
		dataSource="excel";
		dataSheetName="DespacthLinkageView/TC014_ViewDespatchLinkageBeforeToolTip";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String orderNumber,String dataWarningMessage,String Message,String code) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin(orderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchLinkage()
		.clickOrderinfoBefore(dataWarningMessage)
		.typeOrderNumber(orderNumber)
		.clickConsigneeInfoBefore(Message)
		.typeConsignee(code)
		.clickgo();
				
		
		 
		
	}


}
