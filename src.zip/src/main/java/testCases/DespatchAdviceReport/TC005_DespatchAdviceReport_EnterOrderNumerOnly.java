package testCases.DespatchAdviceReport;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC005_DespatchAdviceReport_EnterOrderNumerOnly extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_DespatchAdviceReport_EnterOrderNumerOnly";
		testDescription="EnterOrderNumerOnly";
		category="Functional";
		dataSource="excel";
		dataSheetName="DespatchAdviceReport/TC001_DespatchAdviceReport_ClickGenerateReport";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String Year, String month, String day, String date,String Year1, String month1, String day1, String date1, String Ordernumber, String Consignee) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickReports()
		.clickDespatchAdviceReport()
		.clicktoDateicon(Year1, month1, day1, date1)
		.clickFromDateicon(Year, month, day, date)
		.TypeOrderNumber(Ordernumber)
		.ClickGenerateReport()
		.VerifyWindowMsg()
		.ClickClose();
		
			
		
		
		
	}


}
