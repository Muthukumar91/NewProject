package testCases.ProductRateView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC005_ViewProductRate_RateTypeWithoutOtherField extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_ViewProductRate_RateTypeWithoutOtherField";
		testDescription="RateTypeWithoutOtherField";
		category="smoke";
		dataSource="Excel";
		dataSheetName="ProductRate/TC001_CreateProductRate_ClickReset";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode, String RateType) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickProductRate()
		.selectRateType(RateType)
		.clickGoButton()
		.clickWindowMsg()
		.clickCloseMessage();
		
		
		
		
		
	}

}
