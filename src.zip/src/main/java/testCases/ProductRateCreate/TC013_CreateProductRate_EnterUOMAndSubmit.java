package testCases.ProductRateCreate;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC013_CreateProductRate_EnterUOMAndSubmit extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC013_CreateProductRate_EnterUOMAndSubmit";
		testDescription="EnterUOMAndSubmit";
		category="Functional";
		dataSource="Excel";
		dataSheetName="ProductRate/TC001_CreateProductRate_ClickReset";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode, String RateType) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickProductRate()
		.clickCreateButton()
		.selectRateType(RateType)
		.typeAndChooseOrderNumber(OrderNumber)
		.selectProductCode(ProductCode)
		.clickGoButton()
		.getNoOfProductdetails()
		.EnterUOM()
		.clickSubmitButton()
		.clickWindowMsg()
		.clickCloseMessage();
		
		
	}

}
