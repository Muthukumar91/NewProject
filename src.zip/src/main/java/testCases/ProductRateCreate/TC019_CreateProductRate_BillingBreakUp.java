package testCases.ProductRateCreate;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC019_CreateProductRate_BillingBreakUp extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC019_CreateProductRate_BillingBreakUp";
		testDescription="BillingBreakUp";
		category="Functional";
		dataSource="Excel";
		dataSheetName="ProductRate/TC019_CreateProductRate_BillingBreakUp";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode, String RateType) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickProductRate()
		.clickCreateButton()
		.selectRateType2(RateType)
		.typeAndChooseOrderNumberBB(OrderNumber)
		.selectProductCode(ProductCode)
		.clickGoButton()
		.getNoOfProductdetails()
		.EnterDataInFields()
		.clickSubmitButton()
		.clickConfirmMessage()
		.clickYes();
		
		
	}

}
