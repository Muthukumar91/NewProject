package testCases.PanelEdit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC013_EditDespatchBOMPanel_Update extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC013_EditDespatchBOMPanel_Update";
		testDescription="Update";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC004_EditDespatchBOMPanel_OrderNumberPrefixedNumerals";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution() 
		.clickDespatchBOMPanel()
		.clickEdit()
		.clickUpdate()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
		
	
	}

}

