package testCases.PanelEdit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_EditDespatchBOMPanel_CompleteFlow extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="chrome";
		testCaseName="TC001_EditDespatchBOMPanel_CompleteFlow";
		testDescription="CompleteFlow";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC001_EditDespatchBOMPanel_CompleteFlow";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String dataProductCode,String PanelCode,String dataRemarks) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLoginForChrome(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution() 
		.clickDespatchBOMPanel()
		.clickEdit()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(dataProductCode)
		.selectUsingTextelePanelCode(PanelCode)
		.typeRemarks(dataRemarks)
		.clickBOMPartDetailsRight()
		.clickMovetoLeft()
		.clickUpdate();
	}

}

