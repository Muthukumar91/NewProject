package testCases.PanelEdit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC009_EditDespatchBOMPanel_ResetAfterEnteringPanelEssentials extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_EditDespatchBOMPanel_CompleteFlow";
		testDescription="ClickingUpdateDirectly";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC006_EditDespatchBOMPanel_WithMaxCharactersInPanelDesc";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String dataProductCode,String PanelCode,String dataRemarks,String Success) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution() 
		.clickDespatchBOMPanel()
		.clickEdit()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(dataProductCode)
		.clickReset();
	}

}

