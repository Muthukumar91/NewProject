package testCases.PanelEdit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC005_EditDespatchBOMPanel_OrderNumberWithLeadingSpace extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_EditDespatchBOMPanel_OrderNumberWithLeadingSpace";
		testDescription="OrderNumberWithLeadingSpace";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC005_EditDespatchBOMPanel_OrderNumberWithLeadingSpace";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution() 
		.clickDespatchBOMPanel()
		.clickEdit()
		.typeAndChooseOrderNumber(OrderNumber);
	    

	}
}


