package testCases.PanelEdit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC014_EditDespatchBOMPanel_Reset extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC014_EditDespatchBOMPanel_Reset";
		testDescription="ClickingReseetButtonAfterEnteringOrderNumber";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC004_EditDespatchBOMPanel_OrderNumberPrefixedNumerals";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution() 
		.clickDespatchBOMPanel()
		 .clickEdit()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickReset();
		
	
	}

}

