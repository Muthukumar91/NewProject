package testCases.PanelEdit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC003_EditDespatchBOMPanel_ToolTipAfterEnteringData extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC003_EditDespatchBOMPanel_ToolTipAfterEnteringData";
		testDescription="Tool tip Order Number and Product code before entry";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC003_EditDespatchBOMPanel_ToolTipAfterEnteringData";
		authors="Muthu";
	}

	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String dataProductCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution() 
		.clickDespatchBOMPanel()
		.clickEdit()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickOrderNumberInfo()
		.selectUsingTextProductCode(dataProductCode)
		.clickProductCodeInfo();

	}
}


