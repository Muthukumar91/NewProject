package testCases.PanelEdit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC015_EditDespatchBOMPanel_UpdateWithOnlyOrderNumber extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC015_EditDespatchBOMPanel_UpdateWithOnlyOrderNumber";
		testDescription="ClickingOrderNumberButtonAfterEnteringOrderNumber";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC015_EditDespatchBOMPanel_UpdateWithOnlyOrderNumber";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution() 
		.clickDespatchBOMPanel()
		.clickEdit()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickUpdate();
		
		
	
	}

}

