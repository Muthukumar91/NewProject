package testCases.PanelEdit;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC002_EditDespatchBOMPanel_ToolTipBeforeEnteringData extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC002_EditDespatchBOMPanel_ToolTipBeforeEnteringData";
		testDescription="Tool tip Order Number and Product code before entry";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC002_EditDespatchBOMPanel_ToolTipBeforeEnteringData";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution() 
		.clickDespatchBOMPanel()
		.clickEdit()
		.clickProductCodeInfo()
		.clickOrderNumberInfo();

}
}
	

