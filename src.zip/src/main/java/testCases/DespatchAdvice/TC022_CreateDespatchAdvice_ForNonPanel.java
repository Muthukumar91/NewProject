package testCases.DespatchAdvice;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC022_CreateDespatchAdvice_ForNonPanel extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC022_CreateDespatchAdvice_ForNonPanel";
		testDescription="ForNonPanel";
		category="Functional";
		dataSource="excel";
		dataSheetName="TC018_CreateDespatchAdvice_BudleDetailsTypeQuantity";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String dataDAType,String OrderNumber,String dataPanelCode) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchAdvice()
		.ClickCreate()
		.typeAndChooseDAType(dataDAType)
		.typeAndChooseOrderNumber(OrderNumber)
		.typeAndChooseConsigneeCode()
		//.selectUsingTextProductCode()
		.selectUsingTextPanelCode(dataPanelCode)
		.selectUsingTextLotNumber("")
		.checkNonPanelCheckbox()
		.addpartDetails()
		.getNoOfProductdetails()
		.EnterGridDetails()
		.clickSubmit()
		.CloseWarningMsg();
		
		
		

		
		
	}


}
