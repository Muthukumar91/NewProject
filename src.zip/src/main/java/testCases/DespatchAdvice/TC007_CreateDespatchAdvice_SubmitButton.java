package testCases.DespatchAdvice;

import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC007_CreateDespatchAdvice_SubmitButton extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC007_CreateDespatchAdvice_SubmitButton";
		testDescription="ClickingSubmitButton";
		category="Functional";
		dataSource="excel";
		dataSheetName="TC007_CreateDespatchAdvice_SubmitButton";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String OrderNumber,String message) throws InterruptedException, FileNotFoundException, ClassNotFoundException, IOException, SQLException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchAdvice()
		.ClickCreate()
		.typeAndChooseDAType("select top 1 MDAT_Description from EIPPDSS.[PDSMAS].[GEN_M_DA_Types] where MDAT_ISActive = 'Y' and MDAT_MU_Code='1616' ORDER BY newid()")
		.typeAndChooseOrderNumber(OrderNumber)
		.clickSubmit()
		.verifyTextContainWarningMsg(message)
		.CloseWarningMsg();
		
			
		
		
		
	}


}
