package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC016_ViewDespatchBOMPanel_DbValidationWithCode extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC016_ViewDespatchBOMPanel_DbValidationWithCode";
		testDescription="OrderNumberWithSpace";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC016_ViewDespatchBOMPanel_DbValidationWithCode";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String sql) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.clickGo()
		.gridUIValidation()
		.dbvalidation(sql)
		.compareString();
		
		
		
		
		
		
	}

}
