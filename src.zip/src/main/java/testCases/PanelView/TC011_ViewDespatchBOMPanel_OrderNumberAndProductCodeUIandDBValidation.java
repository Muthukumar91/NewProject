package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC011_ViewDespatchBOMPanel_OrderNumberAndProductCodeUIandDBValidation extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC011_ViewDespatchBOMPanel_OrderNumberAndProductCodeUIandDBValidation";
		testDescription="OrderNumberWithSpace";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC011_ViewDespatchBOMPanel_OrderNumberAndProductCodeUIandDBValidation";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String sql) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.clickGo()
		.gridUIValidation()
		.dbvalidation(sql)
		.compareString();
		
		

		
		
	}

}
