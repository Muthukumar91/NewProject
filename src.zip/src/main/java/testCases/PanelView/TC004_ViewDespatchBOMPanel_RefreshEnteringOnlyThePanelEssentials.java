package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC004_ViewDespatchBOMPanel_RefreshEnteringOnlyThePanelEssentials extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC004_ViewDespatchBOMPanel_RefreshEnteringOnlyThePanelEssentials";
		testDescription="RefreshEnteringOnlyThePanelEssentials";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC003_ViewDespatchBOMPanel_ToolTipOrderNumberAndProductCodeBeforeEntry";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickOrderNumberInfoAfter(OrderNumber)
		.clickOrderNumberInfo()
		.selectUsingTextProductCode(ProductCode)
		.clickProductCodeInfoAfter()
		.clickGo();
	
	}

}
