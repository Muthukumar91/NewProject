package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC009_ViewDespatchBOMPanel_OrderNumberAndProductCodeUIValidation extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC009_ViewDespatchBOMPanel_OrderNumberAndProductCodeUIValidation";
		testDescription="OrderNumberAndProductCodeUIValidation";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC009_ViewDespatchBOMPanel_OrderNumberAndProductCodeUIValidation";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.clickGo()
		.gridUIValidation();
		
	
		
		
		
		
		
	}

}
