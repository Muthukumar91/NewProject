package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC012_ViewDespatchBOMPanel_ResetAndEnterOrderNumber extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC012_ViewDespatchBOMPanel_ResetAndEnterOrderNumber";
		testDescription="ResetAndEnterOrderNumber";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC012_ViewDespatchBOMPanel_ResetAndEnterOrderNumber";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.clickGo()
		.gridUIValidation()
		.clickReset()
		.ResetVerification()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickGo();
		
		

		
		
	}

}
