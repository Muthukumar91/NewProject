package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_ViewDespatchBOMPanel_ClickReset extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_ViewDespatchBOMPanel_ClickReset";
		testDescription="ClickReset";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC001_ViewDespatchBOMPanel_ClickReset";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickReset()
		.ResetVerification();
		
		
		
		
		
	}

}
