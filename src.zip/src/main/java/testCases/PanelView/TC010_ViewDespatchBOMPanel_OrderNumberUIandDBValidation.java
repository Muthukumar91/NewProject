package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC010_ViewDespatchBOMPanel_OrderNumberUIandDBValidation extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC010_ViewDespatchBOMPanel_OrderNumberUIandDBValidation";
		testDescription="OrderNumberWithSpace";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC010_ViewDespatchBOMPanel_OrderNumberUIandDBValidation";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String sql) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickGo()
		.gridUIValidation()
		.dbvalidation(sql)
		.compareString();
		
		
		
		
		
	}

}
