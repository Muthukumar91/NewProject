package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC007_ViewDespatchBOMPanel_OrderNumberWithSpace extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC007_ViewDespatchBOMPanel_OrderNumberWithSpace";
		testDescription="OrderNumberWithSpace";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC007_ViewDespatchBOMPanel_OrderNumberWithSpace";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickGo()
		.getNoRecords();
		
		
		
		
	}

}
