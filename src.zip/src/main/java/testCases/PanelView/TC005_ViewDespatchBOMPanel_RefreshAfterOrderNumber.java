package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC005_ViewDespatchBOMPanel_RefreshAfterOrderNumber extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_ViewDespatchBOMPanel_RefreshAfterOrderNumber";
		testDescription="ClickRefreshAfterOrderNumber";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC005_ViewDespatchBOMPanel_RefreshAfterOrderNumber";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickGo()
		.clickReferesh()
		.ResetVerification();
		
		
		
		
	}

}
