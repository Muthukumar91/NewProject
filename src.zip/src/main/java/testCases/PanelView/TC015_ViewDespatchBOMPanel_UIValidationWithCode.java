package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC015_ViewDespatchBOMPanel_UIValidationWithCode extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC015_ViewDespatchBOMPanel_UIValidationWithCode";
		testDescription="OrderNumberWithSpace";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC015_ViewDespatchBOMPanel_UIValidationWithCode";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.clickGo()
		.gridUIValidation();
		
		
		
		
		
		
	}

}
