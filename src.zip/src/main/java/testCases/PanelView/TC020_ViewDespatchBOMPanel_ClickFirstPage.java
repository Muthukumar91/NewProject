package testCases.PanelView;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC020_ViewDespatchBOMPanel_ClickFirstPage extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC017_ViewDespatchBOMPanel_ClickNext";
		testDescription="EnterPageNumber";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC014_ViewDespatchBOMPanel_Enteritems";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PageNumber) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.clickGo()
		.enteritems(PageNumber)
		.ClickNextPage()
		.ClickFirstPage();
		
		

		
		
	}

}
