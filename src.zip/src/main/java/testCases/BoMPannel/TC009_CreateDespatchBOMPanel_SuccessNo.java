package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC009_CreateDespatchBOMPanel_SuccessNo extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="chrome";
		testCaseName="TC009_CreateDespatchBOMPanel_SuccessNo";
		testDescription="Create Despatch BOM - Panel";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC009_CreateDespatchBOMPanel_SuccessNo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription,String Remarks) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLoginForChrome(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.typePanelDescription(PanelDescription)
		.clickBOMPartDetailsFirst()
		.clickMovetoRight()
		.typeRemarks(Remarks)
		.clickSubmit()
		.clickNoSuccess();
		
		
	}

}
