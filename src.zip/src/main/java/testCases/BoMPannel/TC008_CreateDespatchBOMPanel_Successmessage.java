package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC008_CreateDespatchBOMPanel_Successmessage extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="chrome";
		testCaseName="TC008_CreateDespatchBOMPanel_Successmessage";
		testDescription="BomPanelSuccessMessage";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC008_CreateDespatchBOMPanel_Successmessage";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription,String Remarks,String data) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLoginForChrome(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.clickBOMPartDetailsFirst() 
		.typePanelCode(PanelCode)
		.typePanelDescription(PanelDescription)
		.clickMovetoRight()
		.typeRemarks(Remarks)
		.clickSubmit()
		.verifySuccessMsg(data)
		.clickYesSuccess();
		
		
	}

}
