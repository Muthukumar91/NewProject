package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC005_CreateDespatchBOMPanel_MoveallRight extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC005_CreateDespatchBOMPanel_MoveallRight";
		testDescription="MoveAllPartDetailstoRightAndClickReset";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC005_CreateDespatchBOMPanel_MoveallRight";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.typePanelDescription(PanelDescription)
		//.clickBOMPartDetailsFirst()
		.clickMoveAllRight()
		.clickReset();
		
		
	}

}
