package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC018_CreateDespatchBOMPanel2_RemarksMaxDigitsInFieldMax500 extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC018_CreateDespatchBOMPanel2_RemarksMaxDigitsInFieldMax500";
		testDescription="RemarksMaxDigitsInFieldMax500";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC018_CreateDespatchBOMPanel2_RemarksMaxDigitsInFieldMax500";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription, String sql) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.typeRemarks(PanelDescription)
		.PartCodeDbText()
		.dbvalidation(sql)
		.compareString();	
		
	}

}
