package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC002_CreateDespatchBOMPanel_CheckWithOutProduct extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC002_CreateDespatchBOMPanel_CheckWithOutProduct";
		testDescription="Create Despatch BOM Panel without Product code field";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC002_CreateDespatchBOMPanel_CheckWithOutProduct";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumberDB(OrderNumber)
		.clickSubmit()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
		
		
		
		
		
		
	}

}
