package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_CreateDespatchBOMPanel_CheckwithoutMandoryField_Error extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_CreateDespatchBOMPanel_CheckwithoutMandoryField_Error";
		testDescription="Create Despatch BOM Panel without enterning Mandatory field";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC001_CreateDespatchBOMPanel_CheckwithoutMandoryField_Error";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.clickSubmit()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
		

		
		
		
	}

}
