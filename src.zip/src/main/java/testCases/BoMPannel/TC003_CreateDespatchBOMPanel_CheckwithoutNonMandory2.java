package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC003_CreateDespatchBOMPanel_CheckwithoutNonMandory2 extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="Despatch BOM - Panel";
		testDescription="Create Despatch BOM Panel without Non Mandatory field";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC003_CreateDespatchBOMPanel_CheckwithoutNonMandory2";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String num,String options, String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(num)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(num)
		.selectUsingTextProductCode(options)
		.clickSubmit()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
		
		
		
		
		
		
	}

}
