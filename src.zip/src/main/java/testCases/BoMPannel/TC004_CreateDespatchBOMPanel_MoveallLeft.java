package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC004_CreateDespatchBOMPanel_MoveallLeft extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC004_CreateDespatchBOMPanel_MoveallLeft";
		testDescription="MovingAllBOMPartDetailstoPanelDetails";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC004_CreateDespatchBOMPanel_MoveallLeft";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription,String Remarks,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd) 
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.typePanelDescription(PanelDescription)
		.clickMoveAllRight()
		.clickMoveAllLeft()
		.typeRemarks(Remarks)
		.clickSubmit()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
		
		
		
	}

}
