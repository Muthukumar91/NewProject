package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC006_CreateDespatchBOMPanel_MoveLeft extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="chrome";
		testCaseName="TC006_CreateDespatchBOMPanel_MoveLeft";
		testDescription="BomPanelwithMoveleft";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC006_CreateDespatchBOMPanel_MoveLeft";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription,String Search,String Remarks) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLoginForChrome(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.typePanelDescription(PanelDescription)
		.clickBOMPartDetailsFirst()
		.clickMovetoLeft()
		.typeRemarks(Remarks)
		.clickSubmit();
		
		
	}

}
