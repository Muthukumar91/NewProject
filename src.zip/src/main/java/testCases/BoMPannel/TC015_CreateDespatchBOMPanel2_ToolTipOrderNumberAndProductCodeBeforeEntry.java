package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC015_CreateDespatchBOMPanel2_ToolTipOrderNumberAndProductCodeBeforeEntry extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC015_CreateDespatchBOMPanel2_ToolTipOrderNumberAndProductCodeBeforeEntry";
		testDescription="ToolTipOrderNumberAndProductCodeBeforeEntry";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC013_CreateDespatchBOMPanel2_RefreshEnteringOnlyThePanelEssentials";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String des) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.clickOrderNumberInfo()
		.typeAndChooseOrderNumber(OrderNumber)
		.clickOrderNumberInfo()
		.clickProductCodeInfo()
		.selectUsingTextProductCode(ProductCode)
		.typePanelDescription(des)
		.clickMoveAllRight()
		.clickReferesh()
		.ResetVerification();
	
	}

}
