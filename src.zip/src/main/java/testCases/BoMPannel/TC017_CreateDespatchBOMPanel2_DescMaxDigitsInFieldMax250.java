package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC017_CreateDespatchBOMPanel2_DescMaxDigitsInFieldMax250 extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC017_CreateDespatchBOMPanel2_DescMaxDigitsInFieldMax250";
		testDescription="DescMaxDigitsInFieldMax250";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC017_CreateDespatchBOMPanel2_DescMaxDigitsInFieldMax250";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription, String sql) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.typePanelDescription(PanelDescription)
		.PartCodeDbText()
		.dbvalidation(sql)
		.compareString();	
		
	}

}
