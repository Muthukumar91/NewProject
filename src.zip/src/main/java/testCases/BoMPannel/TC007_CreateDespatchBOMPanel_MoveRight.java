package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC007_CreateDespatchBOMPanel_MoveRight extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="chrome";
		testCaseName="TC007_CreateDespatchBOMPanel_MoveRight";
		testDescription="BomPanelMoveToRight";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC007_CreateDespatchBOMPanel_MoveRight";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription,String Remarks) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLoginForChrome(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)	
		.typePanelDescription(PanelDescription)
		.clickBOMPartDetailsFirst()
		.clickMovetoRight()
		.clickSubmit()
		.verifyTextContainWarningMsg(Remarks)
		.CloseWarningMsg();
		
		
	}

}
