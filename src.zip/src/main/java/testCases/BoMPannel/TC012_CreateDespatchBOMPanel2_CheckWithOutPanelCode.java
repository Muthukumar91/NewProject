package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC012_CreateDespatchBOMPanel2_CheckWithOutPanelCode extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC012_CreateDespatchBOMPanel2_CheckWithOutPanelCode";
		testDescription="ClickingWithoutPanelCode";
		category="smoke";
		dataSource="Excel";
		dataSheetName="TC012_CreateDespatchBOMPanel2_CheckWithOutPanelCode";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.clickSubmit()
		.verifyTextContainWarningMsg(warning)
		.CloseWarningMsg();
	
	}

}
