package testCases.BoMPannel;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC011_CreateDespatchBOMPanel extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC011_CreateDespatchBOMPanel";
		testDescription="CreatingABOMPannelDBValidation";
		category="Functional";
		dataSource="Excel";
		dataSheetName="TC011_CreateDespatchBOMPanel";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String OrderNumber,String ProductCode,String PanelCode,String PanelDescription, String sql, String Remarks) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin(OrderNumber)
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickDespatchBOMPanel()
		.clickCreate()
		.typeAndChooseOrderNumber(OrderNumber)
		.selectUsingTextProductCode(ProductCode)
		.typePanelCode(PanelCode)
		.typePanelDescription(PanelDescription)
		.PartCodeDbText()
		.dbvalidation(sql)
		.compareString()
		.typeRemarks(Remarks)
		.clickSubmit()
		.CloseWarningMsg();
	
		
		
	}

}
