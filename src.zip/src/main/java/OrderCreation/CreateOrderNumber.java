package OrderCreation;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class CreateOrderNumber {
	public String url ="https://eip-tb.lntecc.com/eiplogin.aspx?strLoginPage=1";
	public String name ="dataSheet";
	public String sessionId="";
	
	@Test
	public void create() throws InterruptedException {
		//FBFD1178 - ALU FORMWORK--job code 

		System.setProperty("webdriver.ie.driver", "./drivers/IEDriverServer.exe");
		InternetExplorerDriver driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
		driver.findElementById("txtUserName").sendKeys("sbkms");
		driver.findElementById("txtPassword").sendKeys("Welcome@018");
		driver.findElementById("btnLogin").click();
		Thread.sleep(5000);
		String currentUrl = driver.getCurrentUrl();	
		if(currentUrl.contains(url+"/MemberPage/ESMMgmt.aspx?SessionID=")) {
			sessionId = currentUrl.replace(url+"/MemberPage/ESMMgmt.aspx?SessionID=", "");
		}
		driver.get(url+"/EIPPDSS/CommonGetSession.aspx?strpage=PDSHome/PDSHome&SessionID="+sessionId);
		Thread.sleep(5000);
		driver.findElementByXPath("(//i[@class='PDSSNavigation fa fa-bars'])[2]").click();
		driver.findElementByLinkText("Document").click();
		Thread.sleep(2000);
		driver.findElementByLinkText("Order Mgmt.").click();
		Thread.sleep(2000);
		driver.findElementByLinkText(" Manufacturing Orders  ").click();
		Thread.sleep(2000);
		 
		driver.findElement(By.xpath("//input[@data-val='Create']")).click();
		System.out.println("Clicked on Create button");
		Thread.sleep(4000);
		driver.findElement(By.xpath("//span[@class='k-input']")).click();
		
		driver.findElement(By.id("JobOrders_OrderDescription")).sendKeys("Testing the Order Description");
	
		Thread.sleep(1000);
		driver.findElement(By.id("JobOrders_JobCode")).sendKeys("FCWI1152");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//ul[@id='JobOrders_JobCode_listbox']/li")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("JobOrders_ExpiryDate")).clear();
		Thread.sleep(1000);
		driver.findElement(By.id("JobOrders_ExpiryDate")).sendKeys("08-Apr-2025");
		Thread.sleep(2000);
		driver.findElement(By.id("JobOrders_CustomerCode")).sendKeys("LO00419");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//ul[@id='JobOrders_CustomerCode_listbox']/li")).click();
		Thread.sleep(4000);
		driver.findElement(By.id("JobOrders.ClientOrderNumber")).sendKeys("ORN1259");
		Thread.sleep(2000);
		driver.findElement(By.id("JobOrders.TenderRefNumber")).sendKeys("TRN256983");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@data-value='Despatch']")).click();
		driver.findElement(By.id("txtDescription")).sendKeys("Testing Invoice Message");
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@value='Despatch']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@data-value='Commercial']")).click();
		Thread.sleep(2000);
		
		Thread.sleep(4000);
		
		Thread.sleep(2000);
		driver.findElement(By.xpath("//label[@for='OrderValue']/following::div/span/span/input")).sendKeys("20");
		
		Thread.sleep(3000);
		driver.findElement(By.id("CommercialDetails_PenaltyEffectiveFrom")).clear();
		driver.findElement(By.id("CommercialDetails_PenaltyEffectiveFrom")).sendKeys("08-May-2025");
		
		driver.findElement(By.xpath("//button[@value='Commercial']")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	}
	
}
