package OrderCreation;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC001_CreateOrder extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_ViewDeliveryChallan_ClickGo";
		testDescription="ClickGo";
		category="Functional";
		dataSource="Excel";
		dataSheetName="DC/TC001_CreateDeliveryChallan_ClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData", invocationCount=5)
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin("TPR")
		.clickNavigation()
		.clickDocument()
		.clickSalesandDistribution()
		.clickManufacturingOrders()
		.clickCreate()
		.TypeJobOrdersDescription("FOR DA")
		.SelectOrderType()
		.TypeJobCode("LE080008")//EKFAC022
		.TypeCustomerCode("NO01438")//1O000001
		.TypeClientOrderDate("30-Aug-2007")
		.TypeClientOrderNumber("FOR DA")
		.ClickDespatch()
		.TypeInvoiceMessage("FOR DA")
		.ClickOK()
		.ClickCommercial()
		.TypeEnterOrderValue("100")
		.ClickCurrency()
		.ClickBillingType()
		.ClickCommericalOK()
		.ClickSubmit()
		.getWindowMsg()
		.ClickClose()
		.ClickAuthorize()
		.TypeOrderNumber()
		.Clicksubmit()
		.ClickChkASelectAll()
		.ClickSubmit()
		.ClickClose()
		.clickNavigation()
		.clickDocument()
		.clickDesign()
		.clickProducts()
		.clickCreate()
		.TypeDesignOrder()
		.TypeProductCode("Customer")
		.TypeShortDescription("Customer")
		.clickCustomerProduct()
		.TypeReqQty("10")
		.ClickSubmit()
		.ClickClose()
		.TypeDesignOrder()
		.TypeProductCode("Design")
		.TypeShortDescription("Design")
		.clickDesignProduct()
		.TypeReqQty("10")
		.ClickSubmit()
		.ClickClose()
		.clickNavigation()
		.clickDocument()
		.clickDesign()
		.clickProductionBOM()
		.clickCreate()
		.TypeOrderNumber()
		.SelectProductCode()
		.clickExcelUpload()
		.clickUpload()
		.ClickCloseSucess()
		.clickAuthorize()
		.TypeOrderNumber()
		.ClickChkASelectAll()
		.ClickAPPROVE()
		.ClickClose()
		.clickNavigation()
		.clickDocument()
		.clickDesign()
		.clickBOMAssociation()
		.clickCreate()
		.TypeOrderNumber()
		/*.SelectProductCodeDesign()
		.SelectAssociationTypeWelding()
		.SelectPartCode("RP82A1352W")
		.TypeSearch("RP82A1351R")
		.clickMoveAll()
		.clickSubmit()
		.ClickClose()
		.clickYes()
		.SelectPartCode("RP82A1355W")
		.TypeSearch("RP82A1353R")
		.clickMoveAll()
		.clickSubmit()
		.ClickClose()
		.clickYes()
		.SelectAssociationTypeAssembly()
		.SelectPartCode("RP82A1996A")
		.TypeSearch("")
		.clickMoveAll()
		.clickSubmit()
		.ClickClose()
		.clickYes()*/
		.SelectProductCode()
		.SelectAssociationType()
		.clickMoveAll()
		.clickSubmit()
		.ClickClose()
		.clickNO()
	/*	.clickNavigation()
		.clickDocument()
		.clickPlanning()
		.clickProcessFlow()
		.clickCreate()
		.TypeOrderNumber()
		.SelectProductCode()
		.SelectPartType()
		.clickPartCode()
		.TypeSearch("44")
		.clickSubmit()
		.clickYes()
		.SelectPartTypeWelding()
		.clickPartCode()
		.TypeSearch("44")
		.TypeSearch("235")
		.clickSubmit()
		.clickYes()
		.SelectPartTypeAssembly()
		.clickPartCode()
		.TypeSearch("27")
		.clickSubmit()
		.clickYes()
		.clickAuthorize()
		.TypeOrderNumber()
		.SelectProductCode()
		.clickCheckAll()
		.clickApprove()
		.ClickClose()*/
		.clickNavigation()
		.clickDocument()
		.clickPlanning()
		.clickProductionLinkage()
		.clickCreate()
		.TypeOrderNumber()
		.getNoOfProductdetails()
		.EnterQuantity()
		.clickSubmit()
		.clickYes()
		.ClickClose();
		/*.clickNavigation()
		.clickDocument()
		.clickPlanning()
		.clickRouteCardGeneration()
		.clickCreate()
		.TypeOrderNumber()
		.SelectProductCode()
		.SelectLotNumber()
		.SelectRCType()
		.TypeRawMaterial()
		.TypeBatchQuantity()
		.clickPartCode()
		.clickSubmit()
		.ClickCloseSucess();*/
		
		
		
		
		
		
	}

}
