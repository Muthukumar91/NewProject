package OrderCreation;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC006_ProcessFlow extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_ViewDeliveryChallan_ClickGo";
		testDescription="ClickGo";
		category="Functional";
		dataSource="Excel";
		dataSheetName="DC/TC001_CreateDeliveryChallan_ClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickPlanning()
		.clickProcessFlow()
		.clickCreate()
		.TypeOrderNumber("TPR180181")
		.SelectProductCode()
		.SelectPartType()
		.clickPartCode()
		.TypeSearch("44")
		.clickSubmit()
		.clickYes()
		.SelectPartTypeWelding()
		.clickPartCode()
		.TypeSearch("44")
		.TypeSearch("235")
		.clickSubmit()
		.clickYes()
		.SelectPartTypeAssembly()
		.clickPartCode()
		.TypeSearch("27")
		.clickSubmit()
		.clickYes()
		.clickAuthorize()
		.TypeOrderNumber("TPR180181")
		.SelectProductCode()
		.clickCheckAll()
		.clickApprove()
		.ClickClose();
		
		
		
		
	}

}
