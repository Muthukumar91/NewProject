package OrderCreation;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC002_CreateProducts extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_ViewDeliveryChallan_ClickGo";
		testDescription="ClickGo";
		category="Functional";
		dataSource="Excel";
		dataSheetName="DC/TC001_CreateDeliveryChallan_ClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDesign()
		.clickProducts()
		.clickCreate()
		.TypeDesignOrder("EWL180344")
		.TypeProductCode("Customer")
		.TypeShortDescription("Customer")
		.clickCustomerProduct()
		.TypeReqQty("10")
		.ClickSubmit()
		.ClickClose()
		.TypeDesignOrder("EWL180344")
		.TypeProductCode("Design")
		.TypeShortDescription("Design")
		.clickDesignProduct()
		.TypeReqQty("10")
		.ClickSubmit()
		.ClickClose();
		
		
		
		
		
		
		
	}

}
