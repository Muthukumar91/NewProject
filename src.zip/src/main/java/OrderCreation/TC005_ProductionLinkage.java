package OrderCreation;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.LoginPage;

public class TC005_ProductionLinkage extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC001_ViewDeliveryChallan_ClickGo";
		testDescription="ClickGo";
		category="Functional";
		dataSource="Excel";
		dataSheetName="DC/TC001_CreateDeliveryChallan_ClickGo";
		authors="Muthu";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd,String Year, String month, String day, String date,String warning) {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickPlanning()
		.clickProductionLinkage()
		.clickCreate()
		.TypeOrderNumber("TPR180189")
		.getNoOfProductdetails()
		.EnterQuantity()
		.clickSubmit()
		.clickYes()
		.ClickClose();
		
		
		
		
	}

}
