package base;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Key;


public class WdMethods extends WdEventImpl{	
	public static int dbRowCount;

	public WebElement locateElement(String how, String using) {
		WebElement ele = null;
		switch(how) {
		case("id"):
			ele = getEventDriver().findElement(By.id(using));
		break;
		case("name"):
			ele = getEventDriver().findElement(By.name(using)); 
		break;
		case("linkText"):
			ele = getEventDriver().findElement(By.linkText(using));
		break;
		case("xpath"):
			ele = getEventDriver().findElement(By.xpath(using));
			System.out.println(ele);
		break;
		case("partialLinkText"):
			ele = getEventDriver().findElement(By.partialLinkText(using));
		break;
		case("cssSelector"):
			ele = getEventDriver().findElement(By.cssSelector(using));
		break;
		case("tagName"):
			ele = getEventDriver().findElement(By.tagName(using));
		break;
		case("className"):
			ele = getEventDriver().findElement(By.className(using));
		break;
		default:
			reportStep("The given locator "+how+" is not correct", "FAIL");
			break;
		}
		return ele;			
	}
	
	
	public void mouseOverOnElement(WebElement ele) {
		
		new Actions(getEventDriver()).moveToElement(ele).clickAndHold().keyDown(Keys.SHIFT).keyDown(Keys.ARROW_DOWN).build().perform();
		pause(1);
	}
	
	public void ActionClick(WebElement ele) {
		pause(2);
		
		new Actions(getDriver()).click(ele).perform();
	}
	public void jsClick(WebElement ele) {
		pause(2);
		((JavascriptExecutor) getDriver()).executeScript("arguments[0].click();", ele);
		
	}
	
	
	//Added by Srujana to find the column number that we need to interact with in webtable
	
	public WebElement locateWebTableElement(String columnName,int rowIndex) {
		WebElement ele = null;
		switch("xpath") {
		
		case("xpath"):
			int columnIndex=getEventDriver().findElements(By.xpath("//*[text()='"+columnName+"']/parent::th/preceding-sibling::*")).size()+1;
			ele = getEventDriver().findElement(By.xpath("//*[text()='"+columnName+"']/parent::th/following::tr["+rowIndex+"]/td["+columnIndex+"]"));
			System.out.println(ele);
		
		break;
		
		default:
			reportStep("The given locator xpath is not correct", "FAIL");
			break;
		}
		return ele;			
	}

	public void clear(WebElement ele) {
		
		ele.clear();
	}

	public void type(WebElement ele, String data) {
		ele.clear();
		ele.sendKeys(data);
	}
	
	public void typeAndTab(WebElement ele, String data) {
		ele.clear();
		ele.sendKeys(data, Keys.TAB);
	}

	public void typeAndChoose(WebElement ele, String data) {
		//ele.clear();
		ele.sendKeys(data);
		pause(2);
		try {
			ele.sendKeys(Keys.DOWN, Keys.ENTER, Keys.TAB);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	
	
	
	public void click(WebElement ele) {
		ele.click();
		
	}

	public void selectUsingText(WebElement ele, String text) {
		select(ele, "text", text);
	}

	public void selectUsingValue(WebElement ele, String value) {
		select(ele, "value", value);
	}

	public void selectUsingIndex(WebElement ele, int index) {
		new Select(ele).selectByIndex(index);
	}

	private void select(WebElement ele, String type, String textOrValue) {
		if(ele.getTagName().equals("select")) {
			if(type.equalsIgnoreCase("text"))
				new Select(ele).selectByVisibleText(textOrValue);
			else
				new Select(ele).selectByValue(textOrValue);
		}else {
			ele.click();
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
			}
			//locateElement("xpath", "//li[text()='"+textOrValue+"']").click();			
		}
	}
	public int StringToInteger(String text){
		return Integer.parseInt(text);
	}	
	public String getText(WebElement ele){
		return ele.getText();
	}	

	public String getAttributeText(WebElement ele, String value){
		return ele.getAttribute(value);
	}

	public boolean verifyText(WebElement ele, String text) {
		return ele.getText().equals(text);
	}

	public boolean verifyPartialText(WebElement ele, String text) {
		return ele.getText().contains(text);
	}	

	public boolean verifyTitle(String title) {
		return getEventDriver().getTitle().equalsIgnoreCase(title);
	}


	public void switchToFrame(WebElement ele) {
		getEventDriver().switchTo().frame(ele);
	}

	public void switchToFrame(int index) {
		getEventDriver().switchTo().frame(index);
	}

	public void acceptAlert() {
		getEventDriver().switchTo().alert().accept();
	}

	public void dismissAlert() {
		getEventDriver().switchTo().alert().dismiss();
	}

	public void sendTextAlert(String txt) {
		getEventDriver().switchTo().alert().sendKeys(txt);
	}

	public String getTextAlert() {
		return getEventDriver().switchTo().alert().getText();
	}	

	public void switchWindow(int index) {
		List<String> lstWindows = new ArrayList<>();
		lstWindows.addAll(getEventDriver().getWindowHandles());
		getEventDriver().switchTo().window(lstWindows.get(index));
	}


	
	
	public void pause(long seconds) {
		try {
			Thread.sleep(seconds*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void check(WebElement ele) {
		if(!ele.isSelected()) {
			ele.click();
		}
	}
	

	
	
	
	public void verifyExists(WebElement ele) {
		if(ele.isDisplayed()) {
			reportStep("The element "+ele+" is visible", "PASS");
		}else {
			reportStep("The element "+ele+" is not visible", "WARNING");
		}
	}
	
	
	//Added by Srujana for DB execution 
	public static Object[][] getDataFromDb(String sql){



		// JDBC driver name and database URL
		final String JDBC_DRIVER = PreAndPost.config.getProperty("DB_Pkg");  
		final String DB_URL = PreAndPost.config.getProperty("DB_Url");

		//  Database credentials
		final String USER = PreAndPost.config.getProperty("DB_User");
		final String PASS = PreAndPost.config.getProperty("DB_Pwd");

		Connection conn = null;
		Statement stmt = null;

		Object[][] data = null;

		try{

			//STEP 2: Register JDBC driver
			Class.forName(JDBC_DRIVER);

			//STEP 3: Open a connection
			conn = DriverManager.getConnection(DB_URL,USER,PASS);

			//STEP 4: Execute a query
			stmt = conn.createStatement();

			String count = "Select count(*) from ("+sql+") AS T";
			ResultSet rs = stmt.executeQuery(count);
			rs.next();
			int rowCount = rs.getInt(1);

			// Now run the query
			rs = stmt.executeQuery(sql);
			ResultSetMetaData rsmd=rs.getMetaData();
			

			// get the column count
			int columnCount = rsmd.getColumnCount();

			data = new Object[rowCount][columnCount]; // assign to the data provider array
			int i = 0;

			//STEP 5: Extract data from result set
			while(rs.next()){

				for (int j = 1; j <= columnCount; j++) {
					switch (rsmd.getColumnType(j)) {
					case Types.VARCHAR:
						data[i][j-1] = rs.getString(j);
						break;
					case Types.NULL:
						data[i][j-1] = "";
						break;
					case Types.CHAR:
						data[i][j-1] = rs.getString(j);
						break;
					case Types.TIMESTAMP:
						data[i][j-1] = rs.getDate(j);
						break;
					case Types.DOUBLE:
						data[i][j-1] = rs.getDouble(j);
						break;
					case Types.INTEGER:
						data[i][j-1] = rs.getInt(j);
						break;
					case Types.SMALLINT:
						data[i][j-1] = rs.getInt(j);
						break;

					}
				}
				i++;
			}
			//STEP 6: Clean-up environment
			rs.close();
			stmt.close();
			conn.close();

		}catch(SQLException se){

			//Handle errors for JDBC
			se.printStackTrace();

		}catch(Exception e){

			//Handle errors for Class.forName
			e.printStackTrace();

		}finally{

			try{
				if(stmt!=null)
					stmt.close();
			}catch(SQLException se){
				se.printStackTrace();
			}

			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
		return data;


	}
	
	/* Added By Sudarshan */
	public void VerifyElementIsEnabled(WebElement ele)
	{
		if(ele.isEnabled())
		{
			
			reportStep("The element "+ele+" is Enabled", "PASS");
		}else {
			reportStep("The element "+ele+" is Disabled", "WARNING");
		}
	}
	
	/* Added By Sudarshan */
	public void VerifyElementIsDisabled(WebElement ele)
	{
		if(!ele.isEnabled())
		{
			
			reportStep("The element "+ele+" is Disabled", "PASS");
		}else {
			reportStep("The element "+ele+" is Enabled", "WARNING");
		}
	}
	
	/* Added By Sudarshan */
	public void typeandEnter(WebElement ele,String data ) {
		
		ele.sendKeys(data,Keys.ENTER);
		
	}
	
	public void EnterNotClick(WebElement ele)
	{
		
		try {
			new Robot().mousePress(InputEvent.BUTTON1_MASK);
			pause(1);	
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
	public boolean verifyMandatory(String[] elements) {
		
		boolean bMandatory = false;
		String allElements = "";		
		
		// Go to each element
		for (String elementText : elements) {
			WebElement element = locateElement("xpath", "//label[text()='"+elementText+"']/span[@class='mandatory-star']");
			if(element == null) {
				reportStep("The element "+elementText+" is not mandatory", "WARNING");
				bMandatory = false;
			}
			allElements = allElements + elementText + " ";
		}
		
		
		// Report if all successful
		if(bMandatory)
			reportStep("The element(s) "+allElements+" are displayed as mandatory fields", "PASS");
		
		return bMandatory;
	}
	
	//Added by Srujana for DB execution 
		public static Object[][] getDataFromDB(String sql){



			// JDBC driver name and database URL
			final String JDBC_DRIVER = PreAndPost.config.getProperty("DB_Pkg");  
			final String DB_URL = PreAndPost.config.getProperty("DB_Url");

			//  Database credentials
			final String USER = PreAndPost.config.getProperty("DB_User");
			final String PASS = PreAndPost.config.getProperty("DB_Pwd");

			Connection conn = null;
			Statement stmt = null;

			Object[][] data = null;

			try{

				//STEP 2: Register JDBC driver
				Class.forName(JDBC_DRIVER);

				//STEP 3: Open a connection
				conn = DriverManager.getConnection(DB_URL,USER,PASS);

				//STEP 4: Execute a query
				stmt = conn.createStatement();

				String count = "Select count(*) from ("+sql+") AS T";
				ResultSet rs = stmt.executeQuery(count);
				rs.next();
				dbRowCount = rs.getInt(1);
				System.out.println("DB rows fetechded are "+dbRowCount);
				// Now run the query
				rs = stmt.executeQuery(sql);
				ResultSetMetaData rsmd=rs.getMetaData();
				

				// get the column count
				int columnCount = rsmd.getColumnCount();

				data = new Object[dbRowCount][columnCount]; // assign to the data provider array
				int i = 0;

				//STEP 5: Extract data from result set
				while(rs.next()){

					for (int j = 1; j <= columnCount; j++) {
						switch (rsmd.getColumnType(j)) {
						case Types.VARCHAR:
							data[i][j-1] = rs.getString(j);
							break;
						case Types.NULL:
							data[i][j-1] = "";
							break;
						case Types.CHAR:
							data[i][j-1] = rs.getString(j);
							break;
						case Types.TIMESTAMP:
							data[i][j-1] = rs.getDate(j);
							break;
						case Types.DOUBLE:
							data[i][j-1] = rs.getDouble(j);
							break;
						case Types.INTEGER:
							data[i][j-1] = rs.getInt(j);
							break;
						case Types.SMALLINT:
							data[i][j-1] = rs.getInt(j);
							break;

						}
					}
					i++;
				}
				//STEP 6: Clean-up environment
				rs.close();
				stmt.close();
				conn.close();

			}catch(SQLException se){

				//Handle errors for JDBC
				se.printStackTrace();

			}catch(Exception e){

				//Handle errors for Class.forName
				e.printStackTrace();

			}finally{

				try{
					if(stmt!=null)
						stmt.close();
				}catch(SQLException se){
					se.printStackTrace();
				}

				try{
					if(conn!=null)
						conn.close();
				}catch(SQLException se){
					se.printStackTrace();
				}
			}
			return data;


		}
	
	
	
	/*public Map<String, String> getConsigneeDetails(String endPointUrl){
		
		getDriver().get(endPointUrl);
		String pageSource = getDriver().getPageSource();
		System.out.println(pageSource);
		DOMParser parser = new DOMParser();
		try {
		    parser.parse(new InputSource(new java.io.StringReader(pageSource)));
		    Document doc = parser.getDocument();
		    String message = doc.getDocumentElement().getTextContent();
		    System.out.println(message);
		} catch (SAXException e) {
		    // handle SAXException 
		} catch (IOException e) {
		    // handle IOException 
		}
		return null;
		
		RestAssured.baseURI= endPointUrl;
		
		Response response = 	
				RestAssured
				.given()
				.header(new Header("Content-Type", "application/json"))
				.get()
				.then()
				.extract().response();
				
		if(response.statusCode() == 200) {
			System.out.println("Success with requests");
		}else {
			System.out.println("Response failed with status code: "+response.statusCode() + "and the response error is "+response.prettyPrint());
			throw new RuntimeException();
		}
		
		JsonPath jsonResponse = response.body().jsonPath();
		System.out.println(jsonResponse.prettyPrint());
		return null;
		
	}
	*/
	
	
	
}
