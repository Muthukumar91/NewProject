package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC0016_CreateDespatchLinkageWithNonSelectedFactoryUnitON extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkageNotSelectedFactory";
		testDescription="CreateDespatchLinkageNotSelectedFactory";
		category="smoke";
		dataSource="excel"; 
		dataSheetName="DespatchLinkage/TC0016";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String username,String password,String factoryName) throws InterruptedException  {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickManIcon()
		.clickFactoryOptions()
		.selectFactory(factoryName)
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(2000); 
		new CreateDespatchLinkage()
		.typeOrderNumberNegative(username, factoryName);
		
		
		
		
		
		
	}


}
