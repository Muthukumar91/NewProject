package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC007_CreateDespatchLinkageMandatory1 extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkageMandateFieldsOrder";
		testDescription="CreateDespatchLinkageMandateFieldsOrder";
		category="smoke";
		dataSource="Excel";
		dataSheetName="DespatchLinkage/TC008";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void runLogin(String uName, String pwd) throws InterruptedException {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()  
		.clickDespatchLinkage()
		.clickCreate();

		Thread.sleep(3000);
		new CreateDespatchLinkage()
		.verifyMandatoryFields()
		.clickGetProducts()
		.getdialogTitle()
		.getdialogMsg() 
		.CloseMessage(); 
		
	
		
	}


}
