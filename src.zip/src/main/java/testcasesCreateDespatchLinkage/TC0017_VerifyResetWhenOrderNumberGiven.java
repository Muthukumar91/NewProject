package testcasesCreateDespatchLinkage;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC0017_VerifyResetWhenOrderNumberGiven extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC0017_VerifyResetWhenOrderNumberGiven";
		testDescription="TC0017_VerifyResetWhenOrderNumberGiven";
		category="End to End flow";
		dataSource="excel"; 
		dataSheetName="DespatchLinkage/TC001";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void TC0017_VerifyResetWhenOrderNumberGiven(String username,String password,String factoryName) throws InterruptedException  {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickManIcon()
		.clickFactoryOptions()
		.selectFactory(factoryName)
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(2000); 
		new CreateDespatchLinkage()
		.typeOrderNumber(username, factoryName)
		.getorderNumber()
		.clickReset()
		.clickYesConfirmation()
		.getorderNumber();
		
		
	}

}
