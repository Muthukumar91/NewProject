package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC0014_CreateDespatchLinkageSubmitYesWithTPR extends PreAndPost{
//	@Parameters({"browsername"})
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkageWithTPR";
		testDescription="CreateDespatchLinkageWithTPR";
		category="End to End flow";
		dataSource="excel"; 
		dataSheetName="DespatchLinkage/TC0014";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void endToEndCrfeate(String username,String password,String factoryName) throws InterruptedException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickManIcon()
		.clickFactoryOptions()
		.selectFactory(factoryName)
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(2000); 
		new CreateDespatchLinkage()
		.typeOrderNumber(username,factoryName)
		.clickOrderinfo()
		.verifyInfoDetails()
		.typeConsignee(factoryName)
		.clickConsigneeInfo()
		.verifyInfoDetails()
		.clickLotNumber()
		.VerifyLotNumbers()
		.enterLotNumber()
		.clickGetProducts()
		.getNumberOfDispatchRecords()
		.enterQuantityForAllToBeLinked()  
		.clickSubmit()
		.clickYesConfirmation();
		Thread.sleep(2000);
		new CreateDespatchLinkage()
		.getdialogMsg()
		.CloseMessage()
		.verifyInsertionOfDLNum()
		.clickView()
		
		.typeOrderNumber(CreateDespatchLinkage.orderNumber)
		.typeConsignee(CreateDespatchLinkage.consigneeCode)
		.typeLinkageNo(CreateDespatchLinkage.despatchLinkageNumber)
		.clickgo()
		.clickLinkedQuantity();
		
		
		
	}

}
