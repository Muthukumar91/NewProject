package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC0020_VerifyLinkageNumberInDbCorrespondingToSelectedLotNumber extends PreAndPost{
	
	

		@BeforeClass
		public void setValues() {
			browserName="internet explorer";
			testCaseName="VerifyLinkageNumberInDbCorrespondingToSelectedLotNumber";
			testDescription="VerifyLinkageNumberInDbCorrespondingToSelectedLotNumber";
			category="Smoke";
			dataSource="excel"; 
			dataSheetName="DespatchLinkage/TC0020";
			authors="Srujana";
		}
		
		@Test(dataProvider ="fetchData")
		public void VerifyLinkageNumberInDbCorrespondingToSelectedLotNumber(String username,String password,String factoryName,String lotNumber1,String lotNumber2) throws InterruptedException  {
			new LoginPage()
			.enterUserName(username)
			.enterPassword(password)
			.clickLogin()
			.clickNavigation()
			.clickDocument()
			.clickDespatch()
			.clickDespatchLinkage()
			.clickCreate();
			Thread.sleep(2000); 
			new CreateDespatchLinkage()
			.typeOrderNumber(username,factoryName)
			.typeConsignee(factoryName)
			.clickLotNumber()
			.enterLotNumber(lotNumber1)
			.clickGetProducts()
			.clickLotNumber()
			.enterLotNumber(lotNumber2)
			.getNumberOfDispatchRecords()
			.enterQuantityForAllToBeLinked()  
			.clickSubmit()
			.clickYesConfirmation()
			.getdialogMsg()
			.verifyInsertionOfDLNum();
		}
}
