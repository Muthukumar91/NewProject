package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC006_CreateDespatchLinkageAboveExpectedLinkedQuantity extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkageAboveExpectedQuantity";
		testDescription="CreateDespatchLinkageAboveExpectedQuantity";
		category="smoke";
		dataSource="excel";
		dataSheetName="DespatchLinkage/TC001";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void createDespatchLinkageAboveExpectedQuantity(String username,String password,String factoryName) throws InterruptedException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch() 
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(3000);
		new CreateDespatchLinkage()
		.verifyMandatoryFields()
		.typeOrderNumber(username,factoryName)
		.typeConsignee(factoryName)
		.clickLotNumber()
		.enterLotNumber()
		.clickGetProducts()
		.getNumberOfDispatchRecords()
		.enterQuantityAboveExpected()
		.getdialogTitle()
		.getdialogMsg()
		.CloseMessage();
		
		
	}


}
