package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC008_CreateDespatchLinkageMandatory2 extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkageMandateConsginee";
		testDescription="CreateDespatchLinkageMandateConsginee";
		category="smoke";
		dataSource="Excel";
		dataSheetName="DespatchLinkage/TC001";
		authors="Ramki";
	}
	
	@Test(dataProvider ="fetchData")
	public void createDespatchLinkageMandateConsginee(String uName, String pwd,String factoryName) throws InterruptedException {
		new LoginPage()
		.enterUserName(uName)
		.enterPassword(pwd)
		.clickLogin()
		.clickNavigation() 
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(3000); 
		new CreateDespatchLinkage() 
		.typeOrderNumber(uName, factoryName)
		.clickGetProducts()
		.getdialogTitle()
		.getdialogMsg()
		.CloseMessage();
	
	
	}


}
