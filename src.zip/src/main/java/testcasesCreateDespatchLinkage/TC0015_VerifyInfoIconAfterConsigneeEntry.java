package testcasesCreateDespatchLinkage;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC0015_VerifyInfoIconAfterConsigneeEntry extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC0015_VerifyInfoIconAfterConsigneeEntry";
		testDescription="TC0015_VerifyInfoIconAfterConsigneeEntry";
		category="smoke";
		dataSource="excel"; 
		dataSheetName="DespatchLinkage/TC001";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void TC0015_VerifyInfoIconAfterConsigneeEntry(String username,String password,String factoryName) throws InterruptedException  {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(2000); 
		new CreateDespatchLinkage()
		.typeConsignee(factoryName)
		.clickOrderinfo()
		.verifyInfoDetails();
	}

}
