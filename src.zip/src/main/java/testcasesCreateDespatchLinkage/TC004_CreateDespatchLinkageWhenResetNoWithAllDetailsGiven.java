package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC004_CreateDespatchLinkageWhenResetNoWithAllDetailsGiven extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkageResetno";
		testDescription="CreateDespatchLinkageResetno";
		category="smoke";
		dataSource="excel"; 
		dataSheetName="DespatchLinkage/TC001"; 
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void createDespatchLinkageResetno(String username,String password,String factoryName) throws InterruptedException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch() 
		.clickDespatchLinkage()
		.clickCreate(); 
		Thread.sleep(3000);
		new CreateDespatchLinkage()
		.verifyMandatoryFields()                       
		.typeOrderNumber(username,factoryName)
		.getorderNumber()
		.typeConsignee(factoryName)
		.getConsigneeCode()
		.clickLotNumber()
		.enterLotNumber()
		.getLotNumber()
		.clickGetProducts()
		.getNumberOfDispatchRecords()
		.enterQuantityForAllToBeLinked()  
		.clickReset() 
		.getdialogMsg()
		.clickNoConfirmation()
		.getorderNumber()
		.getConsigneeCode()
		.getLotNumber()
		.getNumberOfDispatchRecords();
	}


}
