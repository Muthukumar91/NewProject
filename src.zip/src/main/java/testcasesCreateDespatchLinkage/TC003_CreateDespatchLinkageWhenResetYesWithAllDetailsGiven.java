package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC003_CreateDespatchLinkageWhenResetYesWithAllDetailsGiven extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkageResetYes";
		testDescription="CreateDespatchLinkageResetYes"; 
		category="smoke";
		dataSource="excel";
		dataSheetName="DespatchLinkage/TC001";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void createDespatchLinkageResetYes(String username,String password,String factoryName) throws InterruptedException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password) 
		.clickLogin() 
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(3000);
		new CreateDespatchLinkage()
		.clickRoles()
		.typeOrderNumber(username,factoryName)
		.getorderNumber()
		.typeConsignee(factoryName)
		.getConsigneeCode()
		.clickLotNumber()
		.enterLotNumber()
		.getLotNumber()
		.clickGetProducts()
		.getNumberOfDispatchRecords()
		.enterQuantityForAllToBeLinked()  
		.clickReset() 
		.getdialogMsg()
		.clickYesConfirmation()
		.getorderNumber()
		.getConsigneeCode()
		.getLotNumber()
		.getNumberOfDispatchRecords();
		
	}


}
