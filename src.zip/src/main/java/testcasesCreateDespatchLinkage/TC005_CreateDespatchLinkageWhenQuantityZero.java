package testcasesCreateDespatchLinkage;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.AbstractPage;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC005_CreateDespatchLinkageWhenQuantityZero extends PreAndPost{
	
	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="CreateDespatchLinkageQuanitytZero";
		testDescription="CreateDespatchLinkageQuanitytZero"; 
		category="smoke";
		dataSource="excel";
		dataSheetName="DespatchLinkage/TC001";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void createDespatchLinkageQuanitytZero(String username,String password,String factoryName) throws InterruptedException {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation() 
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(3000);
		new CreateDespatchLinkage()
		.verifyMandatoryFields()
		.typeOrderNumber(username,factoryName)
		.clickOrderinfo()
		.verifyInfoDetails()
		.typeConsignee(factoryName)
		.clickConsigneeInfo()
		.verifyInfoDetails()
		.clickLotNumber()
		.enterLotNumber()
		.clickGetProducts()
		.getNumberOfDispatchRecords()
		.enterQuantityZero()   
		.clickSubmit()
		.getdialogTitle()
		.getdialogMsg()
		.CloseMessage();
		
		if(CreateDespatchLinkage.dialogTitle.contains("Error")&&CreateDespatchLinkage.dialogMessage.contains("To be Linked Quantity should not be zero"))
					System.out.println("zero quantity not allowed validation success");
		else
					System.out.println("zero quantity not allowed validation not success");
	}


}
