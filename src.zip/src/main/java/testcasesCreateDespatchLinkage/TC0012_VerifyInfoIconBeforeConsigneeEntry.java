package testcasesCreateDespatchLinkage;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.PreAndPost;
import pages.CreateDespatchLinkage;
import pages.LoginPage;

public class TC0012_VerifyInfoIconBeforeConsigneeEntry extends PreAndPost{

	@BeforeClass
	public void setValues() {
		browserName="internet explorer";
		testCaseName="TC0012_VerifyInfoIconBeforeConsigneeEntry";
		testDescription="TC0012_VerifyInfoIconBeforeConsigneeEntry";
		category="smoke";
		dataSource="excel"; 
		dataSheetName="DespatchLinkage/TC008";
		authors="Srujana";
	}
	
	@Test(dataProvider ="fetchData")
	public void TC0012_VerifyInfoIconBeforeConsigneeEntry(String username,String password) throws InterruptedException  {
		new LoginPage()
		.enterUserName(username)
		.enterPassword(password)
		.clickLogin()
		.clickNavigation()
		.clickDocument()
		.clickDespatch()
		.clickDespatchLinkage()
		.clickCreate();
		Thread.sleep(2000); 
		new CreateDespatchLinkage()
		
	
		.clickConsigneeInfo()
		.verifyInfoDetails();
	}

}
